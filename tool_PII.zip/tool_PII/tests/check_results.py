"""Validate a scanner *_summary.json against tests/expected.json.

    python tests/check_results.py <summary.json> [<summary.json> ...]

Fails on: wrong classification / PHI flag, a missing expected PII type (false negative), or any unexpected
PII type (false positive). Files listed in expected.json but absent from the sample folder are reported as SKIP.
With two summaries, also checks that both scanners produced identical findings (parity).
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SAMPLE = os.path.join(HERE, "sample_data")
expected = json.load(open(os.path.join(HERE, "expected.json"), encoding="utf-8"))


def load(p):
    d = json.load(open(p, encoding="utf-8-sig"))
    return d, {os.path.basename(f["path"]): f for f in d["files"]}


def check(path) -> int:
    doc, files = load(path)
    print(f"\n== {doc['meta']['scanner']}  ({path})")
    fails = 0
    for name, exp in expected.items():
        if not os.path.exists(os.path.join(SAMPLE, name)):
            print(f"  SKIP {name} (not generated)")
            continue
        got = files.get(name)
        got_types = set(got["counts"]) if got else set()
        if got and not got["classification"]:
            got_types = set()
        want = set(exp["types"])
        problems = []
        cls = got["classification"] if got else ""
        if cls != exp["classification"]:
            problems.append(f"classification {cls!r} != {exp['classification']!r}")
        if (got["phi"] if got else False) != exp["phi"]:
            problems.append(f"phi {got['phi'] if got else False} != {exp['phi']}")
        if want - got_types:
            problems.append(f"MISSED {sorted(want - got_types)}")
        if got_types - want:
            problems.append(f"FALSE POSITIVE {sorted(got_types - want)}")
        if "max_findings" in exp and got and sum(got["counts"].values()) > exp["max_findings"]:
            problems.append(f"{sum(got['counts'].values())} findings > {exp['max_findings']}")
        status = "FAIL" if problems else "ok  "
        fails += bool(problems)
        print(f"  {status} {name:28} {cls or '-':13} {'; '.join(problems)}")
    print(f"  -> {fails} failure(s); suppressed low-confidence candidates: {doc['summary']['suppressed_low_confidence']}")
    return fails


def parity(a, b) -> int:
    def key(doc):
        return sorted((os.path.basename(f["path"]), x["where"], x["type"], x["confidence"], x["value"])
                      for f in doc["files"] for x in f["findings"])
    ka, kb = key(load(a)[0]), key(load(b)[0])
    only_a, only_b = sorted(set(ka) - set(kb)), sorted(set(kb) - set(ka))
    print(f"\n== parity: {len(ka)} vs {len(kb)} findings")
    for x in only_a:
        print("  only in first :", x)
    for x in only_b:
        print("  only in second:", x)
    return int(bool(only_a or only_b))


if __name__ == "__main__":
    rc = sum(check(p) for p in sys.argv[1:])
    if len(sys.argv) == 3:
        rc += parity(sys.argv[1], sys.argv[2])
    print("\nRESULT:", "PASS" if rc == 0 else "FAIL")
    sys.exit(1 if rc else 0)
