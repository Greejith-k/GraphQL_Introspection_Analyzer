"""Generate SYNTHETIC test files containing fake PII/PHI (checksum-valid but fictitious).

    python tests/make_test_data.py [output_dir]

All identifiers are randomly generated with a fixed seed; none belong to a real person.
Writes expected.json next to the data describing what each file must (and must not) produce.
Legacy Office / Outlook samples (.doc .xls .ppt .msg .pst) are created by make_legacy_test_data.ps1.
"""
import io
import json
import os
import random
import sys
import zipfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "python"))
from pii_scanner import luhn_ok, verhoeff_ok, v_gstin, _B36  # noqa: E402

rnd = random.Random(20261126)
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "sample_data")
os.makedirs(out, exist_ok=True)


def digits(n):
    return "".join(rnd.choice("0123456789") for _ in range(n))


def aadhaar(fmt=True):
    while True:
        base = rnd.choice("23456789") + digits(10)
        for d in "0123456789":
            if verhoeff_ok(base + d) and len(set(base + d)) > 3:
                n = base + d
                return f"{n[:4]} {n[4:8]} {n[8:]}" if fmt else n


def aadhaar_lookalike():
    """12 digits that pass Verhoeff but appear with no context - must be suppressed."""
    return aadhaar(fmt=False)


def card(prefix="4", length=16, sep=" "):
    while True:
        body = prefix + digits(length - len(prefix) - 1)
        for d in "0123456789":
            if luhn_ok(body + d):
                n = body + d
                return sep.join(n[i:i + 4] for i in range(0, len(n), 4)) if sep else n


def pan():
    L = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    return "".join(rnd.choice(L) for _ in range(3)) + "P" + rnd.choice(L) + digits(4) + rnd.choice(L)


def gstin():
    while True:
        p = pan()
        body = "29" + p + "1Z"
        total = 0
        for i, ch in enumerate(body):
            x = _B36.index(ch) * (2 if i % 2 else 1)
            total += x // 36 + x % 36
        g = body + _B36[(36 - total % 36) % 36]
        if v_gstin(g):
            return g


def iban_gb():
    bban = "MIDL" + digits(14)
    num = "".join(str(int(c, 36)) for c in bban + "GB00")
    chk = 98 - int(num) % 97
    s = f"GB{chk:02d}{bban}"
    return " ".join(s[i:i + 4] for i in range(0, len(s), 4))


def mobile():
    return rnd.choice("6789") + digits(9)


def abha():
    n = digits(14)
    return f"{n[:2]}-{n[2:6]}-{n[6:10]}-{n[10:]}"


A1, A2, A3 = aadhaar(), aadhaar(fmt=False), aadhaar()
P1, P2 = pan(), pan()
M1, M2 = mobile(), mobile()
files = {}
expect = {}

files["hr_employee_records.csv"] = (
    "EmpID,Name,Aadhaar,PAN,Mobile,Email,DOB,Bank Account No,IFSC\n"
    f"1001,Test User One,{A1},{P1},+91 {M1[:5]} {M1[5:]},test.one@corp-mail.in,12/05/1988,{digits(12)},HDFC0001234\n"
    f"1002,Test User Two,{A2},{P2},{M2},test.two@corp-mail.in,1990-01-31,{digits(11)},SBIN0004321\n")
expect["hr_employee_records.csv"] = {"classification": "Restricted", "phi": False, "types": [
    "Aadhaar Number", "PAN (India)", "Indian Mobile Number", "Email Address", "Date of Birth", "Bank Account Number",
    "IFSC Code"]}

files["payments_notes.txt"] = (
    f"Customer card {card()} exp 12/29\n"
    f"Backup debit card number {card('5', 16, '')}\n"
    f"Beneficiary account no: {digits(14)}  IFSC ICIC0009876\n"
    f"Wire to IBAN {iban_gb()}\n")
expect["payments_notes.txt"] = {"classification": "Restricted", "phi": False, "types": [
    "Credit/Debit Card Number", "Bank Account Number", "IFSC Code", "IBAN"]}

files["us_contractors.txt"] = f"Contractor SSN 512-{digits(2)}-{digits(3)}7\nPassport No: K{digits(6)}1\n"
expect["us_contractors.txt"] = {"classification": "Restricted", "phi": False, "types": ["US SSN", "Passport Number"]}

files["app.config"] = (
    "<connectionStrings>Server=db01;User Id=sa;Password=Monsoon#2026;</connectionStrings>\n"
    "aws_key=AKIA" + "".join(rnd.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ234567") for _ in range(16)) + "\n"
    "client_ip=10.20.30.40\n")
expect["app.config"] = {"classification": "Restricted", "phi": False, "types": [
    "Password in Clear Text", "AWS Access Key", "IPv4 Address"]}

files["kyc_india.json"] = json.dumps({"voter_id": f"Voter ID ABC{digits(7)}", "gstin": gstin(),
                                      "dl": f"Driving licence MH12 2011{digits(7)}"}) + "\n"
expect["kyc_india.json"] = {"classification": "Confidential", "phi": False, "types": [
    "Voter ID (EPIC)", "GSTIN", "Indian Driving Licence"]}

files["discharge_summary.txt"] = (
    "CITY HOSPITAL - DISCHARGE SUMMARY\n"
    f"Patient: Test Patient   UHID: CH{digits(7)}   ABHA Number: {abha()}\n"
    "ABHA Address: testpatient.demo@abdm\n"
    f"Contact mobile: {mobile()}   Aadhaar: {A3}\n"
    "Diagnosis: Type 2 diabetes mellitus (ICD-10 E11.9) with hypertension\n"
    "Blood group: B+   HbA1c 8.1%   Insulin started\n"
    f"PM-JAY ID: {''.join(rnd.choice('ABCDEFGHJKLMNPQRSTUVWXYZ0123456789') for _ in range(8))}7\n"
    f"Mediclaim policy no: HLT/{digits(8)}/01\n")
expect["discharge_summary.txt"] = {"classification": "Restricted", "phi": True, "types": [
    "UHID / MRN (Patient ID)", "ABHA Number", "ABHA Address", "Indian Mobile Number", "Aadhaar Number",
    "ICD-10 Diagnosis Code", "Blood Group", "Health Condition / Medical Term", "PM-JAY ID",
    "Insurance Policy / Claim No"]}

files["clean_readme.txt"] = "This file has no personal data. Version 1.2.3.4 build 20240101. Order 123456.\n"
expect["clean_readme.txt"] = {"classification": "", "phi": False, "types": []}

files["noise_negatives.txt"] = "\n".join([
    "Release notes v.10.0.19045.1 and version 2.4.18.200",
    f"Order reference {aadhaar_lookalike()} shipped",            # Verhoeff-valid 12 digits, no context
    f"Transaction {card('4', 16, '')} settled",                  # Luhn-valid 16 digits, no card context
    f"Call ticket {mobile()} closed",                            # bare 10 digits, no phone context
    "Epoch 1700000000 and 1712345678",
    "Assets: icon@2x.png logo@3x.webp  noreply@corp-mail.in",
    "Password: ********   password=${DB_PASS}   $password = Read-Host",
    "User account ID 123456789 created",
    "Invoice date 12/05/2023 due 30/06/2023",
    "Sample values from vendor docs: 4111 1111 1111 1111, AKIAIOSFODNN7EXAMPLE, ABCDE1234F, 9876543210",
    "We are running a cancer awareness drive in the office.",
    "Subnet mask 255.255.255.0 gateway version 10.0.0.1",
]) + "\n"
expect["noise_negatives.txt"] = {"classification": "", "phi": False, "types": [], "max_findings": 0}

for name, body in files.items():
    with open(os.path.join(out, name), "w", encoding="utf-8") as f:
        f.write(body)

CT = '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>'
doc_xml = ('<?xml version="1.0"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
           '<w:body><w:p><w:r><w:t>Offer letter for Test Candidate</w:t></w:r></w:p>'
           f'<w:p><w:r><w:t>Aadhaar: {aadhaar(fmt=False)}</w:t></w:r></w:p>'
           f'<w:p><w:r><w:t>PAN: {pan()}, Date of birth 3 March 1992</w:t></w:r></w:p></w:body></w:document>')
with zipfile.ZipFile(os.path.join(out, "offer_letter.docx"), "w") as z:
    z.writestr("[Content_Types].xml", CT)
    z.writestr("word/document.xml", doc_xml)
expect["offer_letter.docx"] = {"classification": "Restricted", "phi": False,
                               "types": ["Aadhaar Number", "PAN (India)", "Date of Birth"]}

# xlsx: header row in shared strings, Aadhaar & card as NUMERIC cells (context must come from the header)
ss = ["Name", "Card Number", "Email", "Aadhaar", "Customer A", "priya.test@corp-mail.in"]
ss_xml = ('<?xml version="1.0"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
          + "".join(f"<si><t>{s}</t></si>" for s in ss) + "</sst>")
cardnum, aad = card("4", 16, ""), aadhaar(fmt=False)
sheet = ('<?xml version="1.0"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>'
         '<row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c><c r="C1" t="s"><v>2</v></c>'
         '<c r="D1" t="s"><v>3</v></c></row>'
         f'<row r="2"><c r="A2" t="s"><v>4</v></c><c r="B2"><v>{cardnum}</v></c><c r="C2" t="s"><v>5</v></c>'
         f'<c r="D2"><v>{float(aad):.11E}</v></c></row></sheetData></worksheet>')
with zipfile.ZipFile(os.path.join(out, "customers.xlsx"), "w") as z:
    z.writestr("[Content_Types].xml", CT)
    z.writestr("xl/sharedStrings.xml", ss_xml)
    z.writestr("xl/worksheets/sheet1.xml", sheet)
expect["customers.xlsx"] = {"classification": "Restricted", "phi": False,
                            "types": ["Credit/Debit Card Number", "Email Address", "Aadhaar Number"]}

buf = io.StringIO()
buf.write("name,pan,mobile\n")
buf.write(f"Archived User,{pan()},{mobile()}\n")
with zipfile.ZipFile(os.path.join(out, "old_exports.zip"), "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("exports/2019/users.csv", buf.getvalue())
expect["old_exports.zip"] = {"classification": "Restricted", "phi": False,
                             "types": ["PAN (India)", "Indian Mobile Number"]}

# values used by the legacy-file generator (so the PS script doesn't need its own checksum code)
legacy = {"aadhaar": aadhaar(), "aadhaar_bare": aadhaar(fmt=False), "pan": pan(), "card": card("5", 16, ""),
          "mobile": mobile(), "abha": abha()}
META_DIR = os.path.dirname(os.path.abspath(__file__))  # keep metadata OUT of the scanned folder
with open(os.path.join(META_DIR, "_legacy_values.json"), "w", encoding="utf-8") as f:
    json.dump(legacy, f)
expect.update({
    "legacy_letter.doc": {"classification": "Restricted", "phi": False, "types": ["Aadhaar Number", "PAN (India)"]},
    "legacy_payroll.xls": {"classification": "Restricted", "phi": False,
                           "types": ["Aadhaar Number", "Credit/Debit Card Number", "Indian Mobile Number"]},
    "legacy_deck.ppt": {"classification": "Restricted", "phi": False, "types": ["PAN (India)"]},
    "patient_mail.msg": {"classification": "Restricted", "phi": True,
                         "types": ["ABHA Number", "Aadhaar Number", "PAN (India)", "Email Address"]},
    "mailbox.pst": {"classification": "Restricted", "phi": False, "types": ["Aadhaar Number", "PAN (India)"]},
})
with open(os.path.join(META_DIR, "expected.json"), "w", encoding="utf-8") as f:
    json.dump(expect, f, indent=1)
print(f"Synthetic test data written to {os.path.abspath(out)}")
