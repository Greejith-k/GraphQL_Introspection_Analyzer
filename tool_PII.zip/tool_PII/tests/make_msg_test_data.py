"""Write a synthetic Outlook .msg (MS-OXMSG in an MS-CFB container) without needing Outlook.

    python tests/make_msg_test_data.py [output_dir]

Includes a long body (> 4096 bytes, regular FAT sectors), short property streams (mini stream)
and a .docx attachment, so both CFB allocation paths and attachment recursion are exercised.
"""
import io
import json
import math
import os
import struct
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
FREE, END, FATSECT, NOSTREAM = 0xFFFFFFFF, 0xFFFFFFFE, 0xFFFFFFFD, 0xFFFFFFFF
SS, MSS, CUTOFF = 512, 64, 4096


def write_cfb(entries: dict) -> bytes:
    nodes = [{"name": "Root Entry", "type": 5, "children": [], "data": b""}]
    index = {"": 0}
    for path in sorted(entries):
        parts = path.split("/")
        for k in range(1, len(parts)):
            sp = "/".join(parts[:k])
            if sp not in index:
                index[sp] = len(nodes)
                nodes.append({"name": parts[k - 1], "type": 1, "children": [], "data": b""})
                nodes[index["/".join(parts[:k - 1])]]["children"].append(index[sp])
        index[path] = len(nodes)
        nodes.append({"name": parts[-1], "type": 2, "children": [], "data": entries[path]})
        nodes[index["/".join(parts[:-1])]]["children"].append(index[path])

    sectors, fat = [], []

    def alloc(data: bytes) -> int:
        n = max(1, math.ceil(len(data) / SS))
        first = len(sectors)
        for i in range(n):
            sectors.append(data[i * SS:(i + 1) * SS].ljust(SS, b"\0"))
            fat.append(first + i + 1 if i < n - 1 else END)
        return first

    ministream, minifat = bytearray(), []
    for nd in nodes:
        if nd["type"] != 2:
            continue
        d = nd["data"]
        if len(d) >= CUTOFF:
            nd["start"] = alloc(d)
        else:
            n = max(1, math.ceil(len(d) / MSS))
            nd["start"] = len(minifat)
            for i in range(n):
                minifat.append(len(minifat) + 1 if i < n - 1 else END)
            ministream += d.ljust(n * MSS, b"\0")
    root_start = alloc(bytes(ministream)) if ministream else END
    mf = b"".join(struct.pack("<I", x) for x in minifat)
    mf += b"\xff" * ((-len(mf)) % SS)
    minifat_start = alloc(mf) if minifat else END

    for nd in nodes:
        nd.setdefault("left", NOSTREAM)
        nd.setdefault("right", NOSTREAM)
        nd["child"] = nd["children"][0] if nd["children"] else NOSTREAM
        for a, b in zip(nd["children"], nd["children"][1:]):
            nodes[a]["right"] = b
    dirb = bytearray()
    for i, nd in enumerate(nodes):
        name = nd["name"].encode("utf-16-le") + b"\0\0"
        start = root_start if i == 0 else nd.get("start", 0)
        size = len(ministream) if i == 0 else len(nd["data"])
        e = name.ljust(64, b"\0") + struct.pack("<HBBIII", len(name), nd["type"], 1, nd["left"], nd["right"],
                                               nd["child"])
        e += b"\0" * 16 + b"\0" * 4 + b"\0" * 16 + struct.pack("<IQ", start if nd["type"] != 1 else 0, size)
        dirb += e
    while len(dirb) % SS:
        dirb += b"\0" * 64 + struct.pack("<HBBIII", 0, 0, 0, NOSTREAM, NOSTREAM, NOSTREAM) + b"\0" * 52
    dir_start = alloc(bytes(dirb))

    nfat = 1
    while math.ceil((len(sectors) + nfat) / (SS // 4)) > nfat:
        nfat += 1
    fat_ids = list(range(len(sectors), len(sectors) + nfat))
    fat += [FATSECT] * nfat
    fat += [FREE] * (nfat * (SS // 4) - len(fat))
    fatb = b"".join(struct.pack("<I", x) for x in fat)
    for i in range(nfat):
        sectors.append(fatb[i * SS:(i + 1) * SS])

    hdr = b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1" + b"\0" * 16
    hdr += struct.pack("<HHHHH", 0x3E, 3, 0xFFFE, 9, 6) + b"\0" * 6
    hdr += struct.pack("<IIIIIIIII", 0, nfat, dir_start, 0, CUTOFF, minifat_start, len(mf) // SS if minifat else 0,
                       END, 0)
    difat = fat_ids + [FREE] * (109 - len(fat_ids))
    hdr += b"".join(struct.pack("<I", x) for x in difat)
    assert len(hdr) == 512
    return hdr + b"".join(sectors)


def u16(s: str) -> bytes:
    return s.encode("utf-16-le")


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "sample_data")
    v = json.load(open(os.path.join(HERE, "_legacy_values.json"), encoding="utf-8"))
    att = io.BytesIO()
    with zipfile.ZipFile(att, "w") as z:
        z.writestr("[Content_Types].xml", "<Types/>")
        z.writestr("word/document.xml", f"<w:document><w:body><w:p><w:t>PAN card copy: {v['pan']}</w:t></w:p>"
                                        "</w:body></w:document>")
    filler = "Please find the patient's records attached for the insurance pre-authorisation.\n" * 60
    body = (f"Dear TPA desk,\nPatient ABHA Number: {v['abha']}\nPatient Aadhaar: {v['aadhaar']}\n" + filler)
    entries = {
        "__substg1.0_0037001F": u16("Pre-auth request - patient documents"),
        "__substg1.0_1000001F": u16(body),
        "__substg1.0_0C1F001F": u16("frontdesk@hospital-test.in"),
        "__properties_version1.0": b"\0" * 32,
        "__attach_version1.0_#00000000/__substg1.0_3707001F": u16("id_proof.docx"),
        "__attach_version1.0_#00000000/__substg1.0_37010102": att.getvalue(),
        "__attach_version1.0_#00000000/__properties_version1.0": b"\0" * 8,
    }
    path = os.path.join(out, "patient_mail.msg")
    with open(path, "wb") as f:
        f.write(write_cfb(entries))
    print(f"wrote {path} ({os.path.getsize(path)} bytes, body {len(entries['__substg1.0_1000001F'])} bytes)")
