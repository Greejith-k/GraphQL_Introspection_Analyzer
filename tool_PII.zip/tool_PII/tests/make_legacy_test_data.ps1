<#
  Creates genuine legacy Office test files (.doc .xls .ppt) through Office COM, using the synthetic
  values written by make_test_data.py (tests\_legacy_values.json). Run make_test_data.py first.
  The .msg sample is produced by make_msg_test_data.py (no Outlook profile needed).
#>
param([string]$OutDir = (Join-Path $PSScriptRoot 'sample_data'))
$ErrorActionPreference = 'Stop'
$v = Get-Content (Join-Path $PSScriptRoot '_legacy_values.json') -Raw | ConvertFrom-Json
$OutDir = (Resolve-Path $OutDir).Path

function Release($o) { if ($o) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($o) } }

# --- Word 97-2003 .doc ------------------------------------------------------
$w = New-Object -ComObject Word.Application
try {
    $w.DisplayAlerts = 0
    $d = $w.Documents.Add()
    $d.Content.Text = "Legacy employment letter`rEmployee Aadhaar: $($v.aadhaar)`rPAN of employee: $($v.pan)`rRegards, HR"
    $d.SaveAs2((Join-Path $OutDir 'legacy_letter.doc'), 0)   # 0 = wdFormatDocument (97-2003)
    $d.Close(0); Release $d
} finally { $w.Quit(); Release $w }

# --- Excel 97-2003 .xls -----------------------------------------------------
$x = New-Object -ComObject Excel.Application
try {
    $x.DisplayAlerts = $false
    $wb = $x.Workbooks.Add(); $ws = $wb.Worksheets.Item(1)
    $hdr = 'Employee', 'Aadhaar', 'Card Number', 'Mobile'
    for ($i = 0; $i -lt 4; $i++) { $ws.Cells.Item(1, $i + 1).Value2 = $hdr[$i] }
    $ws.Cells.Item(2, 1).Value2 = 'Legacy Payroll User'
    $ws.Cells.Item(2, 2).Value2 = [double]$v.aadhaar_bare           # numeric cell (NUMBER record)
    $ws.Cells.Item(2, 3).NumberFormat = '@'
    $ws.Cells.Item(2, 3).Value2 = [string]$v.card                   # text cell (SST string)
    $ws.Cells.Item(2, 4).Value2 = [double]$v.mobile                 # numeric (RK/NUMBER)
    $wb.SaveAs((Join-Path $OutDir 'legacy_payroll.xls'), 56)       # 56 = xlExcel8
    $wb.Close($false); Release $ws; Release $wb
} finally { $x.Quit(); Release $x }

# --- PowerPoint 97-2003 .ppt ------------------------------------------------
$p = New-Object -ComObject PowerPoint.Application
try {
    $pres = $p.Presentations.Add(0)                                 # no window
    $s = $pres.Slides.Add(1, 2)                                     # ppLayoutText
    $s.Shapes.Item(1).TextFrame.TextRange.Text = 'Vendor onboarding'
    $s.Shapes.Item(2).TextFrame.TextRange.Text = "Proprietor PAN: $($v.pan)"
    $pres.SaveAs((Join-Path $OutDir 'legacy_deck.ppt'), 1)          # 1 = ppSaveAsPresentation
    $pres.Close(); Release $s; Release $pres
} finally { $p.Quit(); Release $p }
[GC]::Collect(); [GC]::WaitForPendingFinalizers()
Write-Host "Legacy Office samples written to $OutDir"
