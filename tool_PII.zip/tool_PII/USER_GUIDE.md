# PII / PHI Scanner – User Guide

This guide shows you how to run the toolkit in the three situations you will meet on an engagement:

1. **[On a single local machine](#3-scanning-a-local-machine)** – a laptop, workstation or file server, scanned from its own console
2. **[Across the network](#4-scanning-across-the-network)** – SMB shares on other machines, or many machines at once over WinRM
3. **[Active Directory](#5-scanning-active-directory)** – PII hiding in user, computer and group attributes

Sections 6–9 cover reading the reports, merging results from many hosts, tuning, and troubleshooting.

> **Before you start:** make sure the engagement letter or rules of engagement explicitly authorise *reading file
> contents* for PII discovery. Agree the scan window with the client's SOC, because bulk file reads can trigger EDR /
> ransomware alerts. The reports themselves contain sensitive information, so store them on an access-controlled
> location.

---

## 1. Which scanner should I use?

Both scanners use the same rules and produce the same reports. Pick based on where you are running:

| Situation | Use |
|---|---|
| Windows machine, nothing may be installed | **PowerShell** – `Invoke-PIIScan.ps1` |
| Scanning many Windows hosts at once (WinRM) | **PowerShell** – `Invoke-PIIScanRemote.ps1` |
| Large file server / NAS, or you need **PDF** or **PST** content | **Python** – `pii_scanner.py` |
| Linux / Kali VAPT box | **Python** |
| Host enforces Constrained Language Mode (AppLocker / WDAC) | **Python** (the PowerShell version needs `Add-Type`) |

---

## 2. Setup

### 2.1 Copy the toolkit

Copy the whole folder and **keep the structure**, because both scanners look for the rules in `..\rules\`:

```
tool_PII\
├── powershell\Invoke-PIIScan.ps1
├── powershell\Invoke-PIIScanRemote.ps1
├── python\pii_scanner.py
└── rules\pii_rules.json
```

(For a flat single-machine drop you may also place `pii_rules.json` next to `Invoke-PIIScan.ps1`.)

### 2.2 PowerShell prerequisites

* Windows PowerShell 5.1 (built into Windows 10/11 and Server 2016+). Nothing to install.
* If the folder came from a zip or e-mail, remove the "downloaded from internet" mark once:

```powershell
Get-ChildItem .\tool_PII -Recurse | Unblock-File
```

* If execution policy blocks scripts, run them like this (affects only that one process):

```powershell
powershell -ExecutionPolicy Bypass -File .\powershell\Invoke-PIIScan.ps1 -Path C:\Users
```

### 2.3 Python prerequisites

* Python 3.8 or later. The core needs only the standard library.
* Optional extras (install only what you need):

```bash
pip install pypdf            # PDF content
pip install libpff-python    # Outlook .pst / .ost
pip install ldap3            # Active Directory scan
pip install pywin32          # file owner column (Windows)
```

### 2.4 Your first run (2-minute sanity check)

```powershell
cd tool_PII
.\powershell\Invoke-PIIScan.ps1 -Path $env:USERPROFILE\Documents
```

When it finishes it prints a summary and the path of the reports, for example:

```
[+] 412 files in 6.3s: 9 with PII (Restricted 4, Confidential 3, Internal 2), PHI 0, suppressed low-confidence 31, AD 0
[+] Reports: C:\tool_PII\PII_Reports\PII_WS01_20261126_101500_report.html / _findings.csv / _files.csv / _summary.json
```

Open the `_report.html` file in a browser. See [section 6](#6-reading-the-results) for what it shows.

---

## 3. Scanning a local machine

Run these **on the machine being scanned**. Running the console as Administrator lets the scanner read every user's
profile; without admin rights it silently skips folders it cannot open.

### 3.1 Common scans

| Goal | PowerShell | Python |
|---|---|---|
| One or more folders | `.\Invoke-PIIScan.ps1 -Path C:\Users, D:\Data` | `python pii_scanner.py --path C:\Users --path D:\Data` |
| All fixed drives | `.\Invoke-PIIScan.ps1 -AllDrives` | `python pii_scanner.py --all-drives` |
| Include file owners | add `-IncludeOwner` | add `--include-owner` (needs pywin32) |
| Include Outlook PSTs | add `-IncludePst` (needs Outlook with a profile) | automatic if `libpff-python` is installed |
| Choose report folder | `-OutputDir D:\PII_Reports` | `--out D:\PII_Reports` |

Recommended full-machine scan:

```powershell
# as Administrator
.\powershell\Invoke-PIIScan.ps1 -AllDrives -IncludeOwner -OutputDir D:\PII_Reports
```

### 3.2 What is skipped automatically

* **System folders:** `Windows`, `Program Files`, `Program Files (x86)`, `ProgramData`, `AppData`, `$Recycle.Bin`,
  `System Volume Information`, `node_modules`, `.git`, Python virtual environments. Use `-NoDefaultExcludes` /
  `--no-default-excludes` to include them. Add your own exclusions with `-ExcludeDir Backup, Temp` /
  `--exclude-dir Backup`.
* **Large files:** text files over 25 MB are *partially* scanned (first 25 MB). Larger Office or binary files are skipped
  and listed in `_files.csv`. Change the limit with `-MaxFileSizeMB 100` / `--max-size-mb 100`.
* Office lock files (`~$...`), junctions and symbolic links.

### 3.3 File servers

Scan **on the server itself** using local paths. It is far faster than reading the same data over the network:

```powershell
.\powershell\Invoke-PIIScan.ps1 -Path D:\Shares\HR, D:\Shares\Finance -Threads 16 -IncludeOwner
```
```bash
python python\pii_scanner.py --path D:\Shares --workers 16 --include-owner
```

Scans use all logical CPUs by default. On a busy production server, reduce the load with `-Threads 4` / `--workers 4`.

---

## 4. Scanning across the network

There are two approaches:

| | **A. Agentless share scan** | **B. Remote execution (WinRM)** |
|---|---|---|
| Where the scan runs | On *your* machine; file content is pulled over SMB | On *each target*; only reports come back |
| What it covers | Shared folders (plus `C$`, `D$` with admin rights) | Every local drive of each host |
| Needs on targets | SMB (TCP 445) | WinRM (TCP 5985/5986) enabled |
| Speed | Limited by network | Fast, runs in parallel on every host |
| Best for | Quick VAPT sweep, NAS, file shares | Full estate coverage of workstations and servers |

### 4.1 A. Agentless share scan from your VAPT machine

#### Credentials

* **Domain-joined Windows machine, logged in as the audit account:** nothing extra is needed.
* **Non-domain Windows machine:** pass the client account with `-Credential` (PowerShell) or `--smb-user` (Python):

```powershell
$cred = Get-Credential CLIENT\pii_auditor
```

#### Scan specific hosts

```powershell
# Scan all non-admin shares on two hosts
.\powershell\Invoke-PIIScan.ps1 -ComputerName fs01, 10.10.20.15 -Credential $cred

# Also read whole drives through C$, D$ ... (account must be local admin on the target)
.\powershell\Invoke-PIIScan.ps1 -ComputerName fs01 -IncludeAdminShares -Credential $cred

# Hosts from a text file (one name or IP per line; lines starting with # are ignored)
.\powershell\Invoke-PIIScan.ps1 -ComputerListFile .\hosts.txt -Credential $cred
```
```bash
# Python (Windows). Password is prompted, or set environment variable PII_SMB_PASSWORD
python python\pii_scanner.py --host fs01 --host 10.10.20.15 --smb-user CLIENT\pii_auditor
python python\pii_scanner.py --hosts-file hosts.txt --smb-user CLIENT\pii_auditor --include-admin-shares --workers 16
```

#### Scan specific UNC paths

```powershell
.\powershell\Invoke-PIIScan.ps1 -Path \\fs01\HR, \\nas02\Scans -Credential $cred
```
```bash
python python\pii_scanner.py --path \\fs01\HR --path \\nas02\Scans --smb-user CLIENT\pii_auditor
```

#### Every computer in the domain (or an OU)

```powershell
.\powershell\Invoke-PIIScan.ps1 -DiscoverComputersFromAD -ADServer dc01.client.local `
    -ADSearchBase "OU=Servers,DC=client,DC=local" -Credential $cred
```

The scanner lists enabled computer accounts from AD, skips hosts where port 445 is closed, enumerates each host's shares
and scans them. `ADMIN$`, `IPC$` and `print$` are always skipped.

#### From a Linux / Kali box

Share discovery (`--host`) is Windows-only. On Linux, mount each share and scan the mount point:

```bash
sudo mkdir -p /mnt/hr
sudo mount -t cifs //fs01/HR /mnt/hr -o username=pii_auditor,domain=CLIENT,ro
python3 python/pii_scanner.py --path /mnt/hr --workers 16 --out ./reports_fs01_hr
sudo umount /mnt/hr
```

> **Tip:** the `ro` (read-only) mount option guarantees nothing on the share can be changed.

### 4.2 B. Remote execution on many hosts (WinRM)

`Invoke-PIIScanRemote.ps1` sends the scanner to each host over WinRM and runs it there in memory. Nothing is installed.
It then pulls the reports back, deletes the temporary copies on the target and builds a combined estate report.

**Requirements**

* WinRM enabled on the targets (`Enable-PSRemoting`, usually pushed by GPO). Firewall must allow TCP 5985 (HTTP) or
  5986 (HTTPS).
* An account that is **local administrator** on the targets.
* Run from a Windows machine that can reach the targets. If it is not domain-joined, the targets must be in its
  `TrustedHosts` list, or you can use HTTPS with `-UseSSL`.

**Examples**

```powershell
$cred = Get-Credential CLIENT\pii_auditor

# Named hosts, all fixed drives on each
.\powershell\Invoke-PIIScanRemote.ps1 -ComputerName ws01, ws02, fs01 -Credential $cred

# Every enabled computer in an OU, 32 hosts at a time
.\powershell\Invoke-PIIScanRemote.ps1 -FromAD -ADServer dc01.client.local `
    -ADSearchBase "OU=Workstations,DC=client,DC=local" -Credential $cred -ThrottleLimit 32

# Only certain folders on each host, plus file owners and Outlook PSTs
.\powershell\Invoke-PIIScanRemote.ps1 -ComputerListFile .\hosts.txt -Credential $cred `
    -RemotePath 'C:\Users', 'D:\Data' -ScanArgs @{ IncludeOwner = $true; IncludePst = $true }
```

**What you get** (default folder `.\PII_Collected`, change with `-CollectTo`)

```
PII_Collected\
├── WS01\PII_WS01_..._report.html, _findings.csv, _files.csv, _summary.json
├── WS02\...
├── _failures.csv            ← hosts that were unreachable, denied access or timed out
└── _estate\ESTATE_..._report.html   ← one consolidated report for all hosts
```

Useful options:

| Option | Purpose |
|---|---|
| `-ThrottleLimit 16` | Hosts scanned at the same time |
| `-TimeoutMinutes 240` | Give up on hosts that run longer than this |
| `-UseSSL` | WinRM over HTTPS (5986) |
| `-ScanArgs @{...}` | Any `Invoke-PIIScan.ps1` option, e.g. `@{ MinConfidence = 'High'; MaxFileSizeMB = 50 }` |
| `-NoMerge` | Collect only, merge later |

Re-run only the failed hosts:

```powershell
$failed = (Import-Csv .\PII_Collected\_failures.csv).Host
.\powershell\Invoke-PIIScanRemote.ps1 -ComputerName $failed -Credential $cred
```

### 4.3 Alternative: deploy through GPO / SCCM / Intune

If WinRM is not available, have the client's IT team run the scanner as a scheduled task or package. Each machine writes
to a central share that is **write-only** for computers:

```powershell
powershell -ExecutionPolicy Bypass -File \\deploy\tool_PII\powershell\Invoke-PIIScan.ps1 `
    -AllDrives -Quiet -OutputDir "\\collector\PIIReports$\$env:COMPUTERNAME"
```

Afterwards, merge the results as described in [section 7](#7-merging-results-from-many-hosts).

---

## 5. Scanning Active Directory

The AD scan reads every user, contact, computer and group object and reports:

* **PII in free-text attributes:** `description`, `info`, `comment`, `notes`, `extensionAttribute1–15` and others. This
  catches Aadhaar or PAN numbers, phone numbers and **passwords** that admins have typed into description fields.
* **Password attributes that hold a value:** `userPassword`, `unixUserPassword`, `msSFU30Password` and similar
  (Critical).
* **"Possible password reference":** text such as "temp pass" or "pwd" in a description, flagged for manual review.
* **Structured PII inventory:** how many objects carry `employeeID`, `mobile`, `homePhone`, `streetAddress` and so on.
  Only counts are reported here, not the values.

A normal domain user account is usually enough, because these attributes are readable by Authenticated Users by
default. The scan is read-only LDAP.

### 5.1 PowerShell (recommended)

```powershell
# On a domain-joined machine, as a domain user
.\powershell\Invoke-PIIScan.ps1 -ScanAD

# Limit to an OU
.\powershell\Invoke-PIIScan.ps1 -ScanAD -ADSearchBase "OU=Staff,DC=client,DC=local"

# From a non-domain VAPT machine
.\powershell\Invoke-PIIScan.ps1 -ScanAD -ADServer dc01.client.local -Credential (Get-Credential CLIENT\pii_auditor)

# AD + this machine's drives in one run
.\powershell\Invoke-PIIScan.ps1 -ScanAD -AllDrives
```

No RSAT or ActiveDirectory module is needed. It uses LDAP (TCP 389) to the domain controller.

### 5.2 Python

```bash
pip install ldap3
python python\pii_scanner.py --ad --ad-server dc01.client.local --ad-user CLIENT\pii_auditor
python python\pii_scanner.py --ad --ad-server dc01.client.local --ad-user CLIENT\pii_auditor --ad-base "OU=Staff,DC=client,DC=local" --ad-ldaps
```

The password is prompted, or read from the `PII_AD_PASSWORD` environment variable. `--ad-ldaps` uses LDAPS (TCP 636).

AD findings appear in the HTML report under **Active Directory** and in `_findings.csv` with `Source = ActiveDirectory`.

---

## 6. Reading the results

Each scan writes four files named `PII_<HOST>_<date>_<time>_*`:

| File | Use it for |
|---|---|
| `_report.html` | Executive view: totals, files ranked by risk, AD section |
| `_findings.csv` | One row per (sampled) match: type, category, severity, confidence, masked value, location in the file. Filter it in Excel. |
| `_files.csv` | Every file examined: classification, PHI flag, risk score, counts, and **status** (shows skipped or unreadable files) |
| `_summary.json` | Machine-readable result, used for merging |

### 6.1 Classification labels

| Label | Meaning | Typical action |
|---|---|---|
| **Restricted** | Contains Critical identifiers (Aadhaar, PAN, ABHA, card, passport, SSN), credentials (passwords, keys), or is flagged **PHI** | Remediate first: delete, move to a secured location, encrypt |
| **Confidential** | High-severity data: bank account, IBAN, date of birth, voter ID, driving licence, UHID / MRN, ICD-10 code, insurance number | Restrict access |
| **Internal** | Only Medium/Low data: mobile, email, GSTIN, IFSC, IP | Review |

**PHI** (purple tag): the file contains a patient identifier (ABHA, UHID / MRN, PM-JAY), or health details (diagnosis code,
blood group, medical terms) **together with** a personal identifier. These files are always Restricted.

**Risk score** ranks files within a label, so files with many critical items come first.

### 6.2 Confidence

| Confidence | Meaning |
|---|---|
| **High** | Checksum-valid and well-formatted or labelled, e.g. `Aadhaar: 2345 6789 0124` |
| **Medium** | Checksum-valid, or labelled by a nearby keyword or column header |
| **Low** | Pattern only, e.g. a bare 12-digit number in a log. **Hidden by default** and counted as "suppressed". |

### 6.3 Location ("Where")

Examples of the location column:

| Value | Meaning |
|---|---|
| `line 12` | Line 12 of a text file |
| `sheet 1 line 5` | Row 5 of the first sheet of a spreadsheet |
| `attachment id_proof.docx line 1` | Inside an e-mail attachment |
| `exports/users.csv line 2` | Inside a zip archive |
| `msg 341 attachment scan.pdf page 2` | Inside a PST mailbox |

### 6.4 Masked values

Values are masked by default: `XXXX XXXX 0124`, `t***@client.in`, `Su******`. Only use `-ShowRaw` / `--show-raw` if
the client asks for clear values in writing, and protect the output accordingly.

---

## 7. Merging results from many hosts

Put every host's `*_summary.json` under one folder (subfolders are fine), then run either tool:

```powershell
.\powershell\Invoke-PIIScan.ps1 -MergeFrom .\PII_Collected -OutputDir .\Estate
```
```bash
python python\pii_scanner.py --merge .\PII_Collected --out .\Estate
```

Each tool can merge the other's results. The estate report contains:

* hosts ranked by total risk
* the top 2,000 riskiest files across all hosts
* totals by PII type and category
* AD findings
* `ESTATE_*_hosts.csv` – one row per host
* `ESTATE_*_findings.csv` – every finding from every host

---

## 8. Tuning

| Need | Option |
|---|---|
| Fewer, surer findings (executive summary) | `-MinConfidence High` / `--min-confidence high` |
| Maximum recall (forensic sweep) | `-MinConfidence Low` / `--min-confidence low` |
| Skip zip archives | `-NoArchives` / `--no-archives` |
| More sample values per file | `-MaxSamples 20` / `--max-samples 20` (default 5 per type per file) |
| Bigger files | `-MaxFileSizeMB 100` / `--max-size-mb 100`; PST limit `--max-pst-mb` (Python) |
| Custom rule set | `-RulesFile .\client_rules.json` / `--rules client_rules.json` |

**Editing rules.** All detection lives in `rules\pii_rules.json`. To make the scanner ignore a client's own dummy values
(for example a test PAN used in training material), add them to `known_test_values`. After any change to the rules,
re-run the self-test:

```powershell
python tests\make_test_data.py
.\powershell\Invoke-PIIScan.ps1 -Path tests\sample_data -OutputDir out_ps
python python\pii_scanner.py --path tests\sample_data --out out_py
python tests\check_results.py (Get-ChildItem out_ps\*_summary.json).FullName (Get-ChildItem out_py\*_summary.json).FullName
```

The last line must print `RESULT: PASS`.

---

## 9. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `running scripts is disabled on this system` | Use `powershell -ExecutionPolicy Bypass -File ...` and run `Unblock-File` (section 2.2) |
| `Cannot add type... Add-Type` / "language mode" error | Host enforces Constrained Language Mode. Use the Python scanner. |
| EDR alert about `csc.exe` started by PowerShell | Expected: the engine compiles in memory. Pre-approve with the SOC, or use Python. |
| `Rules file not found` | Keep the folder structure, or pass `-RulesFile` / `--rules` |
| `AD scan failed: Cannot reach a domain controller` | On a non-domain machine add `-ADServer dc01... -Credential ...`; check TCP 389 is reachable |
| `AD scan needs ldap3` | `pip install ldap3` |
| `SMB (445) unreachable: host` | Host is off, firewalled, or the name doesn't resolve. Try its IP address. |
| `SMB authentication to host failed (Win32 error 1326)` | Wrong username or password |
| `... (Win32 error 1219)` | You already have a connection to that host under a different account. Close it with `net use \\host\IPC$ /delete` and retry. |
| `host : 0 share(s)` | The account cannot list shares, or the host has none. Try `-IncludeAdminShares` with an admin account, or scan explicit `\\host\share` paths. |
| WinRM: `Access is denied` / `WinRM cannot complete the operation` | Account isn't local admin, WinRM is disabled, or (non-domain machine) the target isn't in `TrustedHosts` |
| `unsupported: use -IncludePst ...` | PST found. Use `-IncludePst` on a machine with an Outlook profile, or the Python scanner with `libpff-python`. |
| `unsupported: PDF needs the Python scanner` | Scan PDFs with Python and `pypdf` |
| `skipped: too large` | Raise `-MaxFileSizeMB` / `--max-size-mb` |
| Very few results on a profile folder | Not running as Administrator, so other users' folders are unreadable. Check the status column in `_files.csv`. |
| Scan is slow over the network | Run on the server itself, or use remote execution (section 4.2) |

---

## 10. Quick reference card

```powershell
# LOCAL
.\Invoke-PIIScan.ps1 -AllDrives -IncludeOwner                          # whole machine
.\Invoke-PIIScan.ps1 -Path D:\Shares -Threads 16                        # file server

# NETWORK – agentless over SMB
.\Invoke-PIIScan.ps1 -ComputerName fs01,10.0.0.5 -Credential $cred       # shares on hosts
.\Invoke-PIIScan.ps1 -ComputerListFile hosts.txt -IncludeAdminShares -Credential $cred
.\Invoke-PIIScan.ps1 -DiscoverComputersFromAD -ADServer dc01 -Credential $cred

# NETWORK – run on every host via WinRM, collect + merge automatically
.\Invoke-PIIScanRemote.ps1 -FromAD -ADSearchBase "OU=Workstations,DC=client,DC=local" -Credential $cred

# ACTIVE DIRECTORY
.\Invoke-PIIScan.ps1 -ScanAD                                            # domain-joined
.\Invoke-PIIScan.ps1 -ScanAD -ADServer dc01.client.local -Credential $cred

# MERGE
.\Invoke-PIIScan.ps1 -MergeFrom .\PII_Collected -OutputDir .\Estate
```
```bash
# PYTHON equivalents
python pii_scanner.py --all-drives
python pii_scanner.py --host fs01 --smb-user CLIENT\pii_auditor --workers 16
python pii_scanner.py --ad --ad-server dc01.client.local --ad-user CLIENT\pii_auditor
python pii_scanner.py --merge ./PII_Collected --out ./Estate
```

---

## 11. Engagement checklist

- [ ] Written authorisation covers reading file contents and AD attributes
- [ ] Dedicated audit account created (read-only; local admin only where full-disk or WinRM coverage is needed)
- [ ] SOC / EDR team informed: scan window, source IPs, `csc.exe` from PowerShell
- [ ] Self-test passes on your copy (section 8)
- [ ] Pilot on one test host before the full rollout
- [ ] Report output stored on an access-controlled share; plan for its secure deletion after the engagement
- [ ] Remove the audit account and any WinRM / firewall exceptions created for the engagement
