#!/usr/bin/env python3
"""
PII / PHI Discovery & Classification Scanner  (Python edition, v2)

Finds personally identifiable information (PII) and Indian personal health information (PHI)
on local drives, UNC/SMB shares, remote hosts' shares and Active Directory, classifies every
file (Restricted / Confidential / Internal) and writes HTML / CSV / JSON reports.
Raw values are masked by default.

Detection rules live in ../rules/pii_rules.json and are shared with Invoke-PIIScan.ps1.

Core needs only the standard library. Optional extras:
    pip install pypdf             PDF text
    pip install libpff-python     Outlook .pst / .ost mailboxes
    pip install ldap3             Active Directory attribute scan
    pip install pywin32           file owner column (--include-owner)

Examples:
    python pii_scanner.py --path C:\\Users --path \\\\fs01\\HR
    python pii_scanner.py --host fs01 --host 10.10.20.15 --smb-user CORP\\auditor --include-admin-shares
    python pii_scanner.py --ad --ad-server dc01.corp.local --ad-user CORP\\auditor
    python pii_scanner.py --merge .\\collected --out .\\estate_report
"""
from __future__ import annotations

import argparse
import bisect
import csv
import datetime as dt
import getpass
import glob
import html
import io
import json
import multiprocessing as mp
import os
import re
import socket
import struct
import subprocess
import sys
import time
import zipfile
from dataclasses import dataclass
from typing import Iterable, Iterator, Optional

__version__ = "2.0.0"
SCHEMA = "pii-scan/2"
HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_RULES = os.path.normpath(os.path.join(HERE, "..", "rules", "pii_rules.json"))
CONF_NAME = {1: "Low", 2: "Medium", 3: "High"}
CONF_VALUE = {"low": 1, "medium": 2, "high": 3}
_ASCII_LOWER = str.maketrans("ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz")  # length-preserving

# =========================================================================== #
# Validators
# =========================================================================== #
_VD = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 0, 6, 7, 8, 9, 5], [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
       [3, 4, 0, 1, 2, 8, 9, 5, 6, 7], [4, 0, 1, 2, 3, 9, 5, 6, 7, 8], [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
       [6, 5, 9, 8, 7, 1, 0, 4, 3, 2], [7, 6, 5, 9, 8, 2, 1, 0, 4, 3], [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
       [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]]
_VP = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 5, 7, 6, 2, 8, 3, 0, 9, 4], [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
       [8, 9, 1, 6, 0, 4, 3, 5, 2, 7], [9, 4, 5, 3, 1, 2, 6, 8, 7, 0], [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
       [2, 7, 9, 3, 8, 0, 6, 4, 1, 5], [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]]
_NON_DIGIT = re.compile(r"[^0-9]")
_ASC, _DESC = "01234567890123456789", "98765432109876543210"


def _digits(s: str) -> str:
    return _NON_DIGIT.sub("", s)


def verhoeff_ok(d: str) -> bool:
    c = 0
    for i, ch in enumerate(reversed(d)):
        c = _VD[c][_VP[i % 8][ord(ch) - 48]]
    return c == 0


def luhn_ok(d: str) -> bool:
    total, alt = 0, False
    for ch in reversed(d):
        n = ord(ch) - 48
        if alt:
            n = n * 2 - 9 if n > 4 else n * 2
        total += n
        alt = not alt
    return total % 10 == 0


def is_repetitive(d: str) -> bool:
    return len(set(d)) <= 2 or d in _ASC or d in _DESC


def v_not_repetitive(v: str) -> bool:
    d = _digits(v)
    return not d or not is_repetitive(d)


# Visa 4 | Mastercard 51-55, 22-27 | Maestro 50, 56-58, 6x | RuPay 60, 65, 81, 82, 508, 353, 356
# Amex 34/37 | Diners 30, 36, 38, 39 | JCB 35 | Discover 6011/64/65
_CARD_PREFIX = re.compile(r"^(?:4|5[0-8]|2[2-7]|3[0-9]|6|8[12])")


def v_credit_card(v: str) -> bool:
    d = _digits(v)
    return 13 <= len(d) <= 19 and not is_repetitive(d) and bool(_CARD_PREFIX.match(d)) and luhn_ok(d)


def v_aadhaar(v: str) -> bool:
    d = _digits(v)
    return len(d) == 12 and not is_repetitive(d) and verhoeff_ok(d)


def v_iban(v: str) -> bool:
    s = re.sub(r"\s", "", v).upper()
    if not 15 <= len(s) <= 34:
        return False
    r = s[4:] + s[:4]
    rem = 0
    for ch in r:
        for dc in (ch if ch.isdigit() else str(ord(ch) - 55)):
            rem = (rem * 10 + ord(dc) - 48) % 97
    return rem == 1


def v_ipv4(v: str) -> bool:
    p = v.split(".")
    if len(p) != 4 or any(int(x) > 255 for x in p):
        return False
    first = int(p[0])
    return 1 <= first <= 223 and first != 127 and v != "255.255.255.255"


def v_has_digit(v: str) -> bool:
    return any(c.isdigit() for c in v)


_PWD_PLACEHOLDERS = {"password", "passwd", "true", "false", "null", "none", "required", "string", "optional",
                     "empty", "yourpassword", "your_password", "mypassword", "redacted", "hidden", "masked",
                     "n/a", "xxxx", "xxxxxx", "xxxxxxxx", "secret", "changeme_placeholder", "undefined"}


def v_password(v: str) -> bool:
    low = v.lower()
    if set(v) <= set("*x#\u2022.X"):
        return False
    if v[0] in "$%{[(<@\\" or low in _PWD_PLACEHOLDERS:
        return False
    return not any(t in low for t in ("read-host", "getenv", "environ", "securestring", "get-credential", "{{", "${"))


_DL_STATES = set("AN AP AR AS BR CG CH DD DL DN GA GJ HP HR JH JK KA KL LA LD MH ML MN MP MZ NL OD OR PB PY "
                 "RJ SK TN TR TS UK UP WB".split())


def v_dl_state(v: str) -> bool:
    return v[:2].upper() in _DL_STATES


_MONTHS = {m: i for i, m in enumerate("jan feb mar apr may jun jul aug sep oct nov dec".split(), 1)}


def _ymd_ok(y: int, m: int, d: int) -> bool:
    try:
        x = dt.date(y, m, d)
    except ValueError:
        return False
    return y >= 1900 and x <= dt.date.today()


def v_date(v: str) -> bool:
    s = v.strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", s)
    if m:
        return _ymd_ok(int(m[1]), int(m[2]), int(m[3]))
    m = re.match(r"^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$", s)
    if m:
        a, b, y = int(m[1]), int(m[2]), int(m[3])
        return _ymd_ok(y, b, a) or _ymd_ok(y, a, b)
    m = re.match(r"^(\d{1,2})[ -]([A-Za-z]+)[ ,-]+(\d{4})$", s)
    if m:
        mon = _MONTHS.get(m[2][:3].lower())
        return bool(mon) and _ymd_ok(int(m[3]), mon, int(m[1]))
    return False


_B36 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def v_gstin(v: str) -> bool:
    v = v.upper()
    st = int(v[:2])
    if not (1 <= st <= 38 or st in (97, 99)):
        return False
    total = 0
    for i, ch in enumerate(v[:14]):
        p = _B36.index(ch) * (2 if i % 2 else 1)
        total += p // 36 + p % 36
    return _B36[(36 - total % 36) % 36] == v[14]


_NON_TLD = {"png", "jpg", "jpeg", "gif", "svg", "webp", "bmp", "ico", "css", "js", "ts", "map", "woff", "woff2"}
_ROLE_MAIL = {"noreply", "no-reply", "donotreply", "do-not-reply", "postmaster", "mailer-daemon", "abuse",
              "webmaster", "hostmaster"}


def v_email(v: str) -> bool:
    local, _, dom = v.rpartition("@")
    return dom.rsplit(".", 1)[-1].lower() not in _NON_TLD and local.lower() not in _ROLE_MAIL


VALIDATORS = {
    "not_repetitive": v_not_repetitive, "credit_card": v_credit_card, "aadhaar": v_aadhaar, "iban": v_iban,
    "ipv4": v_ipv4, "has_digit": v_has_digit, "password": v_password, "dl_state": v_dl_state, "date": v_date,
    "gstin": v_gstin, "email": v_email,
}


# =========================================================================== #
# Rules
# =========================================================================== #
@dataclass
class Rule:
    name: str
    category: str
    severity: str
    rx: re.Pattern
    group: int
    validator: Optional[object]
    kind: str
    base: int
    context: tuple
    ctx_required: bool
    ctx_window: int
    neg_context: tuple
    fmt_rx: Optional[re.Pattern]
    trigger: tuple
    on_lower: bool = False   # (?i) rule written in lower case: match the pre-lowercased text (much faster in Python)


class RuleSet:
    def __init__(self, path: str):
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
        self.version = cfg["version"]
        self.weights = cfg["severity_weight"]
        self.classification = cfg["classification"]
        self.phi = cfg["phi"]
        self.default_min_conf = cfg.get("default_min_confidence", 2)
        self.neg_window = cfg.get("neg_context_window", 20)
        self.known = {re.sub(r"[^0-9A-Z]", "", x.upper()) for x in cfg.get("known_test_values", [])}
        win = cfg.get("context_window", 60)
        self.rules: list[Rule] = []
        for r in cfg["rules"]:
            val = r.get("validator")
            if val and val not in VALIDATORS:
                raise ValueError(f"rule {r['name']}: unknown validator {val}")
            pat = r["pattern"]
            # A case-insensitive pattern with no upper-case literals (escapes like \S excepted) gives identical spans
            # when run case-sensitively over the ASCII-lowercased text (same length), and is ~5x faster in CPython.
            on_lower = pat.startswith("(?i)") and not re.search(r"(?<!\\)[A-Z]", pat[4:])
            self.rules.append(Rule(
                name=r["name"], category=r["category"], severity=r["severity"],
                rx=re.compile(pat[4:] if on_lower else pat), on_lower=on_lower,
                group=r.get("group", 0), validator=VALIDATORS.get(val) if val else None, kind=r.get("kind", "id"),
                base=r.get("base_confidence", 2), context=tuple(k.lower() for k in r.get("context", [])),
                ctx_required=r.get("context_required", False), ctx_window=r.get("context_window", win),
                neg_context=tuple(k.lower() for k in r.get("neg_context", [])),
                fmt_rx=re.compile(r["format_boost"]) if r.get("format_boost") else None,
                trigger=tuple(t.lower() for t in r.get("trigger", []))))
        self.sev = {r.name: r.severity for r in self.rules}
        self.cat = {r.name: r.category for r in self.rules}
        self.kind = {r.name: r.kind for r in self.rules}


def scan_text(text: str, rs: RuleSet, min_conf: int) -> tuple[list, int]:
    """Returns ([(rule, value, line, confidence)], suppressed_count)."""
    if not text:
        return [], 0
    lower = text.translate(_ASCII_LOWER)
    starts: list[int] = []
    ends: list[int] = []
    out = []
    suppressed = 0
    newlines = None
    for rule in rs.rules:
        if rule.trigger and not any(t in lower for t in rule.trigger):
            continue
        if rule.ctx_required and not any(k in lower for k in rule.context):
            continue
        g = rule.group
        for m in rule.rx.finditer(lower if rule.on_lower else text):
            s, e = m.span(g)
            i = bisect.bisect_right(starts, s)
            if (i and ends[i - 1] > s) or (i < len(starts) and starts[i] < e):
                continue
            v = text[s:e]
            if rule.validator and not rule.validator(v):
                continue
            conf = rule.base
            if rule.context:
                hit = any(k in lower[max(0, s - rule.ctx_window):s] for k in rule.context)
                if rule.ctx_required and not hit:
                    continue
                if hit and not rule.ctx_required:
                    conf += 1
            if rule.neg_context and any(k in lower[max(0, s - rs.neg_window):s] for k in rule.neg_context):
                continue
            if rule.fmt_rx and rule.fmt_rx.search(v):
                conf += 1
            if rs.known and re.sub(r"[^0-9A-Z]", "", v.upper()) in rs.known:
                conf = 1
            conf = min(conf, 3)
            if conf < min_conf:
                suppressed += 1
                continue
            starts.insert(i, s)
            ends.insert(i, e)
            if newlines is None:
                newlines = [x.start() for x in re.finditer("\n", text)]
            out.append((rule, v, bisect.bisect_right(newlines, s) + 1, conf))
    return out, suppressed


def mask(value: str, kind: str) -> str:
    v = value.strip()
    if kind == "term":
        return v
    if kind == "email" and "@" in v:
        user, dom = v.split("@", 1)
        return (user[:1] + "***@" + dom) if user else "***@" + dom
    if kind == "secret":
        return (v[:2] + "*" * 6) if len(v) > 6 else "******"
    if len(v) <= 4:
        return "*" * len(v)
    out, keep = [], 4
    for ch in reversed(v):
        if ch.isalnum() and keep > 0:
            out.append(ch)
            keep -= 1
        elif ch.isalnum():
            out.append("X")
        else:
            out.append(ch)
    return "".join(reversed(out))


# =========================================================================== #
# Text extraction  (all extractors work on bytes so they can recurse into
# e-mail attachments and archive members)
# =========================================================================== #
TEXT_EXT = {".txt", ".log", ".json", ".xml", ".html", ".htm", ".md", ".ini", ".cfg", ".conf", ".config",
            ".yaml", ".yml", ".sql", ".ps1", ".psm1", ".py", ".bat", ".cmd", ".sh", ".properties", ".env",
            ".eml", ".rtf", ".vcf", ".ldif", ".reg", ".js", ".ts", ".java", ".cs", ".php", ".hl7"}
CSV_EXT = {".csv", ".tsv"}
OOXML_EXT = {".docx", ".docm", ".xlsx", ".xlsm", ".pptx", ".pptm"}
ODF_EXT = {".odt", ".ods", ".odp"}
LEGACY_EXT = {".doc", ".xls", ".ppt", ".msg"}
PDF_EXT = {".pdf"}
PST_EXT = {".pst", ".ost"}
ZIP_EXT = {".zip"}
ALL_EXT = TEXT_EXT | CSV_EXT | OOXML_EXT | ODF_EXT | LEGACY_EXT | PDF_EXT | PST_EXT | ZIP_EXT
TEXTLIKE = TEXT_EXT | CSV_EXT
DEFAULT_EXCLUDE_DIRS = {"windows", "program files", "program files (x86)", "$recycle.bin",
                        "system volume information", "programdata", "appdata", "node_modules", ".git", "winsxs",
                        "$windows.~bt", "$windows.~ws", "__pycache__", ".venv", "site-packages"}
MAX_DEPTH = 2
_TAG = re.compile(r"<[^>]+>")
_BLOCK_END = re.compile(r"</(?:w:p|a:p|text:p|table:table-row|tr|p|div|br)>|<br\s*/?>", re.I)

try:
    from pypdf import PdfReader  # type: ignore
except Exception:  # pragma: no cover
    PdfReader = None
try:
    import pypff  # type: ignore
except Exception:  # pragma: no cover
    pypff = None


def decode_bytes(b: bytes) -> str:
    if b.startswith(b"\xef\xbb\xbf"):
        return b[3:].decode("utf-8", "ignore")
    if b.startswith((b"\xff\xfe", b"\xfe\xff")):
        return b.decode("utf-16", "ignore")
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("cp1252", "ignore")


def strip_markup(xml: str) -> str:
    return html.unescape(_TAG.sub(" ", _BLOCK_END.sub("\n", xml)))


def rows_to_text(rows: list[list[str]]) -> str:
    """Render a table as 'Header: value | Header: value' so column headers act as detection context."""
    rows = [r for r in rows if any(c.strip() for c in r)]
    if not rows:
        return ""
    header = [h.strip() for h in rows[0]]
    named = [h for h in header if h]
    use_header = bool(named) and sum(1 for h in named if not any(c.isdigit() for c in h)) * 2 >= len(named)
    out = [" | ".join(rows[0])]
    for r in rows[1:]:
        if use_header:
            out.append(" | ".join(f"{header[i] if i < len(header) and header[i] else 'col' + str(i + 1)}: {c}"
                                  for i, c in enumerate(r) if c.strip()))
        else:
            out.append(" | ".join(r))
    return "\n".join(out)


def norm_number(v: str) -> str:
    if "E" in v or "e" in v or v.endswith(".0"):
        try:
            f = float(v)
            if f.is_integer() and abs(f) < 1e16:
                return str(int(f))
        except ValueError:
            pass
    return v


def csv_text(b: bytes, ext: str) -> str:
    text = decode_bytes(b)
    delim = "\t" if ext == ".tsv" else ","
    if ext == ".csv":
        try:
            delim = csv.Sniffer().sniff(text[:4096], delimiters=",;|\t").delimiter
        except csv.Error:
            pass
    csv.field_size_limit(min(sys.maxsize, 2 ** 31 - 1))
    return rows_to_text(list(csv.reader(io.StringIO(text), delimiter=delim)))


# ----- OOXML / ODF --------------------------------------------------------- #
def _col_index(ref: str) -> int:
    n = 0
    for ch in ref:
        if "A" <= ch <= "Z":
            n = n * 26 + ord(ch) - 64
        else:
            break
    return max(n - 1, 0)


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def xlsx_segments(z: zipfile.ZipFile) -> Iterator[tuple[str, str]]:
    import xml.etree.ElementTree as ET
    shared: list[str] = []
    if "xl/sharedStrings.xml" in z.namelist():
        for _, el in ET.iterparse(io.BytesIO(z.read("xl/sharedStrings.xml"))):
            if _local(el.tag) == "si":
                shared.append("".join(t.text or "" for t in el.iter() if _local(t.tag) == "t"))
                el.clear()
    sheets = sorted((n for n in z.namelist() if n.startswith("xl/worksheets/sheet") and n.endswith(".xml")),
                    key=lambda n: int(re.sub(r"\D", "", n) or 0))
    for name in sheets:
        rows: list[list[str]] = []
        for _, el in ET.iterparse(io.BytesIO(z.read(name))):
            if _local(el.tag) != "row":
                continue
            cells: dict[int, str] = {}
            for c in el:
                if _local(c.tag) != "c":
                    continue
                t = c.get("t")
                idx = _col_index(c.get("r", "A"))
                val = ""
                for sub in c:
                    tag = _local(sub.tag)
                    if tag == "v" and sub.text is not None:
                        val = sub.text
                    elif tag == "is":
                        val = "".join(x.text or "" for x in sub.iter() if _local(x.tag) == "t")
                if t == "s" and val.isdigit() and int(val) < len(shared):
                    val = shared[int(val)]
                elif t not in ("s", "inlineStr", "str"):
                    val = norm_number(val)
                cells[idx] = val
            el.clear()
            if cells:
                rows.append([cells.get(i, "") for i in range(max(cells) + 1)])
        yield f"sheet {os.path.basename(name)[5:-4]}", rows_to_text(rows)


def ooxml_segments(b: bytes, ext: str) -> Iterator[tuple[str, str]]:
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        if ext in (".xlsx", ".xlsm"):
            yield from xlsx_segments(z)
            return
        parts = []
        for n in z.namelist():
            if n.endswith(".xml") and (n.startswith(("word/document", "word/header", "word/footer", "word/comments",
                                                     "word/footnotes", "ppt/slides/slide", "ppt/notesSlides/"))):
                parts.append(strip_markup(z.read(n).decode("utf-8", "ignore")))
        yield "", "\n".join(parts)


def odf_segments(b: bytes) -> Iterator[tuple[str, str]]:
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        yield "", strip_markup(z.read("content.xml").decode("utf-8", "ignore"))


# ----- Compound File Binary (OLE2) - used by .doc .xls .ppt .msg ---------- #
_ENDCHAIN = 0xFFFFFFFA  # anything >= this is a special marker
_NOSTREAM = 0xFFFFFFFF


class CFB:
    """Minimal read-only parser for [MS-CFB] compound files."""

    def __init__(self, data: bytes):
        if data[:8] != b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1":
            raise ValueError("not a compound file")
        self.d = data
        self.ss = 1 << struct.unpack_from("<H", data, 0x1E)[0]
        self.mss = 1 << struct.unpack_from("<H", data, 0x20)[0]
        nfat, dir_start = struct.unpack_from("<II", data, 0x2C)
        self.cutoff, minifat_start, _nmini, difat_start, _ndifat = struct.unpack_from("<IIIII", data, 0x38)
        difat = list(struct.unpack_from("<109I", data, 0x4C))
        per = self.ss // 4
        s, guard = difat_start, 0
        while s < _ENDCHAIN and guard < 10000:
            ent = struct.unpack_from(f"<{per}I", data, (s + 1) * self.ss)
            difat.extend(ent[:-1])
            s = ent[-1]
            guard += 1
        self.fat: list[int] = []
        for sec in [x for x in difat if x < _ENDCHAIN][:nfat]:
            off = (sec + 1) * self.ss
            if off + self.ss <= len(data):
                self.fat.extend(struct.unpack_from(f"<{per}I", data, off))
        dirb = self._chain(dir_start)
        self.entries = []
        for i in range(len(dirb) // 128):
            e = dirb[i * 128:(i + 1) * 128]
            nlen = struct.unpack_from("<H", e, 0x40)[0]
            name = e[:max(0, min(nlen, 64) - 2)].decode("utf-16-le", "ignore")
            typ = e[0x42]
            left, right, child = struct.unpack_from("<III", e, 0x44)
            start, size = struct.unpack_from("<II", e, 0x74)
            self.entries.append((name, typ, left, right, child, start, size))
        root = self.entries[0]
        self.ministream = self._chain(root[5])[:root[6]] if root[6] else b""
        mf = self._chain(minifat_start) if minifat_start < _ENDCHAIN else b""
        self.minifat = list(struct.unpack_from(f"<{len(mf) // 4}I", mf)) if mf else []
        self.streams: dict[str, tuple[int, int]] = {}
        stack, seen = [(root[4], "")], set()
        while stack:
            i, prefix = stack.pop()
            if i == _NOSTREAM or i >= len(self.entries) or i in seen:
                continue
            seen.add(i)
            name, typ, left, right, child, start, size = self.entries[i]
            stack.append((left, prefix))
            stack.append((right, prefix))
            if typ == 2:
                self.streams[prefix + name] = (start, size)
            elif typ == 1:
                stack.append((child, prefix + name + "/"))

    def _chain(self, start: int) -> bytes:
        out, s, n = bytearray(), start, 0
        while s < _ENDCHAIN and s < len(self.fat) and n <= len(self.fat):
            off = (s + 1) * self.ss
            out += self.d[off:off + self.ss]
            s, n = self.fat[s], n + 1
        return bytes(out)

    def read(self, path: str) -> bytes:
        start, size = self.streams[path]
        if size < self.cutoff:
            out, s, n = bytearray(), start, 0
            while s < _ENDCHAIN and s < len(self.minifat) and n <= len(self.minifat) and len(out) < size:
                out += self.ministream[s * self.mss:(s + 1) * self.mss]
                s, n = self.minifat[s], n + 1
            return bytes(out[:size])
        return self._chain(start)[:size]

    def find(self, *names: str) -> Optional[str]:
        low = {k.lower(): k for k in self.streams}
        for n in names:
            if n.lower() in low:
                return low[n.lower()]
        return None


_U16RUN = re.compile(rb"(?:[\x20-\x7e\t\r\n]\x00|[\x00-\x7f]\x09){4,}")
_A8RUN = re.compile(rb"[\x20-\x7e\t\r\n]{4,}")


def binary_text_runs(b: bytes) -> str:
    parts = [m.group().decode("utf-16-le", "ignore") for m in _U16RUN.finditer(b)]
    parts += [m.group().decode("latin-1") for m in _A8RUN.finditer(b)]
    return "\n".join(p.replace("\r", "\n") for p in parts)


def _rk(v: int) -> float:
    if v & 2:
        val = float(struct.unpack("<i", struct.pack("<I", v))[0] >> 2)
    else:
        val = struct.unpack("<d", struct.pack("<Q", (v & 0xFFFFFFFC) << 32))[0]
    return val / 100 if v & 1 else val


def _fmt_num(f: float) -> str:
    return str(int(f)) if f == f and f.is_integer() and abs(f) < 1e16 else repr(f)


def _xl_unicode(data: bytes, pos: int, cch_size: int = 2) -> str:
    cch = data[pos] if cch_size == 1 else struct.unpack_from("<H", data, pos)[0]
    pos += cch_size
    flags = data[pos]
    pos += 1
    if flags & 1:
        return data[pos:pos + cch * 2].decode("utf-16-le", "ignore")
    return data[pos:pos + cch].decode("latin-1")


def _parse_sst(chunks: list[bytes]) -> list[str]:
    out: list[str] = []
    ci, pos = 0, 8

    def need(n):
        nonlocal ci, pos
        buf = bytearray()
        while n > 0:
            while ci < len(chunks) and pos >= len(chunks[ci]):
                ci, pos = ci + 1, 0
            if ci >= len(chunks):
                raise EOFError
            take = min(n, len(chunks[ci]) - pos)
            buf += chunks[ci][pos:pos + take]
            pos += take
            n -= take
        return bytes(buf)

    try:
        total = struct.unpack_from("<I", chunks[0], 4)[0]
        while len(out) < total:
            cch = struct.unpack("<H", need(2))[0]
            flags = need(1)[0]
            high = flags & 1
            runs = struct.unpack("<H", need(2))[0] if flags & 8 else 0
            ext = struct.unpack("<I", need(4))[0] if flags & 4 else 0
            parts, left = [], cch
            while left > 0:
                if pos >= len(chunks[ci]):  # string continues in next CONTINUE record: new flag byte
                    ci, pos = ci + 1, 0
                    if ci >= len(chunks):
                        raise EOFError
                    high = chunks[ci][0] & 1
                    pos = 1
                width = 2 if high else 1
                take = min(left, (len(chunks[ci]) - pos) // width)
                if take <= 0:
                    raise EOFError
                raw = chunks[ci][pos:pos + take * width]
                parts.append(raw.decode("utf-16-le" if high else "latin-1", "ignore"))
                pos += take * width
                left -= take
            out.append("".join(parts))
            if runs or ext:
                need(runs * 4 + ext)
    except (EOFError, struct.error):
        pass
    return out


def xls_segments(cfb: CFB) -> Iterator[tuple[str, str]]:
    name = cfb.find("Workbook", "Book")
    if not name:
        return
    wb = cfb.read(name)
    recs, pos = [], 0
    while pos + 4 <= len(wb):
        typ, ln = struct.unpack_from("<HH", wb, pos)
        recs.append((typ, wb[pos + 4:pos + 4 + ln]))
        pos += 4 + ln
    sst: list[str] = []
    sheets: list[dict] = []
    cur: Optional[dict] = None
    pending_formula = None
    i = 0
    while i < len(recs):
        typ, data = recs[i]
        try:
            if typ == 0x0809 and len(data) >= 4:  # BOF
                cur = {} if struct.unpack_from("<H", data, 2)[0] == 0x0010 else None
                if cur is not None:
                    sheets.append(cur)
            elif typ == 0x00FC:  # SST (+ CONTINUE)
                chunks = [data]
                while i + 1 < len(recs) and recs[i + 1][0] == 0x003C:
                    i += 1
                    chunks.append(recs[i][1])
                sst = _parse_sst(chunks)
            elif cur is not None and len(data) >= 6:
                row, col = struct.unpack_from("<HH", data, 0)
                if typ == 0x00FD:  # LABELSST
                    idx = struct.unpack_from("<I", data, 6)[0]
                    cur[(row, col)] = sst[idx] if idx < len(sst) else ""
                elif typ == 0x0204:  # LABEL
                    cur[(row, col)] = _xl_unicode(data, 6)
                elif typ == 0x0203:  # NUMBER
                    cur[(row, col)] = _fmt_num(struct.unpack_from("<d", data, 6)[0])
                elif typ == 0x027E:  # RK
                    cur[(row, col)] = _fmt_num(_rk(struct.unpack_from("<I", data, 6)[0]))
                elif typ == 0x00BD:  # MULRK
                    n = (len(data) - 6) // 6
                    for k in range(n):
                        cur[(row, col + k)] = _fmt_num(_rk(struct.unpack_from("<I", data, 4 + k * 6 + 2)[0]))
                elif typ == 0x0006 and len(data) >= 14:  # FORMULA
                    if data[12:14] == b"\xff\xff":
                        pending_formula = (row, col) if data[6] == 0 else None
                    else:
                        cur[(row, col)] = _fmt_num(struct.unpack_from("<d", data, 6)[0])
            if typ == 0x0207 and cur is not None and pending_formula:  # STRING (formula result)
                cur[pending_formula] = _xl_unicode(data, 0)
                pending_formula = None
        except (struct.error, IndexError):
            pass
        i += 1
    for n, cells in enumerate(sheets, 1):
        if not cells:
            continue
        maxr = max(r for r, _ in cells)
        maxc = max(c for _, c in cells)
        rows = [[cells.get((r, c), "") for c in range(maxc + 1)] for r in range(maxr + 1)]
        yield f"sheet {n}", rows_to_text(rows)


def msg_segments(cfb: CFB, depth: int) -> Iterator[tuple[str, str]]:
    texts, attach = [], {}
    for path in cfb.streams:
        top, _, leaf = path.rpartition("/")
        if top.startswith("__attach_version1.0_"):
            attach.setdefault(top, {})[leaf] = path
            continue
        try:
            if leaf.endswith("001F"):
                texts.append(cfb.read(path).decode("utf-16-le", "ignore"))
            elif leaf.endswith("001E"):
                texts.append(cfb.read(path).decode("cp1252", "ignore"))
            elif leaf.startswith("__substg1.0_1013"):
                texts.append(strip_markup(decode_bytes(cfb.read(path))))
        except (KeyError, struct.error):
            pass
    yield "", "\n".join(t.replace("\x00", "") for t in texts)
    for storage, members in attach.items():
        data_p = members.get("__substg1.0_37010102")
        if not data_p:
            continue
        fname = ""
        for k in ("__substg1.0_3707001F", "__substg1.0_3704001F"):
            if k in members:
                fname = cfb.read(members[k]).decode("utf-16-le", "ignore").strip("\x00")
                break
        data = cfb.read(data_p)
        ext = os.path.splitext(fname)[1].lower() or sniff_ext(data)
        for p, t in extract_segments(data, ext, depth + 1):
            yield f"attachment {fname or storage}{(' ' + p) if p else ''}", t


def legacy_segments(b: bytes, ext: str, depth: int) -> Iterator[tuple[str, str]]:
    cfb = CFB(b)
    if ext == ".xls":
        yield from xls_segments(cfb)
    elif ext == ".msg":
        yield from msg_segments(cfb, depth)
    else:
        name = cfb.find("WordDocument") if ext == ".doc" else cfb.find("PowerPoint Document")
        if name:
            yield "", binary_text_runs(cfb.read(name))


def sniff_ext(b: bytes) -> str:
    if b[:4] == b"PK\x03\x04":
        try:
            with zipfile.ZipFile(io.BytesIO(b)) as z:
                names = z.namelist()
            if any(n.startswith("word/") for n in names):
                return ".docx"
            if any(n.startswith("xl/") for n in names):
                return ".xlsx"
            if any(n.startswith("ppt/") for n in names):
                return ".pptx"
        except zipfile.BadZipFile:
            return ""
        return ".zip"
    if b[:8] == b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1":
        try:
            c = CFB(b)
            if c.find("WordDocument"):
                return ".doc"
            if c.find("Workbook", "Book"):
                return ".xls"
            if c.find("PowerPoint Document"):
                return ".ppt"
            if any(s.startswith("__substg1.0_") for s in c.streams):
                return ".msg"
        except Exception:  # noqa: BLE001
            return ""
    if b[:5] == b"%PDF-":
        return ".pdf"
    sample = b[:2048]
    if sample and sum(1 for x in sample if x < 9 or 13 < x < 32) < len(sample) * 0.02:
        return ".txt"
    return ""


def zip_segments(b: bytes, depth: int, max_bytes: int) -> Iterator[tuple[str, str]]:
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        for info in z.infolist():
            ext = os.path.splitext(info.filename)[1].lower()
            if info.is_dir() or ext not in ALL_EXT - PST_EXT or info.file_size > max_bytes:
                continue
            try:
                data = z.read(info)
            except (RuntimeError, zipfile.BadZipFile, NotImplementedError):  # encrypted / unsupported
                continue
            for p, t in extract_segments(data, ext, depth + 1, max_bytes):
                yield f"{info.filename}{(' ' + p) if p else ''}", t


def extract_segments(b: bytes, ext: str, depth: int = 0, max_bytes: int = 25 << 20) -> Iterator[tuple[str, str]]:
    if depth > MAX_DEPTH:
        return
    if ext in TEXT_EXT:
        yield "", decode_bytes(b)
    elif ext in CSV_EXT:
        yield "", csv_text(b, ext)
    elif ext in OOXML_EXT:
        yield from ooxml_segments(b, ext)
    elif ext in ODF_EXT:
        yield from odf_segments(b)
    elif ext in LEGACY_EXT:
        yield from legacy_segments(b, ext, depth)
    elif ext in PDF_EXT and PdfReader is not None:
        reader = PdfReader(io.BytesIO(b))
        for n, page in enumerate(reader.pages, 1):
            yield f"page {n}", page.extract_text() or ""
    elif ext in ZIP_EXT:
        yield from zip_segments(b, depth, max_bytes)


def pst_segments(path: str, max_bytes: int) -> Iterator[tuple[str, str]]:
    f = pypff.file()
    f.open(path)
    try:
        stack, n = [f.get_root_folder()], 0
        while stack:
            fo = stack.pop()
            for i in range(fo.number_of_sub_folders):
                stack.append(fo.get_sub_folder(i))
            for i in range(fo.number_of_sub_messages):
                try:
                    m = fo.get_sub_message(i)
                except Exception:  # noqa: BLE001
                    continue
                n += 1
                parts = []
                for attr in ("subject", "sender_name", "transport_headers"):
                    try:
                        parts.append(str(getattr(m, attr) or ""))
                    except Exception:  # noqa: BLE001
                        pass
                for attr in ("plain_text_body", "html_body"):
                    try:
                        body = getattr(m, attr)
                    except Exception:  # noqa: BLE001
                        body = None
                    if body:
                        t = decode_bytes(body) if isinstance(body, bytes) else str(body)
                        parts.append(strip_markup(t) if attr == "html_body" else t)
                yield f"msg {n}", "\n".join(parts)
                for j in range(getattr(m, "number_of_attachments", 0)):
                    try:
                        a = m.get_attachment(j)
                        size = a.get_size()
                        if not size or size > max_bytes:
                            continue
                        data = a.read_buffer(size)
                        name = ""
                        for na in ("name", "long_filename", "filename"):
                            name = getattr(a, na, "") or ""
                            if name:
                                break
                        ext = os.path.splitext(name)[1].lower() or sniff_ext(data)
                        for p, t in extract_segments(data, ext, 1, max_bytes):
                            yield f"msg {n} attachment {name or j}{(' ' + p) if p else ''}", t
                    except Exception:  # noqa: BLE001
                        continue
    finally:
        f.close()


# =========================================================================== #
# File scanning & classification
# =========================================================================== #
def classify(res: dict, rs: RuleSet, health_terms: set) -> None:
    ph = rs.phi
    counts = res["counts"]
    types = set(counts)
    has_id = bool(types & set(ph["identifier_rules"]))
    evidence = bool(types & set(ph["evidence_rules"])) or len(health_terms) >= ph["min_distinct_health_terms"]
    personal = any(rs.cat.get(t) in ph["personal_categories"] for t in types)
    res["phi"] = has_id or (evidence and personal)
    scoring = {t: c for t, c in counts.items() if res["phi"] or t != ph["health_term_rule"]}
    res["risk_score"] = sum(rs.weights[rs.sev[t]] * c for t, c in scoring.items()) + (ph["risk_bonus"] if res["phi"] else 0)
    res["top_severity"] = next((s for s in ("Critical", "High", "Medium", "Low")
                                if any(rs.sev[t] == s for t in scoring)), "")
    res["classification"] = "Restricted" if res["phi"] else rs.classification.get(res["top_severity"], "")


def new_result(path: str, size: int, modified: str) -> dict:
    return {"path": path, "size": size, "modified": modified, "owner": "", "status": "ok", "classification": "",
            "top_severity": "", "risk_score": 0, "phi": False, "counts": {}, "suppressed": 0, "findings": []}


def scan_segments(res: dict, segments: Iterable[tuple[str, str]], rs: RuleSet, min_conf: int, max_samples: int,
                  show_raw: bool) -> None:
    samples: dict[str, int] = {}
    health_terms: set = set()
    hterm = rs.phi["health_term_rule"]
    for prefix, text in segments:
        matches, supp = scan_text(text, rs, min_conf)
        res["suppressed"] += supp
        for rule, value, line, conf in matches:
            t = rule.name
            res["counts"][t] = res["counts"].get(t, 0) + 1
            if t == hterm:
                health_terms.add(value.lower())
            if samples.get(t, 0) < max_samples:
                samples[t] = samples.get(t, 0) + 1
                res["findings"].append({"type": t, "category": rule.category, "severity": rule.severity,
                                        "confidence": CONF_NAME[conf],
                                        "value": value if show_raw else mask(value, rule.kind),
                                        "where": f"{prefix} line {line}".strip()})
    classify(res, rs, health_terms)


_W: dict = {}


def _init_worker(rules_path: str, min_conf: int, max_bytes: int, max_pst: int, max_samples: int, show_raw: bool,
                 archives: bool) -> None:
    _W.update(rs=RuleSet(rules_path), min_conf=min_conf, max_bytes=max_bytes, max_pst=max_pst,
              max_samples=max_samples, show_raw=show_raw, archives=archives)


def scan_file(path: str) -> dict:
    w = _W
    try:
        st = os.stat(path)
    except OSError as e:
        r = new_result(path, 0, "")
        r["status"] = f"error: {e.strerror}"
        return r
    res = new_result(path, st.st_size, dt.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"))
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in PST_EXT:
            if pypff is None:
                res["status"] = "unsupported: pip install libpff-python"
                return res
            if st.st_size > w["max_pst"]:
                res["status"] = "skipped: too large"
                return res
            segs = pst_segments(path, w["max_bytes"])
        else:
            if ext in ZIP_EXT and not w["archives"]:
                res["status"] = "skipped: archives disabled"
                return res
            if ext in PDF_EXT and PdfReader is None:
                res["status"] = "unsupported: pip install pypdf"
                return res
            if st.st_size > w["max_bytes"]:
                if ext not in TEXTLIKE:
                    res["status"] = "skipped: too large"
                    return res
                res["status"] = "partial: first %d MB scanned" % (w["max_bytes"] >> 20)
            with open(path, "rb") as f:
                data = f.read(w["max_bytes"])
            segs = extract_segments(data, ext, 0, w["max_bytes"])
        scan_segments(res, segs, w["rs"], w["min_conf"], w["max_samples"], w["show_raw"])
    except Exception as e:  # noqa: BLE001
        res["status"] = f"error: {type(e).__name__}: {e}"[:300]
    return res


def walk_files(roots: Iterable[str], exclude_dirs: set) -> Iterator[str]:
    for root in roots:
        if os.path.isfile(root):
            yield root
            continue
        if not os.path.isdir(root):
            print(f"[!] not found or not accessible: {root}", file=sys.stderr)
            continue
        for dirpath, dirnames, filenames in os.walk(root, onerror=lambda e: None):
            dirnames[:] = [d for d in dirnames if d.lower() not in exclude_dirs
                           and not _is_junction(os.path.join(dirpath, d))]
            for fn in filenames:
                if os.path.splitext(fn)[1].lower() in ALL_EXT and not fn.startswith("~$"):
                    yield os.path.join(dirpath, fn)


def _is_junction(p: str) -> bool:
    try:
        return os.path.islink(p) or (hasattr(os.path, "isjunction") and os.path.isjunction(p))
    except OSError:
        return True


def file_owner(path: str) -> str:
    try:
        import win32security  # type: ignore
        sd = win32security.GetFileSecurity(path, win32security.OWNER_SECURITY_INFORMATION)
        name, dom, _ = win32security.LookupAccountSid(None, sd.GetSecurityDescriptorOwner())
        return f"{dom}\\{name}"
    except Exception:  # noqa: BLE001
        return ""


# =========================================================================== #
# Network: SMB authentication & share discovery (Windows)
# =========================================================================== #
def smb_connect(host: str, user: str, password: str) -> int:
    import ctypes
    from ctypes import wintypes

    class NETRESOURCE(ctypes.Structure):
        _fields_ = [("dwScope", wintypes.DWORD), ("dwType", wintypes.DWORD), ("dwDisplayType", wintypes.DWORD),
                    ("dwUsage", wintypes.DWORD), ("lpLocalName", wintypes.LPWSTR), ("lpRemoteName", wintypes.LPWSTR),
                    ("lpComment", wintypes.LPWSTR), ("lpProvider", wintypes.LPWSTR)]

    nr = NETRESOURCE()
    nr.lpRemoteName = f"\\\\{host}\\IPC$"
    return ctypes.windll.mpr.WNetAddConnection2W(ctypes.byref(nr), password, user, 0)


def smb_disconnect(host: str) -> None:
    import ctypes
    ctypes.windll.mpr.WNetCancelConnection2W(f"\\\\{host}\\IPC$", 0, True)


def port_open(host: str, port: int = 445, timeout: float = 1.5) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def list_shares(host: str, include_admin: bool) -> list[str]:
    try:
        out = subprocess.run(["net", "view", f"\\\\{host}", "/all"], capture_output=True, text=True, timeout=30).stdout
    except (OSError, subprocess.TimeoutExpired):
        return []
    shares = []
    for line in out.splitlines():
        m = re.match(r"^(.+?)\s{2,}Disk\b", line)
        if not m:
            continue
        s = m.group(1).strip()
        if s.upper() in ("ADMIN$", "IPC$", "PRINT$") or (not include_admin and re.fullmatch(r"[A-Za-z]\$", s)):
            continue
        shares.append(f"\\\\{host}\\{s}")
    return shares


def unc_host(p: str) -> Optional[str]:
    m = re.match(r"^[\\/]{2}([^\\/]+)", p)
    return m.group(1) if m else None


# =========================================================================== #
# Active Directory (ldap3, optional)
# =========================================================================== #
AD_FREE_TEXT = ["description", "info", "comment", "notes", "adminDescription", "physicalDeliveryOfficeName",
                *[f"extensionAttribute{i}" for i in range(1, 16)]]
AD_STRUCTURED = ["employeeID", "employeeNumber", "telephoneNumber", "mobile", "homePhone", "streetAddress",
                 "postalCode", "otherMobile", "ipPhone", "pager"]
AD_PASSWORD_ATTRS = ["userPassword", "unixUserPassword", "unicodePwd", "msSFU30Password", "os400Password"]
_PWD_HINT = re.compile(r"(?i)\b(pw|pwd|pass(word)?|kennwort|temp ?pass)\b")


def scan_ad(server, user, base_dn, use_ssl, rs: RuleSet, min_conf: int, show_raw: bool) -> dict:
    from ldap3 import ALL, NTLM, SUBTREE, Connection, Server  # type: ignore
    pwd = os.environ.get("PII_AD_PASSWORD") or getpass.getpass(f"AD password for {user}: ")
    srv = Server(server, use_ssl=use_ssl, get_info=ALL)
    conn = Connection(srv, user=user, password=pwd, authentication=NTLM, auto_bind=True)
    base_dn = base_dn or srv.info.other["defaultNamingContext"][0]
    attrs = ["sAMAccountName", "distinguishedName", "objectClass", *AD_FREE_TEXT, *AD_STRUCTURED, *AD_PASSWORD_ATTRS]
    findings, structured, total = [], {a: 0 for a in AD_STRUCTURED}, 0
    for entry in conn.extend.standard.paged_search(
            base_dn, "(|(objectClass=user)(objectClass=contact)(objectClass=computer)(objectClass=group))",
            search_scope=SUBTREE, attributes=attrs, paged_size=500, generator=True):
        if entry.get("type") != "searchResEntry":
            continue
        total += 1
        a = entry["attributes"]
        name = str(a.get("sAMAccountName") or a.get("distinguishedName"))
        oc = a.get("objectClass") or [""]
        oc = oc[-1] if isinstance(oc, list) else str(oc)
        for s in AD_STRUCTURED:
            if a.get(s):
                structured[s] += 1
        for p in AD_PASSWORD_ATTRS:
            if a.get(p):
                findings.append(dict(object=name, objectClass=oc, attribute=p, type="Password attribute populated",
                                     category="Credential", severity="Critical", confidence="High", value="******"))
        for attr in AD_FREE_TEXT:
            val = a.get(attr)
            if not val:
                continue
            text = "\n".join(map(str, val)) if isinstance(val, list) else str(val)
            matches, _ = scan_text(text, rs, min_conf)
            for rule, v, _line, conf in matches:
                findings.append(dict(object=name, objectClass=oc, attribute=attr, type=rule.name,
                                     category=rule.category, severity=rule.severity, confidence=CONF_NAME[conf],
                                     value=v if show_raw else mask(v, rule.kind)))
            if _PWD_HINT.search(text) and not any(r.name == "Password in Clear Text" for r, *_ in matches):
                findings.append(dict(object=name, objectClass=oc, attribute=attr, type="Possible password reference",
                                     category="Credential", severity="High", confidence="Low",
                                     value="(review manually)"))
    conn.unbind()
    return {"objects_scanned": total, "base": base_dn, "structured_attribute_counts": structured,
            "findings": findings}


# =========================================================================== #
# Reporting (shared by single-host scans and --merge)
# =========================================================================== #
SEV_CLS = {"Critical": "crit", "High": "high", "Medium": "med", "Low": "low"}
CLS_CLS = {"Restricted": "crit", "Confidential": "high", "Internal": "med"}


def build_summary(results: list[dict], ad: Optional[dict], rs: RuleSet, duration: float) -> dict:
    by_type, by_cat = {}, {}
    by_class = {"Restricted": 0, "Confidential": 0, "Internal": 0}
    for r in results:
        for t, c in r["counts"].items():
            by_type[t] = by_type.get(t, 0) + c
            by_cat[rs.cat[t]] = by_cat.get(rs.cat[t], 0) + c
        if r["classification"]:
            by_class[r["classification"]] += 1
    for fd in (ad or {}).get("findings", []):
        by_type[fd["type"]] = by_type.get(fd["type"], 0) + 1
        by_cat[fd["category"]] = by_cat.get(fd["category"], 0) + 1
    return {
        "files_examined": len(results),
        "files_with_pii": sum(1 for r in results if r["classification"]),
        "files_phi": sum(1 for r in results if r["phi"]),
        "files_errored_or_skipped": sum(1 for r in results if r["status"] != "ok"),
        "suppressed_low_confidence": sum(r["suppressed"] for r in results),
        "files_by_classification": by_class,
        "matches_by_type": dict(sorted(by_type.items(), key=lambda kv: -kv[1])),
        "matches_by_category": dict(sorted(by_cat.items(), key=lambda kv: -kv[1])),
        "ad_findings": len((ad or {}).get("findings", [])),
        "duration_seconds": round(duration, 1),
    }


FINDING_COLS = ["Host", "Source", "PathOrObject", "Where", "PIIType", "Category", "Severity", "Confidence", "Value",
                "Classification", "PHI"]


def finding_rows(doc: dict) -> Iterator[list]:
    host = doc["meta"]["host"]
    for r in doc["files"]:
        for f in r["findings"]:
            yield [host, "File", r["path"], f["where"], f["type"], f["category"], f["severity"], f["confidence"],
                   f["value"], r["classification"], r["phi"]]
    for f in (doc.get("active_directory") or {}).get("findings", []):
        yield [host, "ActiveDirectory", f["object"], f["attribute"], f["type"], f["category"], f["severity"],
               f["confidence"], f["value"], "Restricted" if f["severity"] == "Critical" else "Confidential", False]


def write_host_reports(out_dir: str, results: list[dict], ad: Optional[dict], meta: dict, rs: RuleSet) -> tuple:
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.join(out_dir, f"PII_{meta['host']}_{dt.datetime.now():%Y%m%d_%H%M%S}")
    hits = sorted((r for r in results if r["classification"]), key=lambda r: -r["risk_score"])
    summary = build_summary(results, ad, rs, meta["duration"])
    doc = {"schema": SCHEMA, "meta": meta, "summary": summary, "files": hits,
           "errors": [{"path": r["path"], "status": r["status"]} for r in results if r["status"] != "ok"][:5000],
           "active_directory": ad or None}
    with open(base + "_summary.json", "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1, default=str)
    with open(base + "_findings.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(FINDING_COLS)
        w.writerows(finding_rows(doc))
    with open(base + "_files.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["Path", "SizeBytes", "Modified", "Owner", "Classification", "PHI", "TopSeverity", "RiskScore",
                    "PIITypes", "SuppressedLowConfidence", "Status"])
        for r in sorted(results, key=lambda r: -r["risk_score"]):
            w.writerow([r["path"], r["size"], r["modified"], r["owner"], r["classification"], r["phi"],
                        r["top_severity"], r["risk_score"], "; ".join(f"{k}={v}" for k, v in r["counts"].items()),
                        r["suppressed"], r["status"]])
    with open(base + "_report.html", "w", encoding="utf-8") as f:
        f.write(render_html([doc], f"PII / PHI Scan Report - {meta['host']}"))
    return base, summary


def merge_reports(src: str, out_dir: str) -> tuple:
    docs = []
    for p in sorted(glob.glob(os.path.join(src, "**", "*_summary.json"), recursive=True)):
        try:
            with open(p, encoding="utf-8-sig") as f:
                d = json.load(f)
            if d.get("schema") == SCHEMA:
                docs.append(d)
        except (OSError, json.JSONDecodeError) as e:
            print(f"[!] skipping {p}: {e}", file=sys.stderr)
    if not docs:
        raise SystemExit(f"no {SCHEMA} *_summary.json files under {src}")
    os.makedirs(out_dir, exist_ok=True)
    base = os.path.join(out_dir, f"ESTATE_{dt.datetime.now():%Y%m%d_%H%M%S}")
    with open(base + "_findings.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(FINDING_COLS)
        for d in docs:
            w.writerows(finding_rows(d))
    host_rows = [host_row(d) for d in docs]
    with open(base + "_hosts.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(host_rows[0]))
        w.writeheader()
        w.writerows(host_rows)
    total = aggregate([d["summary"] for d in docs])
    with open(base + "_summary.json", "w", encoding="utf-8") as f:
        json.dump({"schema": "pii-estate/2", "generated": dt.datetime.now().isoformat(timespec="seconds"),
                   "hosts": host_rows, "summary": total}, f, indent=1)
    with open(base + "_report.html", "w", encoding="utf-8") as f:
        f.write(render_html(docs, f"PII / PHI Estate Report - {len(docs)} scan(s)"))
    return base, total, len(docs)


def host_row(d: dict) -> dict:
    s, m = d["summary"], d["meta"]
    top = ", ".join(f"{k} ({v})" for k, v in list(s["matches_by_type"].items())[:4])
    return {"Host": m["host"], "Scanner": m["scanner"], "Started": m["started"], "FilesExamined": s["files_examined"],
            "FilesWithPII": s["files_with_pii"], "Restricted": s["files_by_classification"]["Restricted"],
            "Confidential": s["files_by_classification"]["Confidential"],
            "Internal": s["files_by_classification"]["Internal"], "PHIFiles": s["files_phi"],
            "ADFindings": s["ad_findings"], "RiskTotal": sum(r["risk_score"] for r in d["files"]), "TopTypes": top}


def aggregate(summaries: list[dict]) -> dict:
    tot = {"files_examined": 0, "files_with_pii": 0, "files_phi": 0, "files_errored_or_skipped": 0,
           "suppressed_low_confidence": 0, "ad_findings": 0,
           "files_by_classification": {"Restricted": 0, "Confidential": 0, "Internal": 0},
           "matches_by_type": {}, "matches_by_category": {}}
    for s in summaries:
        for k in ("files_examined", "files_with_pii", "files_phi", "files_errored_or_skipped",
                  "suppressed_low_confidence", "ad_findings"):
            tot[k] += s.get(k, 0)
        for k in tot["files_by_classification"]:
            tot["files_by_classification"][k] += s["files_by_classification"].get(k, 0)
        for key in ("matches_by_type", "matches_by_category"):
            for t, c in s.get(key, {}).items():
                tot[key][t] = tot[key].get(t, 0) + c
    for key in ("matches_by_type", "matches_by_category"):
        tot[key] = dict(sorted(tot[key].items(), key=lambda kv: -kv[1]))
    return tot


def render_html(docs: list[dict], title: str) -> str:
    e = lambda x: html.escape(str(x))  # noqa: E731
    tot = aggregate([d["summary"] for d in docs])
    cats = {}
    sevs = {}
    for d in docs:
        for r in d["files"]:
            for f in r["findings"]:
                cats[f["type"]] = f["category"]
                sevs[f["type"]] = f["severity"]
        for f in (d.get("active_directory") or {}).get("findings", []):
            cats[f["type"]], sevs[f["type"]] = f["category"], f["severity"]
    type_rows = "".join(
        f"<tr><td>{e(t)}</td><td>{e(cats.get(t, ''))}</td><td><span class='pill {SEV_CLS.get(sevs.get(t), '')}'>"
        f"{e(sevs.get(t, ''))}</span></td><td class='num'>{c}</td></tr>" for t, c in tot["matches_by_type"].items())
    host_rows = "".join(
        "<tr>" + "".join(f"<td{' class=num' if isinstance(v, int) else ''}>{e(v)}</td>" for v in host_row(d).values())
        + "</tr>" for d in sorted(docs, key=lambda d: -sum(r["risk_score"] for r in d["files"])))
    files = sorted(((d["meta"]["host"], r) for d in docs for r in d["files"]), key=lambda x: -x[1]["risk_score"])
    file_rows = []
    for host, r in files[:2000]:
        types = ", ".join(f"{e(k)} ({v})" for k, v in r["counts"].items())
        smp = "<br>".join(f"{e(f['type'])}: <code>{e(f['value'])}</code> <span class='muted'>{e(f['confidence'])}"
                          f" &middot; {e(f['where'])}</span>" for f in r["findings"][:6])
        phi = " <span class='pill phi'>PHI</span>" if r["phi"] else ""
        file_rows.append(f"<tr><td><span class='pill {CLS_CLS.get(r['classification'], '')}'>{e(r['classification'])}"
                         f"</span>{phi}</td><td class='num'>{r['risk_score']}</td><td>{e(host)}</td>"
                         f"<td class='path'>{e(r['path'])}</td><td>{types}</td><td class='small'>{smp}</td>"
                         f"<td class='small'>{e(r.get('owner', ''))}</td><td class='small'>{e(r['modified'])}</td></tr>")
    ad_html = ""
    for d in docs:
        ad = d.get("active_directory")
        if not ad:
            continue
        rows = "".join(
            f"<tr><td><span class='pill {SEV_CLS.get(f['severity'], '')}'>{e(f['severity'])}</span></td>"
            f"<td>{e(f['object'])}</td><td>{e(f['objectClass'])}</td><td>{e(f['attribute'])}</td><td>{e(f['type'])}</td>"
            f"<td>{e(f['confidence'])}</td><td><code>{e(f['value'])}</code></td></tr>" for f in ad["findings"])
        st = "".join(f"<tr><td>{e(k)}</td><td class='num'>{v}</td></tr>"
                     for k, v in ad["structured_attribute_counts"].items())
        ad_html += (f"<h2>Active Directory <span class='muted'>({e(d['meta']['host'])})</span></h2>"
                    f"<p>{ad['objects_scanned']} objects scanned under <code>{e(ad['base'])}</code></p>"
                    "<h3>PII in free-text attributes</h3><table><thead><tr><th>Severity</th><th>Object</th><th>Class</th>"
                    f"<th>Attribute</th><th>Type</th><th>Confidence</th><th>Value</th></tr></thead><tbody>"
                    f"{rows or '<tr><td colspan=7>None</td></tr>'}</tbody></table>"
                    "<h3>Objects holding structured PII attributes</h3><table class='narrow'><thead><tr><th>Attribute"
                    f"</th><th>Objects</th></tr></thead><tbody>{st}</tbody></table>")
    c = tot["files_by_classification"]
    masked = any(d["meta"].get("show_raw") for d in docs)
    scopes = "; ".join(f"{d['meta']['host']}: {', '.join(d['meta']['paths']) or '(AD only)'}" for d in docs)
    hosts_cols = "".join(f"<th>{k}</th>" for k in host_row(docs[0]))
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>{e(title)}</title><style>
body{{font-family:Segoe UI,Arial,sans-serif;background:#f7f8fa;color:#1d2230;margin:0;padding:24px}}
h1{{margin:0 0 4px}} h2{{margin-top:28px}} .muted,.meta{{color:#667}} .meta{{margin-bottom:20px;font-size:13px}}
.cards{{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:24px}}
.card{{background:#fff;border:1px solid #e3e6ec;border-radius:8px;padding:14px 18px;min-width:130px}}
.card b{{display:block;font-size:26px}} .card span{{color:#667;font-size:13px}}
table{{border-collapse:collapse;width:100%;background:#fff;margin-bottom:20px;font-size:13px}} table.narrow{{max-width:560px}}
th,td{{border:1px solid #e3e6ec;padding:6px 8px;text-align:left;vertical-align:top}} th{{background:#eef0f4}}
.num{{text-align:right}} .path{{word-break:break-all;max-width:380px}} .small{{font-size:12px}}
code{{background:#f0f1f4;padding:1px 4px;border-radius:3px}}
.pill{{padding:2px 8px;border-radius:10px;font-size:12px;font-weight:600;white-space:nowrap}}
.crit{{background:#fde2e1;color:#a4161a}} .high{{background:#ffe8cc;color:#9a4a00}}
.med{{background:#fff3bf;color:#6b5900}} .low{{background:#e7f0ff;color:#1c4fa0}} .phi{{background:#efe2fd;color:#5b1aa4}}
</style></head><body>
<h1>{e(title)}</h1>
<div class="meta">Generated {dt.datetime.now():%Y-%m-%d %H:%M} &middot; Values {'<b>UNMASKED</b>' if masked else 'masked'}
&middot; Rules v{e(docs[0]['meta'].get('rules_version', ''))} &middot; Min confidence {e(docs[0]['meta'].get('min_confidence', ''))}<br>Scope: {e(scopes)}</div>
<div class="cards">
<div class="card"><b>{len(docs)}</b><span>scans / hosts</span></div>
<div class="card"><b>{tot['files_examined']}</b><span>files examined</span></div>
<div class="card"><b>{tot['files_with_pii']}</b><span>files with PII/PHI</span></div>
<div class="card"><b style="color:#a4161a">{c['Restricted']}</b><span>Restricted</span></div>
<div class="card"><b style="color:#9a4a00">{c['Confidential']}</b><span>Confidential</span></div>
<div class="card"><b style="color:#6b5900">{c['Internal']}</b><span>Internal</span></div>
<div class="card"><b style="color:#5b1aa4">{tot['files_phi']}</b><span>files with PHI</span></div>
<div class="card"><b>{tot['ad_findings']}</b><span>AD findings</span></div>
<div class="card"><b class="muted">{tot['suppressed_low_confidence']}</b><span>low-confidence suppressed</span></div>
</div>
<h2>Hosts</h2><table><thead><tr>{hosts_cols}</tr></thead><tbody>{host_rows}</tbody></table>
<h2>Matches by type</h2><table class="narrow"><thead><tr><th>Type</th><th>Category</th><th>Severity</th><th>Matches</th></tr></thead>
<tbody>{type_rows or "<tr><td colspan=4>None</td></tr>"}</tbody></table>
<h2>Files containing PII / PHI (highest risk first{', top 2000' if len(files) > 2000 else ''})</h2>
<table><thead><tr><th>Classification</th><th>Risk</th><th>Host</th><th>Path</th><th>Types</th><th>Samples</th><th>Owner</th><th>Modified</th></tr></thead>
<tbody>{''.join(file_rows) or "<tr><td colspan=8>No PII found</td></tr>"}</tbody></table>
{ad_html}
<p class="meta"><b>Restricted</b>: Critical identifiers or credentials (Aadhaar, PAN, ABHA, card, passport, SSN, passwords, keys), or any file flagged PHI.
<b>Confidential</b>: High (bank account, IBAN, DOB, voter ID, DL, UHID/MRN, ICD-10, insurance/claim no).
<b>Internal</b>: Medium/Low only (mobile, email, GSTIN, IFSC, IP).
<b>PHI</b>: a patient identifier (ABHA, UHID/MRN, PM-JAY) or health evidence (ICD-10, blood group, 2+ medical terms) together with a personal identifier.
Confidence: High = checksum/format + context, Medium = validated or context, Low = pattern only (hidden by default).</p>
</body></html>"""


# =========================================================================== #
# CLI
# =========================================================================== #
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="PII / PHI discovery & classification scanner")
    g = ap.add_argument_group("targets")
    g.add_argument("--path", action="append", default=[], help="File, folder, drive or UNC path (repeatable)")
    g.add_argument("--all-drives", action="store_true", help="All fixed local drives (Windows)")
    g.add_argument("--host", action="append", default=[], help="Remote host: enumerate & scan its SMB shares")
    g.add_argument("--hosts-file", help="File with one host per line")
    g.add_argument("--include-admin-shares", action="store_true", help="Also scan C$, D$ ... (needs local admin)")
    g.add_argument("--smb-user", help="DOMAIN\\user for SMB (password: prompt or env PII_SMB_PASSWORD)")
    g.add_argument("--ad", action="store_true", help="Scan Active Directory attributes (needs ldap3)")
    g.add_argument("--ad-server")
    g.add_argument("--ad-user", help="DOMAIN\\user (password: prompt or env PII_AD_PASSWORD)")
    g.add_argument("--ad-base")
    g.add_argument("--ad-ldaps", action="store_true")
    g.add_argument("--merge", metavar="DIR", help="Merge *_summary.json files under DIR into one estate report")
    o = ap.add_argument_group("tuning")
    o.add_argument("--out", default="PII_Reports")
    o.add_argument("--rules", default=DEFAULT_RULES)
    o.add_argument("--workers", type=int, default=max(2, (os.cpu_count() or 4)))
    o.add_argument("--min-confidence", choices=["low", "medium", "high"])
    o.add_argument("--max-size-mb", type=float, default=25)
    o.add_argument("--max-pst-mb", type=float, default=4096)
    o.add_argument("--max-samples", type=int, default=5)
    o.add_argument("--exclude-dir", action="append", default=[])
    o.add_argument("--no-default-excludes", action="store_true")
    o.add_argument("--no-archives", action="store_true", help="Do not look inside .zip files")
    o.add_argument("--include-owner", action="store_true", help="Resolve owner of flagged files (needs pywin32)")
    o.add_argument("--show-raw", action="store_true", help="DANGER: write unmasked PII to reports")
    ap.add_argument("--version", action="version", version=__version__)
    a = ap.parse_args(argv)

    if a.merge:
        base, tot, n = merge_reports(a.merge, a.out)
        print(f"[+] Merged {n} scan(s): {tot['files_with_pii']} files with PII, {tot['files_phi']} PHI, "
              f"{tot['ad_findings']} AD findings")
        print(f"[+] Estate report: {base}_report.html / _hosts.csv / _findings.csv / _summary.json")
        return 0

    rs = RuleSet(a.rules)
    min_conf = CONF_VALUE[a.min_confidence] if a.min_confidence else rs.default_min_conf
    paths = list(a.path)
    if a.all_drives and os.name == "nt":
        import ctypes
        import string
        bits = ctypes.windll.kernel32.GetLogicalDrives()
        paths += [f"{L}:\\" for i, L in enumerate(string.ascii_uppercase)
                  if bits >> i & 1 and ctypes.windll.kernel32.GetDriveTypeW(f"{L}:\\") == 3]
    hosts = list(a.host)
    if a.hosts_file:
        with open(a.hosts_file, encoding="utf-8") as f:
            hosts += [ln.strip() for ln in f if ln.strip() and not ln.startswith("#")]

    connected = []
    if a.smb_user and os.name == "nt":
        pwd = os.environ.get("PII_SMB_PASSWORD") or getpass.getpass(f"SMB password for {a.smb_user}: ")
        for h in sorted(set(hosts) | {unc_host(p) for p in paths if unc_host(p)}):
            rc = smb_connect(h, a.smb_user, pwd)
            if rc == 0:
                connected.append(h)
            elif rc != 1219:  # 1219 = already connected with other credentials
                print(f"[!] SMB auth to {h} failed (Win32 error {rc})", file=sys.stderr)
    for h in hosts:
        if not port_open(h):
            print(f"[!] SMB 445 unreachable: {h}", file=sys.stderr)
            continue
        shares = list_shares(h, a.include_admin_shares)
        print(f"    {h}: {len(shares)} share(s)")
        paths += shares
    if not paths and not a.ad:
        ap.error("nothing to scan: use --path, --all-drives, --host or --ad")

    excludes = set() if a.no_default_excludes else set(DEFAULT_EXCLUDE_DIRS)
    excludes |= {d.lower() for d in a.exclude_dir}
    t0 = time.time()
    meta = {"host": socket.gethostname(), "scanner": f"python/{__version__}", "paths": paths,
            "started": dt.datetime.now().isoformat(timespec="seconds"), "show_raw": a.show_raw,
            "user": getpass.getuser(), "rules_version": rs.version, "min_confidence": CONF_NAME[min_conf]}

    results: list[dict] = []
    if paths:
        print(f"[*] Scanning {len(paths)} location(s) with {a.workers} worker processes (min confidence "
              f"{CONF_NAME[min_conf]}) ...")
        init = (a.rules, min_conf, int(a.max_size_mb * 1048576), int(a.max_pst_mb * 1048576), a.max_samples,
                a.show_raw, not a.no_archives)
        with mp.get_context("spawn").Pool(a.workers, initializer=_init_worker, initargs=init) as pool:
            # chunksize=1: large files must not queue up behind each other in one worker's batch
            for r in pool.imap_unordered(scan_file, walk_files(paths, excludes), chunksize=1):
                results.append(r)
                if len(results) % 1000 == 0:
                    print(f"    {len(results)} files examined ({time.time() - t0:.0f}s) ...")
        if a.include_owner:
            for r in results:
                if r["classification"]:
                    r["owner"] = file_owner(r["path"])
    for h in connected:
        smb_disconnect(h)

    ad = None
    if a.ad:
        server = a.ad_server or os.environ.get("USERDNSDOMAIN")
        user = a.ad_user or f"{os.environ.get('USERDOMAIN', '')}\\{getpass.getuser()}"
        if not server:
            print("[!] --ad-server required (USERDNSDOMAIN not set)", file=sys.stderr)
        else:
            print(f"[*] Scanning Active Directory on {server} as {user} ...")
            try:
                ad = scan_ad(server, user, a.ad_base, a.ad_ldaps, rs, min_conf, a.show_raw)
            except ImportError:
                print("[!] AD scan needs ldap3:  pip install ldap3", file=sys.stderr)
            except Exception as e:  # noqa: BLE001
                print(f"[!] AD scan failed: {e}", file=sys.stderr)

    meta["finished"] = dt.datetime.now().isoformat(timespec="seconds")
    meta["duration"] = round(time.time() - t0, 1)
    base, s = write_host_reports(a.out, results, ad, meta, rs)
    c = s["files_by_classification"]
    print(f"[+] {s['files_examined']} files in {meta['duration']}s: {s['files_with_pii']} with PII "
          f"(Restricted {c['Restricted']}, Confidential {c['Confidential']}, Internal {c['Internal']}), "
          f"PHI {s['files_phi']}, suppressed low-confidence {s['suppressed_low_confidence']}, AD {s['ad_findings']}")
    print(f"[+] Reports: {base}_report.html / _findings.csv / _files.csv / _summary.json")
    return 0


if __name__ == "__main__":
    mp.freeze_support()
    sys.exit(main())
