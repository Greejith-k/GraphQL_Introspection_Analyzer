# PII / PHI Discovery & Classification Toolkit (v2)

Finds and classifies **personal data (PII)** and **Indian personal health information (PHI)** across Windows
endpoints, file servers / SMB shares and Active Directory. Two interchangeable scanners share one rule file and
produce identical results and report formats.

```
tool_PII/
├── rules/pii_rules.json               ← single source of truth for detection (edit here, both scanners follow)
├── powershell/Invoke-PIIScan.ps1      ← scanner: single file, no installs, multi-threaded C# engine compiled in memory
├── powershell/Invoke-PIIScanRemote.ps1← fan-out: runs the scanner ON many hosts via WinRM, collects, merges
├── python/pii_scanner.py              ← scanner: stdlib only, multi-process; optional PDF / PST / AD extras
└── tests/                             ← synthetic test data generators + result checker (accuracy & parity)
```

| | PowerShell | Python |
|---|---|---|
| Runtime | Windows PowerShell 5.1+ (FullLanguage mode) | Python 3.8+ (Windows / Linux) |
| Install on target | nothing | Python (or a PyInstaller exe) |
| Parallelism | threads (C# engine) | processes |
| AD scan | ADSI, current Kerberos or `-Credential` | `ldap3` (NTLM) |
| PDF | – | `pypdf` |
| PST / OST | via Outlook (`-IncludePst`, needs an Outlook profile) | `libpff-python` |
| Remote fan-out | `Invoke-PIIScanRemote.ps1` (WinRM) | – |
| Merge many hosts | `-MergeFrom DIR` | `--merge DIR` |

## What it detects

| Category | Types (severity) | False-positive controls |
|---|---|---|
| **PII – India** | Aadhaar (Critical), PAN (Critical), Passport (Critical), Voter ID/EPIC (High), Driving Licence (High), Mobile (Medium) | Aadhaar **Verhoeff** checksum; DL **state code**; EPIC/passport need a keyword nearby; mobile needs +91/0 prefix or a "mobile/phone" keyword |
| **PHI – India** | ABHA Number & ABHA Address (Critical), UHID/MRN (High), PM-JAY ID (High), ICD-10 diagnosis code (High), Blood group (Medium), medical terms (indicator) | Patient-ID / ICD / blood group need a nearby keyword ("UHID", "Diagnosis", "Blood group"…) |
| **Financial** | Card numbers (Critical), IBAN (High), Bank account (High), Insurance policy/claim no (High), IFSC (Low) | **Luhn** + issuer prefix (Visa/MC/RuPay/Maestro/Amex…); IBAN **mod-97**; bank account needs "account no / A/c / beneficiary" |
| **Credentials** | Clear-text passwords, AWS keys, private keys (Critical) | placeholders ignored (`********`, `${VAR}`, `Read-Host`, `%PASS%`…) |
| **Other** | US SSN, Date of birth (real calendar date, not in the future, needs "DOB/birth"), GSTIN (**checksum**), email, IPv4 | role mailboxes (`noreply@`) and `icon@2x.png` ignored; IPs after "version/build" ignored |

**Confidence scoring.** Each match is scored Low / Medium / High from checksum validity, formatting (e.g. `2345 6789 0124`
vs a bare 12-digit run) and context keywords. Only **Medium+** is reported by default; Low-confidence candidates are
counted as "suppressed" (`-MinConfidence Low` / `--min-confidence low` shows everything).

* **Column headers become context** for CSV, XLSX and XLS files: a bare `234567890124` under an "Aadhaar" column is
  reported, while the same number in a log line is not.
* **Published test values are suppressed**: `4111 1111 1111 1111`, `AKIAIOSFODNN7EXAMPLE`, `ABCDE1234F`,
  `9876543210`, UIDAI sandbox Aadhaars and similar.

**PHI flag.** A file is flagged **PHI** (and forced to *Restricted*) when it holds a patient identifier
(ABHA / UHID / PM-JAY), or health evidence (ICD-10 code, blood group, or 2+ distinct medical terms) **together with**
a personal identifier (Aadhaar, PAN, mobile, email, DOB, bank details…). Medical words alone, as in a "cancer
awareness" poster, do not classify a file.

**Classification.** **Restricted** = any Critical type or PHI · **Confidential** = High · **Internal** = Medium/Low only.
`RiskScore = Σ count × weight (10/5/2/1) + 25 if PHI` is used for ranking.

## File formats

Plain text and config files (txt, log, json, xml, ini, sql, ps1, py, env, eml, …).
CSV and TSV are read row by row with the header row used as context.
Office: docx, xlsx, pptx and **legacy doc, xls, ppt** (built-in OLE2 reader, no Office needed).
OpenDocument: odt, ods, odp.
Outlook: **msg** (including attachments) and **pst / ost** (Python with libpff, or PowerShell with Outlook).
**zip** archives up to 2 levels deep (e.g. an attachment inside a zip). PDF in Python only.
Text files larger than the size limit are partially scanned (first N MB); larger binary files are skipped and logged.

## Deployment models

### A. Agentless, from your VAPT machine over SMB

```powershell
# Windows VAPT box (domain-joined or not) - explicit credential for SMB + LDAP
$cred = Get-Credential CLIENT\pii_auditor
.\powershell\Invoke-PIIScan.ps1 -ComputerName 10.10.20.15,fs01 -IncludeAdminShares -Credential $cred
.\powershell\Invoke-PIIScan.ps1 -DiscoverComputersFromAD -ADServer dc01.client.local -Credential $cred
.\powershell\Invoke-PIIScan.ps1 -ScanAD -ADServer dc01.client.local -Credential $cred
```
```bash
# Python equivalent (password prompted, or env PII_SMB_PASSWORD / PII_AD_PASSWORD)
python python/pii_scanner.py --host fs01 --host 10.10.20.15 --smb-user CLIENT\pii_auditor --include-admin-shares
python python/pii_scanner.py --hosts-file hosts.txt --smb-user CLIENT\pii_auditor --workers 16
```
* The scanner lists each host's shares (`net view`), skips `ADMIN$`/`IPC$`/`print$`, and reads `C$` and other
  drive shares only with `-IncludeAdminShares` (which needs local admin).
* On Linux (Kali): mount shares with `mount -t cifs` and point `--path` at the mount. The `--host` discovery uses `net view` and works on Windows only.
* All file content crosses the network, so this is the slowest model. **Warn the client's SOC/EDR team first**: mass
  file reads from one IP look like ransomware staging or data theft.

### B. Run on each machine (best coverage and speed)

```powershell
# Push to many hosts over WinRM, run locally on each, pull reports back, build the estate report
.\powershell\Invoke-PIIScanRemote.ps1 -FromAD -ADSearchBase "OU=Workstations,DC=client,DC=local" -Credential $cred -ThrottleLimit 32
.\powershell\Invoke-PIIScanRemote.ps1 -ComputerListFile hosts.txt -RemotePath 'C:\Users','D:\Data' -ScanArgs @{ IncludeOwner = $true }
```
* Nothing is installed on the targets. The script and rules travel over the WinRM session and run in memory. Each
  host scans its own disks and writes reports to its own `%TEMP%`. The reports are returned over the same session
  (which avoids the double-hop problem), and the temp files are deleted afterwards.
* Output: `PII_Collected\<host>\PII_*`, `_failures.csv` (unreachable or access denied), `_estate\ESTATE_*_report.html`.
* Alternative without WinRM: deploy `Invoke-PIIScan.ps1` plus `pii_rules.json` through GPO, SCCM, Intune or a
  scheduled task with `-AllDrives -OutputDir \\collector\PIIReports$\%COMPUTERNAME%`, then run
  `-MergeFrom \\collector\PIIReports$`.

### C. File servers and NAS

Run the scanner **on the file server** against local paths (10–50× faster than over SMB), or point the Python scanner
with `--workers 16` at the UNC paths from a nearby machine.

### Merge (estate report)

```powershell
.\powershell\Invoke-PIIScan.ps1 -MergeFrom .\PII_Collected -OutputDir .\Estate
python python/pii_scanner.py --merge ./PII_Collected --out ./Estate
```
Both merge tools read JSON from either scanner. Output: a consolidated HTML report (hosts ranked by risk, top files
across the estate, totals by type and category, AD findings), `_hosts.csv`, `_findings.csv` and `_summary.json`.

## Output per scan

`PII_<host>_<ts>_report.html`, `_findings.csv` (one row per sampled match: type, category, severity, confidence,
masked value, location), `_files.csv` (every file examined: classification, PHI, risk, counts, suppressed count, status) and
`_summary.json` (schema `pii-scan/2`, the input for merging). Values are **masked** (`XXXX XXXX 0124`, `t***@corp.in`).
`-ShowRaw` / `--show-raw` writes clear values; use it only with written client approval.

## Key options

| PowerShell | Python | Purpose |
|---|---|---|
| `-Path` / `-AllDrives` | `--path` / `--all-drives` | local folders, drives, UNC paths |
| `-ComputerName` / `-ComputerListFile` / `-DiscoverComputersFromAD` | `--host` / `--hosts-file` | scan remote hosts' shares |
| `-Credential` | `--smb-user` / `--ad-user` | explicit credentials (non-domain VAPT box) |
| `-ScanAD -ADServer -ADSearchBase` | `--ad --ad-server --ad-base` | AD attribute scan |
| `-Threads` | `--workers` | parallelism (default: logical CPUs) |
| `-MinConfidence Low/Medium/High` | `--min-confidence` | precision vs. recall |
| `-MaxFileSizeMB` (25) | `--max-size-mb` | per-file read limit |
| `-ExcludeDir`, `-NoDefaultExcludes`, `-NoArchives` | same, kebab-case | scope control |
| `-IncludeOwner`, `-IncludePst` | `--include-owner` | owner column; PST via Outlook |
| `-RulesFile` | `--rules` | alternative rule set |

## Tuning rules

Edit `rules/pii_rules.json`. Each rule sets its regex, severity, category, validator, `context` keywords
(`context_required` makes them mandatory), `neg_context`, `format_boost`, `base_confidence` and `trigger` (a cheap
substring pre-check that skips the regex). Patterns must work in both Python `re` and .NET `Regex`. Add known dummy
values to `known_test_values`. After any change, run the tests below. Both scanners must still pass and agree.

## Testing

```powershell
python tests\make_test_data.py                      # synthetic, checksum-valid fake data + tests\expected.json
.\tests\make_legacy_test_data.ps1                   # real .doc/.xls/.ppt via Office COM (optional)
python tests\make_msg_test_data.py                  # .msg with attachment (no Outlook needed)
python python\pii_scanner.py --path tests\sample_data --out out_py
.\powershell\Invoke-PIIScan.ps1 -Path tests\sample_data -OutputDir out_ps
python tests\check_results.py out_ps\PII_*_summary.json out_py\PII_*_summary.json
```
`check_results.py` fails on any missed type, unexpected type, wrong classification or PHI flag, and on any difference
between the two scanners. The suite includes a `noise_negatives.txt` file of look-alikes that must produce **zero** findings.

**Current results (26-Nov-2026, this workstation, 8 logical CPUs):** 15/15 sample files correct in both
scanners. Findings are identical in the two (59 = 59 on the sample set; 8,065 = 8,065 on a 2,045-file / 243 MB
corpus). On that corpus Python took 34s and PowerShell 37s, down from 80s and 45s before tuning. In the 20 large log
files, 186,212 checksum-valid look-alike IDs were suppressed as low confidence.

## Not yet verified / limitations

* **Not run end-to-end here:** live AD scan, SMB `-Credential` / `--smb-user` authentication, `Invoke-PIIScanRemote.ps1`
  over real WinRM, and PST scanning (both the Outlook and libpff paths). The test machine has no domain, no WinRM and no
  Outlook profile. The remote payload and merge logic were exercised locally.
* **Not detected:** personal names and addresses (would need NER), text inside images or scanned PDFs (no OCR),
  encrypted or password-protected files, databases, cloud storage. Unsupported files are listed with a reason in `_files.csv`.
* The PowerShell scanner needs FullLanguage mode (`Add-Type`). It will not run under WDAC/AppLocker Constrained
  Language Mode; use the Python scanner there. Some EDRs alert on `csc.exe` compiling from PowerShell, so pre-agree
  this with the client.
* Run under a dedicated, read-only, audited account. The tools never modify files. Treat the reports as sensitive
  data (paths and masked samples) under DPDP Act obligations.
