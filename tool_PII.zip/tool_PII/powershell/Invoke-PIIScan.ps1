<#
.SYNOPSIS
    PII / PHI Discovery & Classification Scanner (PowerShell edition, v2).

.DESCRIPTION
    Finds personally identifiable information (PII) and Indian personal health information (PHI)
    on local drives, UNC/SMB shares, remote computers' shares and Active Directory. Every file is
    classified (Restricted / Confidential / Internal, plus a PHI flag) and HTML / CSV / JSON reports
    are written. Values are masked by default.

    * Single file, no modules to install. A multi-threaded C# engine is compiled in memory at start-up
      (Add-Type), so scanning runs at native speed on all cores.
    * Detection rules are shared with the Python scanner: ..\rules\pii_rules.json
    * AD access uses ADSI - RSAT / ActiveDirectory module NOT required.
    * Windows PowerShell 5.1+ (tested on 5.1). Requires FullLanguage mode (Add-Type).

.EXAMPLE
    .\Invoke-PIIScan.ps1 -Path C:\Users, \\fs01\HR -IncludeOwner

.EXAMPLE
    .\Invoke-PIIScan.ps1 -AllDrives -ScanAD

.EXAMPLE
    # From a non-domain VAPT box: authenticate SMB + LDAP with an explicit credential
    .\Invoke-PIIScan.ps1 -ComputerName 10.10.20.15,fs01 -IncludeAdminShares -Credential (Get-Credential CORP\auditor)

.EXAMPLE
    .\Invoke-PIIScan.ps1 -DiscoverComputersFromAD -ADServer dc01.corp.local -ADSearchBase "OU=Servers,DC=corp,DC=local" -Credential $cred

.EXAMPLE
    # Merge the per-host JSON files collected from many machines into one estate report
    .\Invoke-PIIScan.ps1 -MergeFrom .\PII_Collected -OutputDir .\Estate
#>
[CmdletBinding()]
param(
    [string[]]$Path = @(),
    [switch]$AllDrives,
    [string[]]$ComputerName = @(),
    [string]$ComputerListFile,
    [switch]$DiscoverComputersFromAD,
    [switch]$IncludeAdminShares,
    [System.Management.Automation.PSCredential]$Credential,
    [switch]$ScanAD,
    [string]$ADServer,
    [string]$ADSearchBase,
    [string]$OutputDir = '.\PII_Reports',
    [string]$RulesFile,
    [string]$RulesJson,
    [int]$Threads = [Environment]::ProcessorCount,
    [ValidateSet('Low', 'Medium', 'High')][string]$MinConfidence,
    [double]$MaxFileSizeMB = 25,
    [int]$MaxSamples = 5,
    [string[]]$ExcludeDir = @(),
    [switch]$NoDefaultExcludes,
    [switch]$NoArchives,
    [switch]$IncludeOwner,
    [switch]$IncludePst,
    [switch]$ShowRaw,
    [string]$MergeFrom,
    [switch]$PassThru,
    [switch]$Quiet
)

$ErrorActionPreference = 'Continue'
$ScannerVersion = '2.0.0'
$Schema = 'pii-scan/2'
function Say([string]$m) { if (-not $Quiet) { Write-Host $m } }

# =============================================================================================
# C# engine
# =============================================================================================
$EngineSource = @'
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace PiiScan
{
    public class Rule
    {
        public string Name, Category, Severity, Kind, Validator;
        public Regex Rx, FormatRx;
        public int Group, BaseConf, CtxWindow;
        public string[] Context, NegContext, Trigger;
        public bool CtxRequired;
    }

    public class Finding { public string Type, Category, Severity, Confidence, Value, Where; }

    public class FileResult
    {
        public string Path, Modified = "", Owner = "", Status = "ok", Classification = "", TopSeverity = "";
        public long Size;
        public int RiskScore, Suppressed;
        public bool Phi, PendingPst;
        public Dictionary<string, int> Counts = new Dictionary<string, int>();
        public List<Finding> Findings = new List<Finding>();
    }

    public class Hit { public Rule Rule; public string Value; public int Line, Conf; }

    public class Accumulator
    {
        public FileResult Res;
        public Dictionary<string, int> Samples = new Dictionary<string, int>();
        public HashSet<string> Health = new HashSet<string>();
    }

    public class AdFinding { public string Object, ObjectClass, Attribute, Type, Category, Severity, Confidence, Value; }

    public class AdResult
    {
        public int ObjectsScanned;
        public string Base = "";
        public Dictionary<string, int> Structured = new Dictionary<string, int>();
        public List<AdFinding> Findings = new List<AdFinding>();
    }

    // ------------------------------------------------------------------ validators
    public static class V
    {
        static readonly int[,] D = { {0,1,2,3,4,5,6,7,8,9},{1,2,3,4,0,6,7,8,9,5},{2,3,4,0,1,7,8,9,5,6},{3,4,0,1,2,8,9,5,6,7},
            {4,0,1,2,3,9,5,6,7,8},{5,9,8,7,6,0,4,3,2,1},{6,5,9,8,7,1,0,4,3,2},{7,6,5,9,8,2,1,0,4,3},{8,7,6,5,9,3,2,1,0,4},{9,8,7,6,5,4,3,2,1,0} };
        static readonly int[,] P = { {0,1,2,3,4,5,6,7,8,9},{1,5,7,6,2,8,3,0,9,4},{5,8,0,3,7,9,6,1,4,2},{8,9,1,6,0,4,3,5,2,7},
            {9,4,5,3,1,2,6,8,7,0},{4,2,8,6,5,7,3,9,0,1},{2,7,9,3,8,0,6,4,1,5},{7,0,4,6,9,1,3,2,5,8} };
        static readonly Regex CardPrefix = new Regex("^(?:4|5[0-8]|2[2-7]|3[0-9]|6|8[12])");
        static readonly Regex DateIso = new Regex(@"^(\d{4})-(\d{2})-(\d{2})$");
        static readonly Regex DateDmy = new Regex(@"^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$");
        static readonly Regex DateMon = new Regex(@"^(\d{1,2})[ -]([A-Za-z]+)[ ,-]+(\d{4})$");
        static readonly string[] Months = { "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec" };
        static readonly HashSet<string> PwdPlaceholders = new HashSet<string> { "password", "passwd", "true", "false", "null", "none", "required",
            "string", "optional", "empty", "yourpassword", "your_password", "mypassword", "redacted", "hidden", "masked", "n/a", "xxxx", "xxxxxx",
            "xxxxxxxx", "secret", "changeme_placeholder", "undefined" };
        static readonly string[] PwdTokens = { "read-host", "getenv", "environ", "securestring", "get-credential", "{{", "${" };
        static readonly HashSet<string> DlStates = new HashSet<string>("AN AP AR AS BR CG CH DD DL DN GA GJ HP HR JH JK KA KL LA LD MH ML MN MP MZ NL OD OR PB PY RJ SK TN TR TS UK UP WB".Split(' '));
        static readonly HashSet<string> NonTld = new HashSet<string> { "png", "jpg", "jpeg", "gif", "svg", "webp", "bmp", "ico", "css", "js", "ts", "map", "woff", "woff2" };
        static readonly HashSet<string> RoleMail = new HashSet<string> { "noreply", "no-reply", "donotreply", "do-not-reply", "postmaster", "mailer-daemon", "abuse", "webmaster", "hostmaster" };
        const string B36 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public static readonly HashSet<string> Names = new HashSet<string> { "not_repetitive", "credit_card", "aadhaar", "has_digit", "dl_state",
            "iban", "ipv4", "password", "date", "gstin", "email" };

        public static string Digits(string s)
        {
            var sb = new StringBuilder(s.Length);
            foreach (char c in s) if (c >= '0' && c <= '9') sb.Append(c);
            return sb.ToString();
        }
        public static bool Verhoeff(string d)
        {
            int c = 0;
            for (int i = 0; i < d.Length; i++) c = D[c, P[i % 8, d[d.Length - 1 - i] - '0']];
            return c == 0;
        }
        public static bool Luhn(string d)
        {
            int total = 0; bool alt = false;
            for (int i = d.Length - 1; i >= 0; i--)
            {
                int n = d[i] - '0';
                if (alt) n = n > 4 ? n * 2 - 9 : n * 2;
                total += n; alt = !alt;
            }
            return total % 10 == 0;
        }
        public static bool Repetitive(string d)
        {
            if (new HashSet<char>(d).Count <= 2) return true;
            return "01234567890123456789".Contains(d) || "98765432109876543210".Contains(d);
        }
        static bool YmdOk(int y, int m, int d)
        {
            try { var x = new DateTime(y, m, d); return y >= 1900 && x <= DateTime.Today; }
            catch (ArgumentOutOfRangeException) { return false; }
        }
        public static bool Call(string name, string v)
        {
            string d;
            switch (name)
            {
                case "not_repetitive": d = Digits(v); return d.Length == 0 || !Repetitive(d);
                case "credit_card": d = Digits(v); return d.Length >= 13 && d.Length <= 19 && !Repetitive(d) && CardPrefix.IsMatch(d) && Luhn(d);
                case "aadhaar": d = Digits(v); return d.Length == 12 && !Repetitive(d) && Verhoeff(d);
                case "has_digit": return v.Any(char.IsDigit);
                case "dl_state": return v.Length >= 2 && DlStates.Contains(v.Substring(0, 2).ToUpperInvariant());
                case "iban":
                {
                    string s = Regex.Replace(v, @"\s", "").ToUpperInvariant();
                    if (s.Length < 15 || s.Length > 34) return false;
                    string r = s.Substring(4) + s.Substring(0, 4);
                    int rem = 0;
                    foreach (char ch in r)
                    {
                        string part = char.IsDigit(ch) ? ch.ToString() : ((int)ch - 55).ToString(CultureInfo.InvariantCulture);
                        foreach (char dc in part) rem = (rem * 10 + (dc - '0')) % 97;
                    }
                    return rem == 1;
                }
                case "ipv4":
                {
                    var p = v.Split('.');
                    if (p.Length != 4) return false;
                    foreach (var x in p) if (int.Parse(x, CultureInfo.InvariantCulture) > 255) return false;
                    int first = int.Parse(p[0], CultureInfo.InvariantCulture);
                    return first >= 1 && first <= 223 && first != 127 && v != "255.255.255.255";
                }
                case "password":
                {
                    string low = v.ToLowerInvariant();
                    if (v.All(c => "*x#\u2022.X".IndexOf(c) >= 0)) return false;
                    if ("$%{[(<@\\".IndexOf(v[0]) >= 0 || PwdPlaceholders.Contains(low)) return false;
                    foreach (var t in PwdTokens) if (low.Contains(t)) return false;
                    return true;
                }
                case "date":
                {
                    string s = v.Trim();
                    var m = DateIso.Match(s);
                    if (m.Success) return YmdOk(int.Parse(m.Groups[1].Value), int.Parse(m.Groups[2].Value), int.Parse(m.Groups[3].Value));
                    m = DateDmy.Match(s);
                    if (m.Success)
                    {
                        int a = int.Parse(m.Groups[1].Value), b = int.Parse(m.Groups[2].Value), y = int.Parse(m.Groups[3].Value);
                        return YmdOk(y, b, a) || YmdOk(y, a, b);
                    }
                    m = DateMon.Match(s);
                    if (m.Success)
                    {
                        string mn = m.Groups[2].Value.ToLowerInvariant();
                        int mon = Array.IndexOf(Months, mn.Length >= 3 ? mn.Substring(0, 3) : mn) + 1;
                        return mon > 0 && YmdOk(int.Parse(m.Groups[3].Value), mon, int.Parse(m.Groups[1].Value));
                    }
                    return false;
                }
                case "gstin":
                {
                    string g = v.ToUpperInvariant();
                    int st = int.Parse(g.Substring(0, 2), CultureInfo.InvariantCulture);
                    if (!((st >= 1 && st <= 38) || st == 97 || st == 99)) return false;
                    int total = 0;
                    for (int i = 0; i < 14; i++)
                    {
                        int p = B36.IndexOf(g[i]) * (i % 2 == 1 ? 2 : 1);
                        total += p / 36 + p % 36;
                    }
                    return B36[(36 - total % 36) % 36] == g[14];
                }
                case "email":
                {
                    int at = v.LastIndexOf('@');
                    string local = v.Substring(0, at), dom = v.Substring(at + 1);
                    string tld = dom.Substring(dom.LastIndexOf('.') + 1).ToLowerInvariant();
                    return !NonTld.Contains(tld) && !RoleMail.Contains(local.ToLowerInvariant());
                }
            }
            throw new ArgumentException("unknown validator " + name);
        }
    }

    // ------------------------------------------------------------------ compound file (OLE2) reader
    public class Cfb
    {
        const uint END = 0xFFFFFFFA, NOSTREAM = 0xFFFFFFFF;
        class Entry { public string Name; public int Type; public uint Left, Right, Child, Start, Size; }
        readonly byte[] d;
        readonly int ss, mss;
        readonly uint cutoff;
        readonly List<uint> fat = new List<uint>(), minifat = new List<uint>();
        readonly byte[] ministream;
        public readonly List<string> Order = new List<string>();
        readonly Dictionary<string, uint[]> streams = new Dictionary<string, uint[]>();

        public static bool IsCfb(byte[] b)
        {
            byte[] sig = { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 };
            if (b.Length < 512) return false;
            for (int i = 0; i < 8; i++) if (b[i] != sig[i]) return false;
            return true;
        }
        uint U32(long off) { return BitConverter.ToUInt32(d, (int)off); }

        public Cfb(byte[] data)
        {
            if (!IsCfb(data)) throw new InvalidDataException("not a compound file");
            d = data;
            ss = 1 << BitConverter.ToUInt16(d, 0x1E);
            mss = 1 << BitConverter.ToUInt16(d, 0x20);
            uint nfat = U32(0x2C), dirStart = U32(0x30);
            cutoff = U32(0x38);
            uint minifatStart = U32(0x3C), difatStart = U32(0x44);
            var difat = new List<uint>();
            for (int i = 0; i < 109; i++) difat.Add(U32(0x4C + i * 4));
            int per = ss / 4;
            uint s = difatStart; int guard = 0;
            while (s < END && guard < 10000)
            {
                long off = ((long)s + 1) * ss;
                if (off + ss > d.Length) throw new InvalidDataException("bad DIFAT");
                for (int i = 0; i < per - 1; i++) difat.Add(U32(off + i * 4));
                s = U32(off + (per - 1) * 4); guard++;
            }
            int taken = 0;
            foreach (uint sec in difat)
            {
                if (sec >= END) continue;
                if (taken >= nfat) break;
                taken++;
                long off = ((long)sec + 1) * ss;
                if (off + ss <= d.Length) for (int i = 0; i < per; i++) fat.Add(U32(off + i * 4));
            }
            byte[] dirb = Chain(dirStart);
            var entries = new List<Entry>();
            for (int i = 0; i + 128 <= dirb.Length; i += 128)
            {
                int nlen = BitConverter.ToUInt16(dirb, i + 0x40);
                int nb = Math.Max(0, Math.Min(nlen, 64) - 2);
                entries.Add(new Entry {
                    Name = Encoding.Unicode.GetString(dirb, i, nb), Type = dirb[i + 0x42],
                    Left = BitConverter.ToUInt32(dirb, i + 0x44), Right = BitConverter.ToUInt32(dirb, i + 0x48),
                    Child = BitConverter.ToUInt32(dirb, i + 0x4C), Start = BitConverter.ToUInt32(dirb, i + 0x74),
                    Size = BitConverter.ToUInt32(dirb, i + 0x78) });
            }
            var root = entries[0];
            ministream = root.Size > 0 ? Slice(Chain(root.Start), root.Size) : new byte[0];
            if (minifatStart < END)
            {
                byte[] mf = Chain(minifatStart);
                for (int i = 0; i + 4 <= mf.Length; i += 4) minifat.Add(BitConverter.ToUInt32(mf, i));
            }
            var stack = new Stack<KeyValuePair<uint, string>>();
            var seen = new HashSet<uint>();
            stack.Push(new KeyValuePair<uint, string>(root.Child, ""));
            while (stack.Count > 0)
            {
                var top = stack.Pop();
                uint i = top.Key; string prefix = top.Value;
                if (i == NOSTREAM || i >= entries.Count || !seen.Add(i)) continue;
                var e = entries[(int)i];
                stack.Push(new KeyValuePair<uint, string>(e.Left, prefix));
                stack.Push(new KeyValuePair<uint, string>(e.Right, prefix));
                if (e.Type == 2)
                {
                    string key = prefix + e.Name;
                    if (!streams.ContainsKey(key)) Order.Add(key);
                    streams[key] = new uint[] { e.Start, e.Size };
                }
                else if (e.Type == 1) stack.Push(new KeyValuePair<uint, string>(e.Child, prefix + e.Name + "/"));
            }
        }
        static byte[] Slice(byte[] b, long n) { if (b.Length <= n) return b; var o = new byte[n]; Array.Copy(b, o, n); return o; }
        byte[] Chain(uint start)
        {
            var ms = new MemoryStream();
            uint s = start; int n = 0;
            while (s < END && s < fat.Count && n <= fat.Count)
            {
                long off = ((long)s + 1) * ss;
                int len = (int)Math.Min(ss, Math.Max(0, d.Length - off));
                if (len > 0) ms.Write(d, (int)off, len);
                s = fat[(int)s]; n++;
            }
            return ms.ToArray();
        }
        public byte[] Read(string path)
        {
            uint[] st = streams[path];
            uint start = st[0], size = st[1];
            if (size < cutoff)
            {
                var ms = new MemoryStream();
                uint s = start; int n = 0;
                while (s < END && s < minifat.Count && n <= minifat.Count && ms.Length < size)
                {
                    long off = (long)s * mss;
                    int len = (int)Math.Min(mss, Math.Max(0, ministream.Length - off));
                    if (len > 0) ms.Write(ministream, (int)off, len);
                    s = minifat[(int)s]; n++;
                }
                return Slice(ms.ToArray(), size);
            }
            return Slice(Chain(start), size);
        }
        public string Find(params string[] names)
        {
            foreach (var n in names)
                foreach (var k in Order) if (string.Equals(k, n, StringComparison.OrdinalIgnoreCase)) return k;
            return null;
        }
    }

    // ------------------------------------------------------------------ engine
    public class Engine
    {
        public List<Rule> Rules = new List<Rule>();
        public HashSet<string> Known = new HashSet<string>();
        public Dictionary<string, int> Weights = new Dictionary<string, int>();
        public Dictionary<string, string> ClassMap = new Dictionary<string, string>();
        public HashSet<string> PhiIds = new HashSet<string>(), PhiEvidence = new HashSet<string>(), PersonalCats = new HashSet<string>();
        public string HealthRule = "";
        public int MinHealthTerms = 2, PhiBonus = 25, NegWindow = 20, MinConf = 2, MaxSamples = 5, MaxDepth = 2;
        public long MaxBytes = 25L << 20;
        public bool ShowRaw, Archives = true;
        public Dictionary<string, string> Sev = new Dictionary<string, string>(), Cat = new Dictionary<string, string>();
        public int FilesDone;
        public ConcurrentQueue<string> Warnings = new ConcurrentQueue<string>();
        static readonly string[] ConfName = { "", "Low", "Medium", "High" };

        public static readonly HashSet<string> TextExt = new HashSet<string>(".txt .log .json .xml .html .htm .md .ini .cfg .conf .config .yaml .yml .sql .ps1 .psm1 .py .bat .cmd .sh .properties .env .eml .rtf .vcf .ldif .reg .js .ts .java .cs .php .hl7".Split(' '));
        public static readonly HashSet<string> CsvExt = new HashSet<string> { ".csv", ".tsv" };
        public static readonly HashSet<string> OoxmlExt = new HashSet<string> { ".docx", ".docm", ".xlsx", ".xlsm", ".pptx", ".pptm" };
        public static readonly HashSet<string> OdfExt = new HashSet<string> { ".odt", ".ods", ".odp" };
        public static readonly HashSet<string> LegacyExt = new HashSet<string> { ".doc", ".xls", ".ppt", ".msg" };
        public static readonly HashSet<string> PstExt = new HashSet<string> { ".pst", ".ost" };
        public static readonly HashSet<string> AllExt;
        static Engine()
        {
            AllExt = new HashSet<string>(TextExt);
            AllExt.UnionWith(CsvExt); AllExt.UnionWith(OoxmlExt); AllExt.UnionWith(OdfExt); AllExt.UnionWith(LegacyExt); AllExt.UnionWith(PstExt);
            AllExt.Add(".pdf"); AllExt.Add(".zip");
        }

        public void AddRule(string name, string cat, string sev, string pattern, int group, string validator, string kind, int baseConf,
                            string[] ctx, bool ctxReq, int ctxWin, string[] neg, string fmt, string[] trig)
        {
            if (!string.IsNullOrEmpty(validator) && !V.Names.Contains(validator)) throw new ArgumentException("rule " + name + ": unknown validator " + validator);
            Rules.Add(new Rule {
                Name = name, Category = cat, Severity = sev, Group = group, Validator = string.IsNullOrEmpty(validator) ? null : validator,
                Kind = string.IsNullOrEmpty(kind) ? "id" : kind, BaseConf = baseConf, CtxRequired = ctxReq, CtxWindow = ctxWin,
                Rx = new Regex(pattern, RegexOptions.Compiled | RegexOptions.CultureInvariant),
                FormatRx = string.IsNullOrEmpty(fmt) ? null : new Regex(fmt, RegexOptions.CultureInvariant),
                Context = (ctx ?? new string[0]).Select(x => x.ToLowerInvariant()).ToArray(),
                NegContext = (neg ?? new string[0]).Select(x => x.ToLowerInvariant()).ToArray(),
                Trigger = (trig ?? new string[0]).Select(x => x.ToLowerInvariant()).ToArray() });
            Sev[name] = sev; Cat[name] = cat;
        }
        public void AddKnown(string v) { Known.Add(NormKnown(v)); }
        static string NormKnown(string v)
        {
            var sb = new StringBuilder();
            foreach (char c in v.ToUpperInvariant()) if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z')) sb.Append(c);
            return sb.ToString();
        }
        static string AsciiLower(string s)
        {
            var a = s.ToCharArray();
            for (int i = 0; i < a.Length; i++) if (a[i] >= 'A' && a[i] <= 'Z') a[i] = (char)(a[i] + 32);
            return new string(a);
        }
        static bool AnyIn(string lower, string[] keys, int from, int to)
        {
            foreach (var k in keys)
            {
                int idx = lower.IndexOf(k, from, to - from, StringComparison.Ordinal);
                if (idx >= 0) return true;
            }
            return false;
        }
        static int BisectRight(List<int> a, int x)
        {
            int lo = 0, hi = a.Count;
            while (lo < hi) { int mid = (lo + hi) / 2; if (x < a[mid]) hi = mid; else lo = mid + 1; }
            return lo;
        }

        public List<Hit> ScanText(string text, out int suppressed)
        {
            suppressed = 0;
            var hits = new List<Hit>();
            if (string.IsNullOrEmpty(text)) return hits;
            string lower = AsciiLower(text);
            var starts = new List<int>(); var ends = new List<int>();
            List<int> nl = null;
            foreach (var r in Rules)
            {
                if (r.Trigger.Length > 0 && !AnyIn(lower, r.Trigger, 0, lower.Length)) continue;
                if (r.CtxRequired && !AnyIn(lower, r.Context, 0, lower.Length)) continue;
                foreach (System.Text.RegularExpressions.Match m in r.Rx.Matches(text))
                {
                    var g = m.Groups[r.Group];
                    int s = g.Index, e = g.Index + g.Length;
                    int i = BisectRight(starts, s);
                    if ((i > 0 && ends[i - 1] > s) || (i < starts.Count && starts[i] < e)) continue;
                    string v = g.Value;
                    if (r.Validator != null && !V.Call(r.Validator, v)) continue;
                    int conf = r.BaseConf;
                    if (r.Context.Length > 0)
                    {
                        bool hit = AnyIn(lower, r.Context, Math.Max(0, s - r.CtxWindow), s);
                        if (r.CtxRequired && !hit) continue;
                        if (hit && !r.CtxRequired) conf++;
                    }
                    if (r.NegContext.Length > 0 && AnyIn(lower, r.NegContext, Math.Max(0, s - NegWindow), s)) continue;
                    if (r.FormatRx != null && r.FormatRx.IsMatch(v)) conf++;
                    if (Known.Count > 0 && Known.Contains(NormKnown(v))) conf = 1;
                    if (conf > 3) conf = 3;
                    if (conf < MinConf) { suppressed++; continue; }
                    starts.Insert(i, s); ends.Insert(i, e);
                    if (nl == null) { nl = new List<int>(); for (int k = 0; k < text.Length; k++) if (text[k] == '\n') nl.Add(k); }
                    hits.Add(new Hit { Rule = r, Value = v, Line = BisectRight(nl, s) + 1, Conf = conf });
                }
            }
            return hits;
        }

        public static string Mask(string value, string kind)
        {
            string v = value.Trim();
            if (kind == "term") return v;
            if (kind == "email" && v.Contains("@"))
            {
                int at = v.IndexOf('@'); string user = v.Substring(0, at), dom = v.Substring(at + 1);
                return user.Length > 0 ? user.Substring(0, 1) + "***@" + dom : "***@" + dom;
            }
            if (kind == "secret") return v.Length > 6 ? v.Substring(0, 2) + "******" : "******";
            if (v.Length <= 4) return new string('*', v.Length);
            var a = v.ToCharArray(); int keep = 4;
            for (int i = a.Length - 1; i >= 0; i--)
                if (char.IsLetterOrDigit(a[i])) { if (keep > 0) keep--; else a[i] = 'X'; }
            return new string(a);
        }

        public string ConfLabel(int c) { return ConfName[c]; }

        // ---------------------------------------------------- accumulation & classification
        public Accumulator Begin(FileResult r) { return new Accumulator { Res = r }; }
        public void AddSegment(Accumulator acc, string prefix, string text)
        {
            int supp;
            var hits = ScanText(text, out supp);
            acc.Res.Suppressed += supp;
            foreach (var h in hits)
            {
                string t = h.Rule.Name;
                int c; acc.Res.Counts.TryGetValue(t, out c); acc.Res.Counts[t] = c + 1;
                if (t == HealthRule) acc.Health.Add(h.Value.ToLowerInvariant());
                int sc; acc.Samples.TryGetValue(t, out sc);
                if (sc < MaxSamples)
                {
                    acc.Samples[t] = sc + 1;
                    acc.Res.Findings.Add(new Finding { Type = t, Category = h.Rule.Category, Severity = h.Rule.Severity,
                        Confidence = ConfName[h.Conf], Value = ShowRaw ? h.Value : Mask(h.Value, h.Rule.Kind),
                        Where = (prefix + " line " + h.Line).Trim() });
                }
            }
        }
        public void Finish(Accumulator acc)
        {
            var r = acc.Res;
            var types = r.Counts.Keys.ToList();
            bool hasId = types.Any(t => PhiIds.Contains(t));
            bool evidence = types.Any(t => PhiEvidence.Contains(t)) || acc.Health.Count >= MinHealthTerms;
            bool personal = types.Any(t => Cat.ContainsKey(t) && PersonalCats.Contains(Cat[t]));
            r.Phi = hasId || (evidence && personal);
            var scoring = r.Counts.Where(kv => r.Phi || kv.Key != HealthRule).ToList();
            r.RiskScore = scoring.Sum(kv => Weights[Sev[kv.Key]] * kv.Value) + (r.Phi ? PhiBonus : 0);
            r.TopSeverity = "";
            foreach (var s in new[] { "Critical", "High", "Medium", "Low" })
                if (scoring.Any(kv => Sev[kv.Key] == s)) { r.TopSeverity = s; break; }
            r.Classification = r.Phi ? "Restricted" : (ClassMap.ContainsKey(r.TopSeverity) ? ClassMap[r.TopSeverity] : "");
        }

        // ---------------------------------------------------- extraction
        public static string Decode(byte[] b)
        {
            if (b.Length >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF) return Encoding.UTF8.GetString(b, 3, b.Length - 3);
            if (b.Length >= 2 && b[0] == 0xFF && b[1] == 0xFE) return Encoding.Unicode.GetString(b, 2, b.Length - 2);
            if (b.Length >= 2 && b[0] == 0xFE && b[1] == 0xFF) return Encoding.BigEndianUnicode.GetString(b, 2, b.Length - 2);
            try { return new UTF8Encoding(false, true).GetString(b); }
            catch (DecoderFallbackException) { return Encoding.GetEncoding(1252).GetString(b); }
        }
        static readonly Regex Tag = new Regex("<[^>]+>", RegexOptions.Compiled);
        static readonly Regex BlockEnd = new Regex(@"</(?:w:p|a:p|text:p|table:table-row|tr|p|div|br)>|<br\s*/?>", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        public static string StripMarkup(string xml) { return WebUtility.HtmlDecode(Tag.Replace(BlockEnd.Replace(xml, "\n"), " ")); }

        public static string RowsToText(List<List<string>> rows)
        {
            rows = rows.Where(r => r.Any(c => c.Trim().Length > 0)).ToList();
            if (rows.Count == 0) return "";
            var header = rows[0].Select(h => h.Trim()).ToList();
            var named = header.Where(h => h.Length > 0).ToList();
            bool useHeader = named.Count > 0 && named.Count(h => !h.Any(char.IsDigit)) * 2 >= named.Count;
            var sb = new StringBuilder(string.Join(" | ", rows[0]));
            for (int ri = 1; ri < rows.Count; ri++)
            {
                var r = rows[ri];
                sb.Append('\n');
                if (useHeader)
                {
                    var parts = new List<string>();
                    for (int i = 0; i < r.Count; i++)
                        if (r[i].Trim().Length > 0)
                            parts.Add((i < header.Count && header[i].Length > 0 ? header[i] : "col" + (i + 1)) + ": " + r[i]);
                    sb.Append(string.Join(" | ", parts));
                }
                else sb.Append(string.Join(" | ", r));
            }
            return sb.ToString();
        }

        static List<List<string>> ParseCsv(string text, char delim)
        {
            var rows = new List<List<string>>(); var row = new List<string>(); var cell = new StringBuilder();
            bool q = false; int i = 0;
            while (i < text.Length)
            {
                char c = text[i];
                if (q)
                {
                    if (c == '"') { if (i + 1 < text.Length && text[i + 1] == '"') { cell.Append('"'); i++; } else q = false; }
                    else cell.Append(c);
                }
                else if (c == '"' && cell.Length == 0) q = true;
                else if (c == delim) { row.Add(cell.ToString()); cell.Clear(); }
                else if (c == '\r' || c == '\n')
                {
                    if (c == '\r' && i + 1 < text.Length && text[i + 1] == '\n') i++;
                    row.Add(cell.ToString()); cell.Clear(); rows.Add(row); row = new List<string>();
                }
                else cell.Append(c);
                i++;
            }
            if (cell.Length > 0 || row.Count > 0) { row.Add(cell.ToString()); rows.Add(row); }
            return rows;
        }
        static string CsvText(byte[] b, string ext)
        {
            string text = Decode(b);
            char delim = ext == ".tsv" ? '\t' : ',';
            if (ext == ".csv")
            {
                int nl = text.IndexOf('\n'); string first = nl > 0 ? text.Substring(0, nl) : text;
                int best = first.Count(c => c == ',');
                foreach (char cand in new[] { ';', '\t', '|' }) { int n = first.Count(c => c == cand); if (n > best) { best = n; delim = cand; } }
            }
            return RowsToText(ParseCsv(text, delim));
        }

        static string NormNumber(string v)
        {
            if (v.IndexOf('E') >= 0 || v.IndexOf('e') >= 0 || v.EndsWith(".0"))
            {
                double f;
                if (double.TryParse(v, NumberStyles.Float, CultureInfo.InvariantCulture, out f) && Math.Floor(f) == f && Math.Abs(f) < 1e16)
                    return ((long)f).ToString(CultureInfo.InvariantCulture);
            }
            return v;
        }
        static string FmtNum(double f)
        {
            if (!double.IsNaN(f) && Math.Floor(f) == f && Math.Abs(f) < 1e16) return ((long)f).ToString(CultureInfo.InvariantCulture);
            return f.ToString("R", CultureInfo.InvariantCulture);
        }
        static int ColIndex(string r)
        {
            int n = 0;
            foreach (char ch in r) { if (ch >= 'A' && ch <= 'Z') n = n * 26 + ch - 64; else break; }
            return Math.Max(n - 1, 0);
        }
        static string ReadEntry(ZipArchiveEntry e)
        {
            using (var sr = new StreamReader(e.Open(), Encoding.UTF8)) return sr.ReadToEnd();
        }
        static byte[] ReadEntryBytes(ZipArchiveEntry e)
        {
            using (var s = e.Open()) using (var ms = new MemoryStream()) { s.CopyTo(ms); return ms.ToArray(); }
        }

        static void XlsxSegments(ZipArchive z, List<KeyValuePair<string, string>> outp)
        {
            var shared = new List<string>();
            var sse = z.GetEntry("xl/sharedStrings.xml");
            if (sse != null)
                using (var xr = XmlReader.Create(sse.Open()))
                {
                    StringBuilder cur = null;
                    bool pending = false;   // ReadElementContentAsString leaves the reader ON the next node
                    while (pending || xr.Read())
                    {
                        pending = false;
                        if (xr.NodeType == XmlNodeType.Element && xr.LocalName == "si") { cur = new StringBuilder(); if (xr.IsEmptyElement) { shared.Add(""); cur = null; } }
                        else if (xr.NodeType == XmlNodeType.Element && xr.LocalName == "t" && cur != null && !xr.IsEmptyElement) { cur.Append(xr.ReadElementContentAsString()); pending = true; }
                        else if (xr.NodeType == XmlNodeType.EndElement && xr.LocalName == "si" && cur != null) { shared.Add(cur.ToString()); cur = null; }
                    }
                }
            var sheets = z.Entries.Where(e => e.FullName.StartsWith("xl/worksheets/sheet") && e.FullName.EndsWith(".xml"))
                .OrderBy(e => { var dg = Regex.Replace(e.FullName, @"\D", ""); return dg.Length > 0 ? int.Parse(dg) : 0; }).ToList();
            foreach (var se in sheets)
            {
                var rows = new List<List<string>>();
                using (var xr = XmlReader.Create(se.Open()))
                {
                    Dictionary<int, string> cells = null;
                    string ct = null; int ci = 0; string val = null; bool inIs = false; StringBuilder isb = null;
                    bool pending = false;   // ReadElementContentAsString leaves the reader ON the next node
                    while (pending || xr.Read())
                    {
                        pending = false;
                        if (xr.NodeType == XmlNodeType.Element)
                        {
                            switch (xr.LocalName)
                            {
                                case "row": cells = new Dictionary<int, string>(); if (xr.IsEmptyElement) cells = null; break;
                                case "c":
                                    ct = xr.GetAttribute("t"); ci = ColIndex(xr.GetAttribute("r") ?? "A"); val = "";
                                    if (xr.IsEmptyElement && cells != null) cells[ci] = "";
                                    break;
                                case "v": if (!xr.IsEmptyElement) { val = xr.ReadElementContentAsString(); pending = true; } break;
                                case "is": inIs = true; isb = new StringBuilder(); break;
                                case "t": if (inIs && !xr.IsEmptyElement) { isb.Append(xr.ReadElementContentAsString()); pending = true; } break;
                            }
                        }
                        else if (xr.NodeType == XmlNodeType.EndElement)
                        {
                            if (xr.LocalName == "is") { inIs = false; val = isb.ToString(); }
                            else if (xr.LocalName == "c" && cells != null)
                            {
                                int idx;
                                if (ct == "s" && val.Length > 0 && val.All(char.IsDigit) && int.TryParse(val, out idx) && idx < shared.Count) val = shared[idx];
                                else if (ct != "s" && ct != "inlineStr" && ct != "str") val = NormNumber(val);
                                cells[ci] = val;
                            }
                            else if (xr.LocalName == "row" && cells != null)
                            {
                                if (cells.Count > 0) { int mx = cells.Keys.Max(); var row = new List<string>(); for (int i = 0; i <= mx; i++) { string cv; row.Add(cells.TryGetValue(i, out cv) ? cv : ""); } rows.Add(row); }
                                cells = null;
                            }
                        }
                    }
                }
                string nm = Path.GetFileName(se.FullName);
                outp.Add(new KeyValuePair<string, string>("sheet " + nm.Substring(5, nm.Length - 9), RowsToText(rows)));
            }
        }

        static void OoxmlSegments(byte[] b, string ext, List<KeyValuePair<string, string>> outp)
        {
            using (var z = new ZipArchive(new MemoryStream(b), ZipArchiveMode.Read))
            {
                if (ext == ".xlsx" || ext == ".xlsm") { XlsxSegments(z, outp); return; }
                var parts = new List<string>();
                string[] pre = { "word/document", "word/header", "word/footer", "word/comments", "word/footnotes", "ppt/slides/slide", "ppt/notesSlides/" };
                foreach (var e in z.Entries)
                    if (e.FullName.EndsWith(".xml") && pre.Any(p => e.FullName.StartsWith(p))) parts.Add(StripMarkup(ReadEntry(e)));
                outp.Add(new KeyValuePair<string, string>("", string.Join("\n", parts)));
            }
        }

        static readonly Regex U16Run = new Regex(@"(?:[\x20-\x7e\t\r\n]\x00|[\x00-\x7f]\x09){4,}", RegexOptions.Compiled);
        static readonly Regex A8Run = new Regex(@"[\x20-\x7e\t\r\n]{4,}", RegexOptions.Compiled);
        static readonly Encoding Latin1 = Encoding.GetEncoding(28591);
        public static string BinaryTextRuns(byte[] b)
        {
            string s = Latin1.GetString(b);
            var parts = new List<string>();
            foreach (System.Text.RegularExpressions.Match m in U16Run.Matches(s)) parts.Add(Encoding.Unicode.GetString(Latin1.GetBytes(m.Value)));
            foreach (System.Text.RegularExpressions.Match m in A8Run.Matches(s)) parts.Add(m.Value);
            return string.Join("\n", parts.Select(p => p.Replace("\r", "\n")));
        }

        static double Rk(uint v)
        {
            double val = (v & 2) != 0 ? (double)(((int)v) >> 2) : BitConverter.Int64BitsToDouble((long)((ulong)(v & 0xFFFFFFFC) << 32));
            return (v & 1) != 0 ? val / 100 : val;
        }
        static string XlUnicode(byte[] d, int pos)
        {
            int cch = BitConverter.ToUInt16(d, pos); pos += 2;
            int flags = d[pos]; pos += 1;
            if ((flags & 1) != 0) return Encoding.Unicode.GetString(d, pos, Math.Min(cch * 2, d.Length - pos));
            return Latin1.GetString(d, pos, Math.Min(cch, d.Length - pos));
        }
        static List<string> ParseSst(List<byte[]> chunks)
        {
            var outp = new List<string>();
            int ci = 0, pos = 8;
            Func<int, byte[]> need = n =>
            {
                var buf = new List<byte>();
                while (n > 0)
                {
                    while (ci < chunks.Count && pos >= chunks[ci].Length) { ci++; pos = 0; }
                    if (ci >= chunks.Count) throw new EndOfStreamException();
                    int take = Math.Min(n, chunks[ci].Length - pos);
                    for (int k = 0; k < take; k++) buf.Add(chunks[ci][pos + k]);
                    pos += take; n -= take;
                }
                return buf.ToArray();
            };
            try
            {
                uint total = BitConverter.ToUInt32(chunks[0], 4);
                while (outp.Count < total)
                {
                    int cch = BitConverter.ToUInt16(need(2), 0);
                    int flags = need(1)[0];
                    int high = flags & 1;
                    int runs = (flags & 8) != 0 ? BitConverter.ToUInt16(need(2), 0) : 0;
                    long ext = (flags & 4) != 0 ? BitConverter.ToUInt32(need(4), 0) : 0;
                    var sb = new StringBuilder(); int left = cch;
                    while (left > 0)
                    {
                        if (pos >= chunks[ci].Length)
                        {
                            ci++; pos = 0;
                            if (ci >= chunks.Count) throw new EndOfStreamException();
                            high = chunks[ci][0] & 1; pos = 1;
                        }
                        int width = high != 0 ? 2 : 1;
                        int take = Math.Min(left, (chunks[ci].Length - pos) / width);
                        if (take <= 0) throw new EndOfStreamException();
                        sb.Append(high != 0 ? Encoding.Unicode.GetString(chunks[ci], pos, take * 2) : Latin1.GetString(chunks[ci], pos, take));
                        pos += take * width; left -= take;
                    }
                    outp.Add(sb.ToString());
                    if (runs > 0 || ext > 0) need((int)(runs * 4 + ext));
                }
            }
            catch (EndOfStreamException) { }
            catch (ArgumentException) { }
            return outp;
        }

        static void XlsSegments(Cfb cfb, List<KeyValuePair<string, string>> outp)
        {
            string name = cfb.Find("Workbook", "Book");
            if (name == null) return;
            byte[] wb = cfb.Read(name);
            var recs = new List<KeyValuePair<int, byte[]>>();
            int pos = 0;
            while (pos + 4 <= wb.Length)
            {
                int typ = BitConverter.ToUInt16(wb, pos), ln = BitConverter.ToUInt16(wb, pos + 2);
                int avail = Math.Max(0, Math.Min(ln, wb.Length - pos - 4));
                var data = new byte[avail]; Array.Copy(wb, pos + 4, data, 0, avail);
                recs.Add(new KeyValuePair<int, byte[]>(typ, data));
                pos += 4 + ln;
            }
            var sst = new List<string>();
            var sheets = new List<Dictionary<long, string>>();
            Dictionary<long, string> cur = null;
            long pendingFormula = -1;
            for (int i = 0; i < recs.Count; i++)
            {
                int typ = recs[i].Key; byte[] data = recs[i].Value;
                try
                {
                    if (typ == 0x0809 && data.Length >= 4)
                    {
                        cur = BitConverter.ToUInt16(data, 2) == 0x0010 ? new Dictionary<long, string>() : null;
                        if (cur != null) sheets.Add(cur);
                    }
                    else if (typ == 0x00FC)
                    {
                        var chunks = new List<byte[]> { data };
                        while (i + 1 < recs.Count && recs[i + 1].Key == 0x003C) { i++; chunks.Add(recs[i].Value); }
                        sst = ParseSst(chunks);
                    }
                    else if (cur != null && data.Length >= 6)
                    {
                        int row = BitConverter.ToUInt16(data, 0), col = BitConverter.ToUInt16(data, 2);
                        long key = ((long)row << 16) | (uint)col;
                        if (typ == 0x00FD) { uint idx = BitConverter.ToUInt32(data, 6); cur[key] = idx < sst.Count ? sst[(int)idx] : ""; }
                        else if (typ == 0x0204) cur[key] = XlUnicode(data, 6);
                        else if (typ == 0x0203) cur[key] = FmtNum(BitConverter.ToDouble(data, 6));
                        else if (typ == 0x027E) cur[key] = FmtNum(Rk(BitConverter.ToUInt32(data, 6)));
                        else if (typ == 0x00BD)
                        {
                            int n = (data.Length - 6) / 6;
                            for (int k = 0; k < n; k++) cur[((long)row << 16) | (uint)(col + k)] = FmtNum(Rk(BitConverter.ToUInt32(data, 4 + k * 6 + 2)));
                        }
                        else if (typ == 0x0006 && data.Length >= 14)
                        {
                            if (data[12] == 0xFF && data[13] == 0xFF) pendingFormula = data[6] == 0 ? key : -1;
                            else cur[key] = FmtNum(BitConverter.ToDouble(data, 6));
                        }
                    }
                    if (typ == 0x0207 && cur != null && pendingFormula >= 0) { cur[pendingFormula] = XlUnicode(data, 0); pendingFormula = -1; }
                }
                catch (ArgumentException) { }
                catch (IndexOutOfRangeException) { }
            }
            for (int n = 0; n < sheets.Count; n++)
            {
                var cells = sheets[n];
                if (cells.Count == 0) continue;
                int maxr = (int)cells.Keys.Max(k => k >> 16), maxc = (int)cells.Keys.Max(k => k & 0xFFFF);
                var rows = new List<List<string>>();
                for (int r = 0; r <= maxr; r++)
                {
                    var row = new List<string>();
                    for (int c = 0; c <= maxc; c++) { string v; row.Add(cells.TryGetValue(((long)r << 16) | (uint)c, out v) ? v : ""); }
                    rows.Add(row);
                }
                outp.Add(new KeyValuePair<string, string>("sheet " + (n + 1), RowsToText(rows)));
            }
        }

        void MsgSegments(Cfb cfb, int depth, List<KeyValuePair<string, string>> outp)
        {
            var texts = new List<string>();
            var attachOrder = new List<string>();
            var attach = new Dictionary<string, Dictionary<string, string>>();
            foreach (var path in cfb.Order)
            {
                int slash = path.LastIndexOf('/');
                string top = slash >= 0 ? path.Substring(0, slash) : "", leaf = slash >= 0 ? path.Substring(slash + 1) : path;
                if (top.StartsWith("__attach_version1.0_"))
                {
                    if (!attach.ContainsKey(top)) { attach[top] = new Dictionary<string, string>(); attachOrder.Add(top); }
                    attach[top][leaf] = path; continue;
                }
                if (leaf.EndsWith("001F")) texts.Add(Encoding.Unicode.GetString(cfb.Read(path)));
                else if (leaf.EndsWith("001E")) texts.Add(Encoding.GetEncoding(1252).GetString(cfb.Read(path)));
                else if (leaf.StartsWith("__substg1.0_1013")) texts.Add(StripMarkup(Decode(cfb.Read(path))));
            }
            outp.Add(new KeyValuePair<string, string>("", string.Join("\n", texts.Select(t => t.Replace("\0", "")))));
            foreach (var st in attachOrder)
            {
                var mem = attach[st];
                string dataP;
                if (!mem.TryGetValue("__substg1.0_37010102", out dataP)) continue;
                string fname = "";
                foreach (var k in new[] { "__substg1.0_3707001F", "__substg1.0_3704001F" })
                    if (mem.ContainsKey(k)) { fname = Encoding.Unicode.GetString(cfb.Read(mem[k])).Trim('\0'); break; }
                byte[] data = cfb.Read(dataP);
                string ext = Path.GetExtension(fname).ToLowerInvariant();
                if (ext.Length == 0) ext = Sniff(data);
                foreach (var kv in Extract(data, ext, depth + 1))
                    outp.Add(new KeyValuePair<string, string>("attachment " + (fname.Length > 0 ? fname : st) + (kv.Key.Length > 0 ? " " + kv.Key : ""), kv.Value));
            }
        }

        public static string Sniff(byte[] b)
        {
            if (b.Length >= 4 && b[0] == 'P' && b[1] == 'K' && b[2] == 3 && b[3] == 4)
            {
                try
                {
                    using (var z = new ZipArchive(new MemoryStream(b), ZipArchiveMode.Read))
                    {
                        var names = z.Entries.Select(e => e.FullName).ToList();
                        if (names.Any(n => n.StartsWith("word/"))) return ".docx";
                        if (names.Any(n => n.StartsWith("xl/"))) return ".xlsx";
                        if (names.Any(n => n.StartsWith("ppt/"))) return ".pptx";
                    }
                }
                catch (InvalidDataException) { return ""; }
                return ".zip";
            }
            if (Cfb.IsCfb(b))
            {
                try
                {
                    var c = new Cfb(b);
                    if (c.Find("WordDocument") != null) return ".doc";
                    if (c.Find("Workbook", "Book") != null) return ".xls";
                    if (c.Find("PowerPoint Document") != null) return ".ppt";
                    if (c.Order.Any(s => s.StartsWith("__substg1.0_"))) return ".msg";
                }
                catch (Exception) { return ""; }
            }
            if (b.Length >= 5 && b[0] == '%' && b[1] == 'P' && b[2] == 'D' && b[3] == 'F' && b[4] == '-') return ".pdf";
            int n2 = Math.Min(2048, b.Length);
            if (n2 > 0)
            {
                int bad = 0;
                for (int i = 0; i < n2; i++) if (b[i] < 9 || (b[i] > 13 && b[i] < 32)) bad++;
                if (bad < n2 * 0.02) return ".txt";
            }
            return "";
        }

        public List<KeyValuePair<string, string>> Extract(byte[] b, string ext, int depth)
        {
            var outp = new List<KeyValuePair<string, string>>();
            if (depth > MaxDepth) return outp;
            if (TextExt.Contains(ext)) outp.Add(new KeyValuePair<string, string>("", Decode(b)));
            else if (CsvExt.Contains(ext)) outp.Add(new KeyValuePair<string, string>("", CsvText(b, ext)));
            else if (OoxmlExt.Contains(ext)) OoxmlSegments(b, ext, outp);
            else if (OdfExt.Contains(ext))
                using (var z = new ZipArchive(new MemoryStream(b), ZipArchiveMode.Read))
                    outp.Add(new KeyValuePair<string, string>("", StripMarkup(ReadEntry(z.GetEntry("content.xml")))));
            else if (LegacyExt.Contains(ext))
            {
                var cfb = new Cfb(b);
                if (ext == ".xls") XlsSegments(cfb, outp);
                else if (ext == ".msg") MsgSegments(cfb, depth, outp);
                else
                {
                    string nm = ext == ".doc" ? cfb.Find("WordDocument") : cfb.Find("PowerPoint Document");
                    if (nm != null) outp.Add(new KeyValuePair<string, string>("", BinaryTextRuns(cfb.Read(nm))));
                }
            }
            else if (ext == ".zip")
            {
                using (var z = new ZipArchive(new MemoryStream(b), ZipArchiveMode.Read))
                    foreach (var e in z.Entries)
                    {
                        string mext = Path.GetExtension(e.FullName).ToLowerInvariant();
                        if (e.FullName.EndsWith("/") || !AllExt.Contains(mext) || PstExt.Contains(mext) || e.Length > MaxBytes) continue;
                        byte[] data;
                        try { data = ReadEntryBytes(e); } catch (Exception) { continue; }
                        foreach (var kv in Extract(data, mext, depth + 1))
                            outp.Add(new KeyValuePair<string, string>(e.FullName + (kv.Key.Length > 0 ? " " + kv.Key : ""), kv.Value));
                    }
            }
            return outp;
        }

        // ---------------------------------------------------- files
        public FileResult NewResult(string path)
        {
            var res = new FileResult { Path = path };
            try
            {
                var fi = new FileInfo(path);
                res.Size = fi.Length;
                res.Modified = fi.LastWriteTime.ToString("yyyy-MM-dd'T'HH:mm:ss", CultureInfo.InvariantCulture);
            }
            catch (Exception ex) { res.Status = "error: " + ex.Message; }
            return res;
        }

        public FileResult ScanFile(string path)
        {
            var res = NewResult(path);
            if (res.Status != "ok") return res;
            string ext = Path.GetExtension(path).ToLowerInvariant();
            try
            {
                if (PstExt.Contains(ext)) { res.Status = "unsupported: use -IncludePst (needs Outlook) or the Python scanner with libpff-python"; res.PendingPst = true; return res; }
                if (ext == ".zip" && !Archives) { res.Status = "skipped: archives disabled"; return res; }
                if (ext == ".pdf") { res.Status = "unsupported: PDF needs the Python scanner with pypdf"; return res; }
                if (res.Size > MaxBytes)
                {
                    if (!TextExt.Contains(ext) && !CsvExt.Contains(ext)) { res.Status = "skipped: too large"; return res; }
                    res.Status = "partial: first " + (MaxBytes >> 20) + " MB scanned";
                }
                byte[] data;
                using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    int len = (int)Math.Min(fs.Length, MaxBytes);
                    data = new byte[len]; int read = 0;
                    while (read < len) { int n = fs.Read(data, read, len - read); if (n <= 0) break; read += n; }
                    if (read < len) Array.Resize(ref data, read);
                }
                var acc = Begin(res);
                foreach (var kv in Extract(data, ext, 0)) AddSegment(acc, kv.Key, kv.Value);
                Finish(acc);
            }
            catch (Exception ex)
            {
                string m = "error: " + ex.GetType().Name + ": " + ex.Message;
                res.Status = m.Length > 300 ? m.Substring(0, 300) : m;
                res.Counts.Clear(); res.Findings.Clear(); res.Classification = ""; res.RiskScore = 0; res.Phi = false;
            }
            return res;
        }

        static bool IsReparse(string dir)
        {
            try { return (File.GetAttributes(dir) & FileAttributes.ReparsePoint) != 0; } catch (Exception) { return true; }
        }
        static string[] SafeFiles(string d) { try { return Directory.GetFiles(d); } catch (Exception) { return new string[0]; } }
        static string[] SafeDirs(string d) { try { return Directory.GetDirectories(d); } catch (Exception) { return new string[0]; } }

        public IEnumerable<string> Walk(string[] roots, HashSet<string> excl)
        {
            foreach (var root in roots)
            {
                if (File.Exists(root)) { yield return root; continue; }
                if (!Directory.Exists(root)) { Warnings.Enqueue("not found or not accessible: " + root); continue; }
                var stack = new Stack<string>(); stack.Push(root);
                while (stack.Count > 0)
                {
                    string dir = stack.Pop();
                    foreach (var f in SafeFiles(dir))
                    {
                        string fn = Path.GetFileName(f);
                        if (AllExt.Contains(Path.GetExtension(fn).ToLowerInvariant()) && !fn.StartsWith("~$")) yield return f;
                    }
                    foreach (var sub in SafeDirs(dir))
                        if (!excl.Contains(Path.GetFileName(sub).ToLowerInvariant()) && !IsReparse(sub)) stack.Push(sub);
                }
            }
        }

        public Task<List<FileResult>> StartScan(string[] roots, string[] excludes, int threads)
        {
            var excl = new HashSet<string>(excludes.Select(x => x.ToLowerInvariant()));
            return Task.Factory.StartNew(() =>
            {
                var oldMode = System.Runtime.GCSettings.LatencyMode;
                System.Runtime.GCSettings.LatencyMode = System.Runtime.GCLatencyMode.SustainedLowLatency; // fewer blocking GCs
                var bag = new ConcurrentBag<FileResult>();
                Parallel.ForEach(Partitioner.Create(Walk(roots, excl), EnumerablePartitionerOptions.NoBuffering),
                    new ParallelOptions { MaxDegreeOfParallelism = Math.Max(1, threads) },
                    p => { bag.Add(ScanFile(p)); Interlocked.Increment(ref FilesDone); });
                System.Runtime.GCSettings.LatencyMode = oldMode;
                return bag.ToList();
            }, TaskCreationOptions.LongRunning);
        }

        // ---------------------------------------------------- output
        public static string J(string s)
        {
            if (s == null) return "null";
            var sb = new StringBuilder(s.Length + 2); sb.Append('"');
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default: if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4")); else sb.Append(c); break;
                }
            }
            return sb.Append('"').ToString();
        }
        static string B(bool b) { return b ? "true" : "false"; }
        static string Dict(IEnumerable<KeyValuePair<string, int>> d) { return "{" + string.Join(",", d.Select(kv => J(kv.Key) + ":" + kv.Value)) + "}"; }

        public string HostDocJson(string metaJson, List<FileResult> all, AdResult ad, double duration)
        {
            var hits = all.Where(r => r.Classification.Length > 0).OrderByDescending(r => r.RiskScore).ToList();
            var byType = new Dictionary<string, int>(); var byCat = new Dictionary<string, int>();
            var byClass = new Dictionary<string, int> { { "Restricted", 0 }, { "Confidential", 0 }, { "Internal", 0 } };
            foreach (var r in all)
            {
                foreach (var kv in r.Counts)
                {
                    int c; byType.TryGetValue(kv.Key, out c); byType[kv.Key] = c + kv.Value;
                    string cat = Cat[kv.Key]; byCat.TryGetValue(cat, out c); byCat[cat] = c + kv.Value;
                }
                if (r.Classification.Length > 0) byClass[r.Classification]++;
            }
            if (ad != null)
                foreach (var f in ad.Findings)
                {
                    int c; byType.TryGetValue(f.Type, out c); byType[f.Type] = c + 1;
                    byCat.TryGetValue(f.Category, out c); byCat[f.Category] = c + 1;
                }
            var sb = new StringBuilder();
            sb.Append("{\"schema\":\"pii-scan/2\",\"meta\":").Append(metaJson).Append(",\"summary\":{");
            sb.Append("\"files_examined\":").Append(all.Count);
            sb.Append(",\"files_with_pii\":").Append(hits.Count);
            sb.Append(",\"files_phi\":").Append(all.Count(r => r.Phi));
            sb.Append(",\"files_errored_or_skipped\":").Append(all.Count(r => r.Status != "ok"));
            sb.Append(",\"suppressed_low_confidence\":").Append(all.Sum(r => r.Suppressed));
            sb.Append(",\"files_by_classification\":").Append(Dict(byClass));
            sb.Append(",\"matches_by_type\":").Append(Dict(byType.OrderByDescending(kv => kv.Value)));
            sb.Append(",\"matches_by_category\":").Append(Dict(byCat.OrderByDescending(kv => kv.Value)));
            sb.Append(",\"ad_findings\":").Append(ad == null ? 0 : ad.Findings.Count);
            sb.Append(",\"duration_seconds\":").Append(Math.Round(duration, 1).ToString(CultureInfo.InvariantCulture)).Append("},\n\"files\":[");
            for (int i = 0; i < hits.Count; i++)
            {
                var r = hits[i];
                if (i > 0) sb.Append(",\n");
                sb.Append("{\"path\":").Append(J(r.Path)).Append(",\"size\":").Append(r.Size).Append(",\"modified\":").Append(J(r.Modified))
                  .Append(",\"owner\":").Append(J(r.Owner)).Append(",\"status\":").Append(J(r.Status)).Append(",\"classification\":").Append(J(r.Classification))
                  .Append(",\"top_severity\":").Append(J(r.TopSeverity)).Append(",\"risk_score\":").Append(r.RiskScore).Append(",\"phi\":").Append(B(r.Phi))
                  .Append(",\"counts\":").Append(Dict(r.Counts)).Append(",\"suppressed\":").Append(r.Suppressed).Append(",\"findings\":[");
                sb.Append(string.Join(",", r.Findings.Select(f => "{\"type\":" + J(f.Type) + ",\"category\":" + J(f.Category) + ",\"severity\":" + J(f.Severity)
                    + ",\"confidence\":" + J(f.Confidence) + ",\"value\":" + J(f.Value) + ",\"where\":" + J(f.Where) + "}")));
                sb.Append("]}");
            }
            sb.Append("],\n\"errors\":[");
            sb.Append(string.Join(",", all.Where(r => r.Status != "ok").Take(5000).Select(r => "{\"path\":" + J(r.Path) + ",\"status\":" + J(r.Status) + "}")));
            sb.Append("],\n\"active_directory\":");
            if (ad == null) sb.Append("null");
            else
            {
                sb.Append("{\"objects_scanned\":").Append(ad.ObjectsScanned).Append(",\"base\":").Append(J(ad.Base))
                  .Append(",\"structured_attribute_counts\":").Append(Dict(ad.Structured)).Append(",\"findings\":[");
                sb.Append(string.Join(",", ad.Findings.Select(f => "{\"object\":" + J(f.Object) + ",\"objectClass\":" + J(f.ObjectClass) + ",\"attribute\":" + J(f.Attribute)
                    + ",\"type\":" + J(f.Type) + ",\"category\":" + J(f.Category) + ",\"severity\":" + J(f.Severity) + ",\"confidence\":" + J(f.Confidence)
                    + ",\"value\":" + J(f.Value) + "}")));
                sb.Append("]}");
            }
            sb.Append("}");
            return sb.ToString();
        }

        static string C(object o)
        {
            string s = o == null ? "" : Convert.ToString(o, CultureInfo.InvariantCulture);
            return "\"" + s.Replace("\"", "\"\"") + "\"";
        }
        public void WriteCsvs(string basePath, string host, List<FileResult> all, AdResult ad)
        {
            var enc = new UTF8Encoding(true);
            var sorted = all.OrderByDescending(r => r.RiskScore).ToList();
            using (var w = new StreamWriter(basePath + "_findings.csv", false, enc))
            {
                w.WriteLine("Host,Source,PathOrObject,Where,PIIType,Category,Severity,Confidence,Value,Classification,PHI");
                foreach (var r in sorted.Where(x => x.Classification.Length > 0))
                    foreach (var f in r.Findings)
                        w.WriteLine(string.Join(",", new[] { C(host), C("File"), C(r.Path), C(f.Where), C(f.Type), C(f.Category), C(f.Severity), C(f.Confidence), C(f.Value), C(r.Classification), C(r.Phi ? "True" : "False") }));
                if (ad != null)
                    foreach (var f in ad.Findings)
                        w.WriteLine(string.Join(",", new[] { C(host), C("ActiveDirectory"), C(f.Object), C(f.Attribute), C(f.Type), C(f.Category), C(f.Severity), C(f.Confidence), C(f.Value), C(f.Severity == "Critical" ? "Restricted" : "Confidential"), C("False") }));
            }
            using (var w = new StreamWriter(basePath + "_files.csv", false, enc))
            {
                w.WriteLine("Path,SizeBytes,Modified,Owner,Classification,PHI,TopSeverity,RiskScore,PIITypes,SuppressedLowConfidence,Status");
                foreach (var r in sorted)
                    w.WriteLine(string.Join(",", new[] { C(r.Path), C(r.Size), C(r.Modified), C(r.Owner), C(r.Classification), C(r.Phi ? "True" : "False"), C(r.TopSeverity),
                        C(r.RiskScore), C(string.Join("; ", r.Counts.Select(kv => kv.Key + "=" + kv.Value))), C(r.Suppressed), C(r.Status) }));
            }
        }
    }

    // ------------------------------------------------------------------ SMB authentication (WNetAddConnection2)
    public static class Smb
    {
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        class NETRESOURCE
        {
            public int dwScope, dwType, dwDisplayType, dwUsage;
            public string lpLocalName, lpRemoteName, lpComment, lpProvider;
        }
        [DllImport("mpr.dll", CharSet = CharSet.Unicode)]
        static extern int WNetAddConnection2(NETRESOURCE nr, string password, string user, int flags);
        [DllImport("mpr.dll", CharSet = CharSet.Unicode)]
        static extern int WNetCancelConnection2(string name, int flags, bool force);
        public static int Connect(string host, string user, string password)
        {
            return WNetAddConnection2(new NETRESOURCE { lpRemoteName = @"\\" + host + @"\IPC$" }, password, user, 0);
        }
        public static int Disconnect(string host) { return WNetCancelConnection2(@"\\" + host + @"\IPC$", 0, true); }
    }
}
'@

if (-not ('PiiScan.Engine' -as [type])) {
    Add-Type -AssemblyName System.IO.Compression
    $refs = @([System.IO.Compression.ZipArchive].Assembly.Location, [System.Xml.XmlReader].Assembly.Location,
              [System.Linq.Enumerable].Assembly.Location, [System.Uri].Assembly.Location)
    if ($PSVersionTable.PSEdition -eq 'Core') { Add-Type -TypeDefinition $EngineSource -Language CSharp }
    else { Add-Type -TypeDefinition $EngineSource -Language CSharp -ReferencedAssemblies $refs }
}

# =============================================================================================
# Rules
# =============================================================================================
function New-PiiEngine {
    if (-not $RulesJson) {
        $candidates = @($RulesFile, (Join-Path $PSScriptRoot '..\rules\pii_rules.json'), (Join-Path $PSScriptRoot 'pii_rules.json')) | Where-Object { $_ }
        $rf = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
        if (-not $rf) { throw "Rules file not found (looked in: $($candidates -join ', ')). Use -RulesFile." }
        $script:RulesJson = [IO.File]::ReadAllText((Resolve-Path $rf).Path)
    }
    $cfg = $RulesJson | ConvertFrom-Json
    $e = New-Object PiiScan.Engine
    foreach ($p in $cfg.severity_weight.PSObject.Properties) { $e.Weights[$p.Name] = [int]$p.Value }
    foreach ($p in $cfg.classification.PSObject.Properties) { $e.ClassMap[$p.Name] = [string]$p.Value }
    foreach ($x in $cfg.phi.identifier_rules) { [void]$e.PhiIds.Add($x) }
    foreach ($x in $cfg.phi.evidence_rules) { [void]$e.PhiEvidence.Add($x) }
    foreach ($x in $cfg.phi.personal_categories) { [void]$e.PersonalCats.Add($x) }
    $e.HealthRule = $cfg.phi.health_term_rule; $e.MinHealthTerms = $cfg.phi.min_distinct_health_terms; $e.PhiBonus = $cfg.phi.risk_bonus
    if ($cfg.neg_context_window) { $e.NegWindow = $cfg.neg_context_window }
    foreach ($k in $cfg.known_test_values) { $e.AddKnown($k) }
    $win = if ($cfg.context_window) { [int]$cfg.context_window } else { 60 }
    foreach ($r in $cfg.rules) {
        $get = { param($n, $def) if ($r.PSObject.Properties[$n]) { $r.$n } else { $def } }
        $e.AddRule($r.name, $r.category, $r.severity, $r.pattern, [int](& $get 'group' 0), [string](& $get 'validator' ''),
            [string](& $get 'kind' 'id'), [int](& $get 'base_confidence' 2), [string[]]@(& $get 'context' @()),
            [bool](& $get 'context_required' $false), [int](& $get 'context_window' $win), [string[]]@(& $get 'neg_context' @()),
            [string](& $get 'format_boost' ''), [string[]]@(& $get 'trigger' @()))
    }
    $e.MinConf = if ($MinConfidence) { @{ Low = 1; Medium = 2; High = 3 }[$MinConfidence] } else { [int]$cfg.default_min_confidence }
    $e.MaxSamples = $MaxSamples; $e.MaxBytes = [long]($MaxFileSizeMB * 1MB); $e.ShowRaw = [bool]$ShowRaw; $e.Archives = -not $NoArchives
    return @{ Engine = $e; Version = $cfg.version }
}

# =============================================================================================
# Active Directory (ADSI) and network helpers
# =============================================================================================
function New-ADSearcher([string]$Filter, [string[]]$Props) {
    $ldap = 'LDAP://'
    if ($ADServer) { $ldap += $ADServer + '/' }
    if ($ADSearchBase) { $ldap += $ADSearchBase }
    else {
        $rootPath = if ($ADServer) { "LDAP://$ADServer/RootDSE" } else { 'LDAP://RootDSE' }
        $rootDse = if ($Credential) { New-Object DirectoryServices.DirectoryEntry($rootPath, $Credential.UserName, $Credential.GetNetworkCredential().Password) } else { New-Object DirectoryServices.DirectoryEntry($rootPath) }
        $nc = $null
        try { $nc = $rootDse.Properties['defaultNamingContext'] } catch { }
        if (-not $nc -or -not $nc.Count) {
            throw "Cannot reach a domain controller$(if ($ADServer) { " at $ADServer" }). On a non-domain-joined machine use -ADServer <dc fqdn/ip> -Credential <DOMAIN\user> (and check TCP 389 is reachable)."
        }
        $ldap += [string]$nc[0]
    }
    $root = if ($Credential) { New-Object DirectoryServices.DirectoryEntry($ldap, $Credential.UserName, $Credential.GetNetworkCredential().Password) } else { New-Object DirectoryServices.DirectoryEntry($ldap) }
    $ds = New-Object DirectoryServices.DirectorySearcher($root, $Filter)
    $ds.PageSize = 500
    foreach ($p in $Props) { [void]$ds.PropertiesToLoad.Add($p) }
    return $ds
}

$AdFreeText   = @('description','info','comment','notes','admindescription','physicaldeliveryofficename') + (1..15 | ForEach-Object { "extensionattribute$_" })
$AdStructured = @('employeeid','employeenumber','telephonenumber','mobile','homephone','streetaddress','postalcode','othermobile','ipphone','pager')
$AdPwdAttrs   = @('userpassword','unixuserpassword','unicodepwd','mssfu30password','os400password')

function Invoke-ADScan($Engine) {
    Say '[*] Scanning Active Directory object attributes ...'
    $ds = New-ADSearcher '(|(objectClass=user)(objectClass=contact)(objectClass=computer)(objectClass=group))' (@('samaccountname','distinguishedname','objectclass') + $AdFreeText + $AdStructured + $AdPwdAttrs)
    $ad = New-Object PiiScan.AdResult
    $ad.Base = [string]$ds.SearchRoot.Path
    foreach ($a in $AdStructured) { $ad.Structured[$a] = 0 }
    $all = $ds.FindAll()
    try {
        foreach ($r in $all) {
            $ad.ObjectsScanned++
            $p = $r.Properties
            $name = if ($p['samaccountname'].Count) { [string]$p['samaccountname'][0] } else { [string]$p['distinguishedname'][0] }
            $oc = if ($p['objectclass'].Count) { [string]$p['objectclass'][$p['objectclass'].Count - 1] } else { '' }
            foreach ($a in $AdStructured) { if ($p[$a].Count) { $ad.Structured[$a]++ } }
            foreach ($a in $AdPwdAttrs) {
                if ($p[$a].Count) { $ad.Findings.Add((New-Object PiiScan.AdFinding -Property @{ Object = $name; ObjectClass = $oc; Attribute = $a; Type = 'Password attribute populated'; Category = 'Credential'; Severity = 'Critical'; Confidence = 'High'; Value = '******' })) }
            }
            foreach ($a in $AdFreeText) {
                if (-not $p[$a].Count) { continue }
                $text = (@($p[$a]) | ForEach-Object { [string]$_ }) -join "`n"
                $supp = 0
                $hits = $Engine.ScanText($text, [ref]$supp)
                $hasPwd = $false
                foreach ($h in $hits) {
                    if ($h.Rule.Name -eq 'Password in Clear Text') { $hasPwd = $true }
                    $v = if ($ShowRaw) { $h.Value } else { [PiiScan.Engine]::Mask($h.Value, $h.Rule.Kind) }
                    $ad.Findings.Add((New-Object PiiScan.AdFinding -Property @{ Object = $name; ObjectClass = $oc; Attribute = $a; Type = $h.Rule.Name; Category = $h.Rule.Category; Severity = $h.Rule.Severity; Confidence = $Engine.ConfLabel($h.Conf); Value = $v }))
                }
                if (-not $hasPwd -and $text -match '(?i)\b(pw|pwd|pass(word)?|kennwort|temp ?pass)\b') {
                    $ad.Findings.Add((New-Object PiiScan.AdFinding -Property @{ Object = $name; ObjectClass = $oc; Attribute = $a; Type = 'Possible password reference'; Category = 'Credential'; Severity = 'High'; Confidence = 'Low'; Value = '(review manually)' }))
                }
            }
        }
    } finally { $all.Dispose() }
    return $ad
}

function Get-ADComputers {
    $ds = New-ADSearcher '(&(objectCategory=computer)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))' @('dnshostname','name')
    $all = $ds.FindAll()
    try { foreach ($r in $all) { if ($r.Properties['dnshostname'].Count) { [string]$r.Properties['dnshostname'][0] } else { [string]$r.Properties['name'][0] } } }
    finally { $all.Dispose() }
}

function Test-Port445([string]$HostName) {
    $c = New-Object Net.Sockets.TcpClient
    try { $ar = $c.BeginConnect($HostName, 445, $null, $null); return ($ar.AsyncWaitHandle.WaitOne(1500) -and $c.Connected) }
    catch { return $false } finally { $c.Close() }
}

function Get-RemoteShares([string]$HostName) {
    $out = & net.exe view "\\$HostName" /all 2>$null
    foreach ($line in $out) {
        if ($line -match '^(.+?)\s{2,}Disk\b') {
            $share = $Matches[1].Trim()
            if ($share -in @('ADMIN$', 'IPC$', 'print$')) { continue }
            if (-not $IncludeAdminShares -and $share -match '^[A-Za-z]\$$') { continue }
            "\\$HostName\$share"
        }
    }
}

# =============================================================================================
# Outlook PST / OST (optional, needs Outlook with a profile on this machine)
# =============================================================================================
function Invoke-PstScan($Engine, $Results) {
    $pending = @($Results | Where-Object { $_.PendingPst })
    if (-not $pending) { return }
    Say "[*] Scanning $($pending.Count) PST/OST file(s) through Outlook ..."
    try { $ol = New-Object -ComObject Outlook.Application; $ns = $ol.GetNamespace('MAPI') }
    catch { Write-Warning "Outlook not available: $($_.Exception.Message)"; return }
    $tmp = Join-Path $env:TEMP ('piipst_' + [guid]::NewGuid().ToString('N')); New-Item -ItemType Directory $tmp | Out-Null
    foreach ($res in $pending) {
        $store = $null
        try {
            $before = @($ns.Stores | ForEach-Object { $_.StoreID })
            $ns.AddStore($res.Path)
            $store = @($ns.Stores | Where-Object { $before -notcontains $_.StoreID })[0]
            if (-not $store) { throw 'store did not mount' }
            $res.Counts.Clear(); $res.Findings.Clear(); $res.Status = 'ok'; $res.PendingPst = $false
            $acc = $Engine.Begin($res); $n = 0
            $stack = New-Object System.Collections.Stack; $stack.Push($store.GetRootFolder())
            while ($stack.Count) {
                $f = $stack.Pop()
                foreach ($sf in $f.Folders) { $stack.Push($sf) }
                foreach ($it in $f.Items) {
                    $n++
                    $parts = foreach ($prop in 'Subject', 'SenderEmailAddress', 'To', 'CC', 'Body') { try { [string]$it.$prop } catch { '' } }
                    $Engine.AddSegment($acc, "msg $n", ($parts -join "`n"))
                    try {
                        foreach ($att in $it.Attachments) {
                            $fn = Join-Path $tmp ([IO.Path]::GetFileName([string]$att.FileName))
                            $att.SaveAsFile($fn)
                            $bytes = [IO.File]::ReadAllBytes($fn); Remove-Item $fn -Force
                            $ext = [IO.Path]::GetExtension($fn).ToLowerInvariant(); if (-not $ext) { $ext = [PiiScan.Engine]::Sniff($bytes) }
                            foreach ($kv in $Engine.Extract($bytes, $ext, 1)) { $Engine.AddSegment($acc, ("msg $n attachment $($att.FileName) " + $kv.Key).Trim(), $kv.Value) }
                        }
                    } catch { }
                }
            }
            $Engine.Finish($acc)
        } catch { $res.Status = "error: PST via Outlook: $($_.Exception.Message)" }
        finally { if ($store) { try { $ns.RemoveStore($store.GetRootFolder()) } catch { } } }
    }
    Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
}

# =============================================================================================
# HTML report (works for one host or a merged estate)
# =============================================================================================
function HtmlEnc([object]$s) { return [Net.WebUtility]::HtmlEncode([string]$s) }
function Get-Props($o) { if ($null -eq $o) { @() } else { @($o.PSObject.Properties) } }

function Get-HostRow($d) {
    $s = $d.summary; $m = $d.meta
    $risk = 0; foreach ($f in @($d.files)) { $risk += [int]$f.risk_score }
    $top = (Get-Props $s.matches_by_type | Select-Object -First 4 | ForEach-Object { "$($_.Name) ($($_.Value))" }) -join ', '
    [ordered]@{ Host = $m.host; Scanner = $m.scanner; Started = $m.started; FilesExamined = [int]$s.files_examined; FilesWithPII = [int]$s.files_with_pii
        Restricted = [int]$s.files_by_classification.Restricted; Confidential = [int]$s.files_by_classification.Confidential
        Internal = [int]$s.files_by_classification.Internal; PHIFiles = [int]$s.files_phi; ADFindings = [int]$s.ad_findings; RiskTotal = $risk; TopTypes = $top }
}

function Get-Aggregate($Docs) {
    $t = [ordered]@{ files_examined = 0; files_with_pii = 0; files_phi = 0; files_errored_or_skipped = 0; suppressed_low_confidence = 0; ad_findings = 0
        files_by_classification = [ordered]@{ Restricted = 0; Confidential = 0; Internal = 0 }; matches_by_type = @{}; matches_by_category = @{} }
    foreach ($d in $Docs) {
        $s = $d.summary
        foreach ($k in 'files_examined', 'files_with_pii', 'files_phi', 'files_errored_or_skipped', 'suppressed_low_confidence', 'ad_findings') { $t[$k] += [int]$s.$k }
        foreach ($k in 'Restricted', 'Confidential', 'Internal') { $t.files_by_classification[$k] += [int]$s.files_by_classification.$k }
        foreach ($key in 'matches_by_type', 'matches_by_category') { foreach ($p in (Get-Props $s.$key)) { $t[$key][$p.Name] = [int]$t[$key][$p.Name] + [int]$p.Value } }
    }
    foreach ($key in 'matches_by_type', 'matches_by_category') {
        $o = [ordered]@{}; foreach ($kv in ($t[$key].GetEnumerator() | Sort-Object Value -Descending)) { $o[$kv.Key] = $kv.Value }; $t[$key] = $o
    }
    return $t
}

function ConvertTo-HtmlReport($Docs, [string]$Title) {
    $tot = Get-Aggregate $Docs
    $sevCls = @{ Critical = 'crit'; High = 'high'; Medium = 'med'; Low = 'low' }
    $clsCls = @{ Restricted = 'crit'; Confidential = 'high'; Internal = 'med' }
    $cats = @{}; $sevs = @{}
    foreach ($d in $Docs) {
        foreach ($r in @($d.files)) { foreach ($f in @($r.findings)) { $cats[$f.type] = $f.category; $sevs[$f.type] = $f.severity } }
        if ($d.active_directory) { foreach ($f in @($d.active_directory.findings)) { $cats[$f.type] = $f.category; $sevs[$f.type] = $f.severity } }
    }
    $sb = New-Object Text.StringBuilder
    $typeRows = foreach ($k in $tot.matches_by_type.Keys) { "<tr><td>$(HtmlEnc $k)</td><td>$(HtmlEnc $cats[$k])</td><td><span class='pill $($sevCls[$sevs[$k]])'>$(HtmlEnc $sevs[$k])</span></td><td class='num'>$($tot.matches_by_type[$k])</td></tr>" }
    $hostRowsData = @($Docs | ForEach-Object { Get-HostRow $_ } | Sort-Object { $_.RiskTotal } -Descending)
    $hostCols = ($hostRowsData[0].Keys | ForEach-Object { "<th>$_</th>" }) -join ''
    $hostRows = foreach ($h in $hostRowsData) { '<tr>' + (($h.Values | ForEach-Object { if ($_ -is [int]) { "<td class='num'>$_</td>" } else { "<td>$(HtmlEnc $_)</td>" } }) -join '') + '</tr>' }
    $files = New-Object System.Collections.Generic.List[object]
    foreach ($d in $Docs) { foreach ($r in @($d.files)) { $files.Add([pscustomobject]@{ H = $d.meta.host; R = $r; Risk = [int]$r.risk_score }) } }
    $sorted = @($files | Sort-Object Risk -Descending | Select-Object -First 2000)
    $fileRows = foreach ($x in $sorted) {
        $r = $x.R
        $types = (Get-Props $r.counts | ForEach-Object { "$(HtmlEnc $_.Name) ($($_.Value))" }) -join ', '
        $smp = (@($r.findings) | Select-Object -First 6 | ForEach-Object { "$(HtmlEnc $_.type): <code>$(HtmlEnc $_.value)</code> <span class='muted'>$(HtmlEnc $_.confidence) &middot; $(HtmlEnc $_.where)</span>" }) -join '<br>'
        $phi = if ($r.phi) { " <span class='pill phi'>PHI</span>" } else { '' }
        "<tr><td><span class='pill $($clsCls[$r.classification])'>$(HtmlEnc $r.classification)</span>$phi</td><td class='num'>$($r.risk_score)</td><td>$(HtmlEnc $x.H)</td><td class='path'>$(HtmlEnc $r.path)</td><td>$types</td><td class='small'>$smp</td><td class='small'>$(HtmlEnc $r.owner)</td><td class='small'>$(HtmlEnc $r.modified)</td></tr>"
    }
    $adHtml = foreach ($d in $Docs) {
        $ad = $d.active_directory; if (-not $ad) { continue }
        $rows = (@($ad.findings) | ForEach-Object { "<tr><td><span class='pill $($sevCls[$_.severity])'>$(HtmlEnc $_.severity)</span></td><td>$(HtmlEnc $_.object)</td><td>$(HtmlEnc $_.objectClass)</td><td>$(HtmlEnc $_.attribute)</td><td>$(HtmlEnc $_.type)</td><td>$(HtmlEnc $_.confidence)</td><td><code>$(HtmlEnc $_.value)</code></td></tr>" }) -join ''
        if (-not $rows) { $rows = '<tr><td colspan=7>None</td></tr>' }
        $st = (Get-Props $ad.structured_attribute_counts | ForEach-Object { "<tr><td>$(HtmlEnc $_.Name)</td><td class='num'>$($_.Value)</td></tr>" }) -join ''
        "<h2>Active Directory <span class='muted'>($(HtmlEnc $d.meta.host))</span></h2><p>$($ad.objects_scanned) objects scanned under <code>$(HtmlEnc $ad.base)</code></p><h3>PII in free-text attributes</h3><table><thead><tr><th>Severity</th><th>Object</th><th>Class</th><th>Attribute</th><th>Type</th><th>Confidence</th><th>Value</th></tr></thead><tbody>$rows</tbody></table><h3>Objects holding structured PII attributes</h3><table class='narrow'><thead><tr><th>Attribute</th><th>Objects</th></tr></thead><tbody>$st</tbody></table>"
    }
    $c = $tot.files_by_classification
    $masked = if (@($Docs | Where-Object { $_.meta.show_raw }).Count) { '<b>UNMASKED</b>' } else { 'masked' }
    $scopes = ($Docs | ForEach-Object { "$($_.meta.host): " + $(if (@($_.meta.paths).Count) { @($_.meta.paths) -join ', ' } else { '(AD only)' }) }) -join '; '
    $more = if ($files.Count -gt 2000) { ', top 2000' } else { '' }
    if (-not $typeRows) { $typeRows = '<tr><td colspan=4>None</td></tr>' }
    if (-not $fileRows) { $fileRows = '<tr><td colspan=8>No PII found</td></tr>' }
    @"
<!doctype html><html><head><meta charset="utf-8"><title>$(HtmlEnc $Title)</title><style>
body{font-family:Segoe UI,Arial,sans-serif;background:#f7f8fa;color:#1d2230;margin:0;padding:24px}
h1{margin:0 0 4px} h2{margin-top:28px} .muted,.meta{color:#667} .meta{margin-bottom:20px;font-size:13px}
.cards{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:24px}
.card{background:#fff;border:1px solid #e3e6ec;border-radius:8px;padding:14px 18px;min-width:130px}
.card b{display:block;font-size:26px} .card span{color:#667;font-size:13px}
table{border-collapse:collapse;width:100%;background:#fff;margin-bottom:20px;font-size:13px} table.narrow{max-width:560px}
th,td{border:1px solid #e3e6ec;padding:6px 8px;text-align:left;vertical-align:top} th{background:#eef0f4}
.num{text-align:right} .path{word-break:break-all;max-width:380px} .small{font-size:12px}
code{background:#f0f1f4;padding:1px 4px;border-radius:3px}
.pill{padding:2px 8px;border-radius:10px;font-size:12px;font-weight:600;white-space:nowrap}
.crit{background:#fde2e1;color:#a4161a} .high{background:#ffe8cc;color:#9a4a00}
.med{background:#fff3bf;color:#6b5900} .low{background:#e7f0ff;color:#1c4fa0} .phi{background:#efe2fd;color:#5b1aa4}
</style></head><body>
<h1>$(HtmlEnc $Title)</h1>
<div class="meta">Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm') &middot; Values $masked &middot; Rules v$(HtmlEnc $Docs[0].meta.rules_version) &middot; Min confidence $(HtmlEnc $Docs[0].meta.min_confidence)<br>Scope: $(HtmlEnc $scopes)</div>
<div class="cards">
<div class="card"><b>$($Docs.Count)</b><span>scans / hosts</span></div>
<div class="card"><b>$($tot.files_examined)</b><span>files examined</span></div>
<div class="card"><b>$($tot.files_with_pii)</b><span>files with PII/PHI</span></div>
<div class="card"><b style="color:#a4161a">$($c.Restricted)</b><span>Restricted</span></div>
<div class="card"><b style="color:#9a4a00">$($c.Confidential)</b><span>Confidential</span></div>
<div class="card"><b style="color:#6b5900">$($c.Internal)</b><span>Internal</span></div>
<div class="card"><b style="color:#5b1aa4">$($tot.files_phi)</b><span>files with PHI</span></div>
<div class="card"><b>$($tot.ad_findings)</b><span>AD findings</span></div>
<div class="card"><b class="muted">$($tot.suppressed_low_confidence)</b><span>low-confidence suppressed</span></div>
</div>
<h2>Hosts</h2><table><thead><tr>$hostCols</tr></thead><tbody>$($hostRows -join '')</tbody></table>
<h2>Matches by type</h2><table class="narrow"><thead><tr><th>Type</th><th>Category</th><th>Severity</th><th>Matches</th></tr></thead><tbody>$($typeRows -join '')</tbody></table>
<h2>Files containing PII / PHI (highest risk first$more)</h2>
<table><thead><tr><th>Classification</th><th>Risk</th><th>Host</th><th>Path</th><th>Types</th><th>Samples</th><th>Owner</th><th>Modified</th></tr></thead>
<tbody>$($fileRows -join "`n")</tbody></table>
$($adHtml -join "`n")
<p class="meta"><b>Restricted</b>: Critical identifiers or credentials (Aadhaar, PAN, ABHA, card, passport, SSN, passwords, keys), or any file flagged PHI.
<b>Confidential</b>: High (bank account, IBAN, DOB, voter ID, DL, UHID/MRN, ICD-10, insurance/claim no).
<b>Internal</b>: Medium/Low only (mobile, email, GSTIN, IFSC, IP).
<b>PHI</b>: a patient identifier (ABHA, UHID/MRN, PM-JAY) or health evidence (ICD-10, blood group, 2+ medical terms) together with a personal identifier.
Confidence: High = checksum/format + context, Medium = validated or context, Low = pattern only (hidden by default).</p>
</body></html>
"@
}

function Write-Utf8([string]$File, [string]$Text) { [IO.File]::WriteAllText($File, $Text, (New-Object Text.UTF8Encoding($true))) }

# =============================================================================================
# Merge mode
# =============================================================================================
function Invoke-Merge {
    $docs = New-Object System.Collections.Generic.List[object]
    foreach ($f in (Get-ChildItem -Path $MergeFrom -Recurse -Filter '*_summary.json' -File)) {
        try {
            $d = [IO.File]::ReadAllText($f.FullName) | ConvertFrom-Json
            if ($d.schema -eq $Schema) { $docs.Add($d) }
        } catch { Write-Warning "skipping $($f.FullName): $($_.Exception.Message)" }
    }
    if (-not $docs.Count) { throw "No $Schema *_summary.json files under $MergeFrom" }
    if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }
    $base = Join-Path (Resolve-Path $OutputDir).Path ('ESTATE_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $rows = foreach ($d in $docs) {
        foreach ($r in @($d.files)) { foreach ($x in @($r.findings)) {
            [pscustomobject][ordered]@{ Host = $d.meta.host; Source = 'File'; PathOrObject = $r.path; Where = $x.where; PIIType = $x.type; Category = $x.category; Severity = $x.severity; Confidence = $x.confidence; Value = $x.value; Classification = $r.classification; PHI = $r.phi } } }
        if ($d.active_directory) { foreach ($x in @($d.active_directory.findings)) {
            [pscustomobject][ordered]@{ Host = $d.meta.host; Source = 'ActiveDirectory'; PathOrObject = $x.object; Where = $x.attribute; PIIType = $x.type; Category = $x.category; Severity = $x.severity; Confidence = $x.confidence; Value = $x.value; Classification = $(if ($x.severity -eq 'Critical') { 'Restricted' } else { 'Confidential' }); PHI = $false } } }
    }
    $rows | Export-Csv "${base}_findings.csv" -NoTypeInformation -Encoding UTF8
    $hostRows = @($docs | ForEach-Object { [pscustomobject](Get-HostRow $_) })
    $hostRows | Export-Csv "${base}_hosts.csv" -NoTypeInformation -Encoding UTF8
    $tot = Get-Aggregate $docs
    Write-Utf8 "${base}_summary.json" ([ordered]@{ schema = 'pii-estate/2'; generated = (Get-Date).ToString('s'); hosts = $hostRows; summary = $tot } | ConvertTo-Json -Depth 6)
    Write-Utf8 "${base}_report.html" (ConvertTo-HtmlReport $docs "PII / PHI Estate Report - $($docs.Count) scan(s)")
    Say "[+] Merged $($docs.Count) scan(s): $($tot.files_with_pii) files with PII, $($tot.files_phi) PHI, $($tot.ad_findings) AD findings"
    Say "[+] Estate report: ${base}_report.html / _hosts.csv / _findings.csv / _summary.json"
    if ($PassThru) { [pscustomobject]@{ Base = $base; Summary = $tot } }
}

# =============================================================================================
# Main
# =============================================================================================
if ($MergeFrom) { Invoke-Merge; return }

$started = Get-Date
$sw = [Diagnostics.Stopwatch]::StartNew()
$built = New-PiiEngine
$engine = $built.Engine

$targets = New-Object System.Collections.Generic.List[string]
foreach ($p in $Path) { $targets.Add($p) }
if ($AllDrives) { foreach ($d in [IO.DriveInfo]::GetDrives()) { if ($d.DriveType -eq 'Fixed' -and $d.IsReady) { $targets.Add($d.RootDirectory.FullName) } } }
$hosts = @($ComputerName)
if ($ComputerListFile) { $hosts += @(Get-Content $ComputerListFile | Where-Object { $_ -and -not $_.StartsWith('#') } | ForEach-Object { $_.Trim() }) }
if ($DiscoverComputersFromAD) {
    Say '[*] Enumerating enabled computer accounts from AD ...'
    $hosts += @(Get-ADComputers)
    Say "    $($hosts.Count) computer(s)"
}
$hosts = @($hosts | Where-Object { $_ } | Sort-Object -Unique)

$connected = @()
if ($Credential) {
    $uncHosts = @($Path | ForEach-Object { if ($_ -match '^[\\/]{2}([^\\/]+)') { $Matches[1] } })
    foreach ($h in (@($hosts) + $uncHosts | Sort-Object -Unique)) {
        $rc = [PiiScan.Smb]::Connect($h, $Credential.UserName, $Credential.GetNetworkCredential().Password)
        if ($rc -eq 0) { $connected += $h } elseif ($rc -ne 1219) { Write-Warning "SMB authentication to $h failed (Win32 error $rc)" }
    }
}
foreach ($h in $hosts) {
    if (-not (Test-Port445 $h)) { Write-Warning "SMB (445) unreachable: $h"; continue }
    $shares = @(Get-RemoteShares $h)
    Say "    $h : $($shares.Count) share(s)"
    foreach ($s in $shares) { $targets.Add($s) }
}
if ($targets.Count -eq 0 -and -not $ScanAD) { Write-Error 'Nothing to scan. Use -Path, -AllDrives, -ComputerName, -ComputerListFile, -DiscoverComputersFromAD, -ScanAD or -MergeFrom.'; return }

$exclude = New-Object System.Collections.Generic.List[string]
if (-not $NoDefaultExcludes) { foreach ($x in @('windows','program files','program files (x86)','$recycle.bin','system volume information','programdata','appdata','node_modules','.git','winsxs','$windows.~bt','$windows.~ws','__pycache__','.venv','site-packages')) { $exclude.Add($x) } }
foreach ($x in $ExcludeDir) { $exclude.Add($x) }

$results = New-Object System.Collections.Generic.List[PiiScan.FileResult]
if ($targets.Count) {
    Say "[*] Scanning $($targets.Count) location(s) with $Threads threads (min confidence $($engine.ConfLabel($engine.MinConf))) ..."
    $task = $engine.StartScan($targets.ToArray(), $exclude.ToArray(), $Threads)
    while (-not $task.Wait(1000)) {
        if (-not $Quiet) { Write-Progress -Activity 'PII / PHI scan' -Status "$($engine.FilesDone) files examined, $([int]$sw.Elapsed.TotalSeconds)s" }
    }
    Write-Progress -Activity 'PII / PHI scan' -Completed
    if ($task.IsFaulted) { throw $task.Exception.InnerException }
    $results.AddRange($task.Result)
    $w = $null; while ($engine.Warnings.TryDequeue([ref]$w)) { Write-Warning $w }
    if ($IncludePst) { Invoke-PstScan $engine $results }
    if ($IncludeOwner) { foreach ($r in $results) { if ($r.Classification) { try { $r.Owner = (Get-Acl -LiteralPath $r.Path -ErrorAction Stop).Owner } catch { } } } }
}
foreach ($h in $connected) { [void][PiiScan.Smb]::Disconnect($h) }

$ad = $null
if ($ScanAD) { try { $ad = Invoke-ADScan $engine } catch { Write-Warning "AD scan failed: $($_.Exception.Message)" } }

$meta = [ordered]@{ host = $env:COMPUTERNAME; scanner = "powershell/$ScannerVersion"; paths = @($targets); started = $started.ToString('s')
    show_raw = [bool]$ShowRaw; user = "$env:USERDOMAIN\$env:USERNAME"; rules_version = $built.Version; min_confidence = $engine.ConfLabel($engine.MinConf)
    finished = (Get-Date).ToString('s'); duration = [math]::Round($sw.Elapsed.TotalSeconds, 1) }
$metaJson = $meta | ConvertTo-Json -Compress -Depth 4
if (@($targets).Count -eq 1) { $metaJson = $metaJson -replace '"paths":("(?:[^"\\]|\\.)*")', '"paths":[$1]' }   # PS 5.1 unrolls 1-element arrays
if (@($targets).Count -eq 0) { $metaJson = $metaJson -replace '"paths":(null|""|\{\})', '"paths":[]' }

if (-not (Test-Path $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }
$base = Join-Path (Resolve-Path $OutputDir).Path ("PII_{0}_{1}" -f $env:COMPUTERNAME, (Get-Date -Format 'yyyyMMdd_HHmmss'))
$docJson = $engine.HostDocJson($metaJson, $results, $ad, $sw.Elapsed.TotalSeconds)
Write-Utf8 "${base}_summary.json" $docJson
$engine.WriteCsvs($base, $env:COMPUTERNAME, $results, $ad)
$doc = $docJson | ConvertFrom-Json
Write-Utf8 "${base}_report.html" (ConvertTo-HtmlReport @($doc) "PII / PHI Scan Report - $env:COMPUTERNAME")

$s = $doc.summary
Say ("[+] {0} files in {1}s: {2} with PII (Restricted {3}, Confidential {4}, Internal {5}), PHI {6}, suppressed low-confidence {7}, AD {8}" -f `
    $s.files_examined, $meta.duration, $s.files_with_pii, $s.files_by_classification.Restricted, $s.files_by_classification.Confidential,
    $s.files_by_classification.Internal, $s.files_phi, $s.suppressed_low_confidence, $s.ad_findings)
Say "[+] Reports: ${base}_report.html / _findings.csv / _files.csv / _summary.json"
if ($PassThru) { [pscustomobject]@{ Base = $base; Summary = $s } }
