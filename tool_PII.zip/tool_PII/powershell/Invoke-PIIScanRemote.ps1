<#
.SYNOPSIS
    Fan-out wrapper: runs Invoke-PIIScan.ps1 ON many Windows hosts in parallel via WinRM, collects their
    reports back to this machine and builds one consolidated estate report.

.DESCRIPTION
    * Nothing is installed on targets: the scanner and rules are sent as text over the WinRM session and
      executed in memory (execution policy does not apply to script blocks; AMSI still inspects them).
    * Each host scans its OWN disks (no file content crosses the network), writes reports to its %TEMP%,
      and the report files are returned over the same session - this avoids the Kerberos "double hop"
      problem of writing to a central share from inside a remote session. Remote temp files are deleted.
    * Per-host failures (unreachable, access denied, timeout) are written to _failures.csv.

    Requirements: WinRM enabled on targets (Enable-PSRemoting / GPO), an account that is local admin on
    the targets (or member of Remote Management Users with read access to the data), TCP 5985/5986.

.EXAMPLE
    .\Invoke-PIIScanRemote.ps1 -ComputerName ws01,ws02,fs01 -Credential (Get-Credential CORP\pii_auditor)

.EXAMPLE
    # Every enabled computer in an OU, 32 at a time, fixed drives on each host, PST via Outlook where present
    .\Invoke-PIIScanRemote.ps1 -FromAD -ADSearchBase "OU=Workstations,DC=corp,DC=local" -ThrottleLimit 32 -ScanArgs @{ IncludePst = $true }

.EXAMPLE
    # Only specific folders on each host, HTTPS WinRM
    .\Invoke-PIIScanRemote.ps1 -ComputerListFile .\hosts.txt -RemotePath 'C:\Users','D:\Data' -UseSSL
#>
[CmdletBinding()]
param(
    [string[]]$ComputerName = @(),
    [string]$ComputerListFile,
    [switch]$FromAD,
    [string]$ADServer,
    [string]$ADSearchBase,
    [System.Management.Automation.PSCredential]$Credential,
    [string[]]$RemotePath = @(),                 # default: all fixed drives of each host
    [hashtable]$ScanArgs = @{},                  # extra Invoke-PIIScan parameters, e.g. @{ MinConfidence='High'; IncludeOwner=$true }
    [int]$ThrottleLimit = 16,
    [int]$TimeoutMinutes = 240,
    [switch]$UseSSL,
    [string]$CollectTo = '.\PII_Collected',
    [string]$EstateReportDir,
    [switch]$NoMerge
)

$ErrorActionPreference = 'Stop'
$scanner = Join-Path $PSScriptRoot 'Invoke-PIIScan.ps1'
$rulesPath = @((Join-Path $PSScriptRoot '..\rules\pii_rules.json'), (Join-Path $PSScriptRoot 'pii_rules.json')) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not (Test-Path $scanner)) { throw "Invoke-PIIScan.ps1 not found next to this script" }
if (-not $rulesPath) { throw "pii_rules.json not found (..\rules\ or next to this script)" }
$scannerText = [IO.File]::ReadAllText($scanner)
$rulesText = [IO.File]::ReadAllText((Resolve-Path $rulesPath).Path)

# ---------------------------------------------------------------- target list
$hosts = @($ComputerName)
if ($ComputerListFile) { $hosts += @(Get-Content $ComputerListFile | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') }) }
if ($FromAD) {
    $ldap = 'LDAP://' + $(if ($ADServer) { "$ADServer/" } else { '' })
    if ($ADSearchBase) { $ldap += $ADSearchBase } else {
        $rd = if ($ADServer) { "LDAP://$ADServer/RootDSE" } else { 'LDAP://RootDSE' }
        $rde = if ($Credential) { New-Object DirectoryServices.DirectoryEntry($rd, $Credential.UserName, $Credential.GetNetworkCredential().Password) } else { New-Object DirectoryServices.DirectoryEntry($rd) }
        $ldap += [string]$rde.Properties['defaultNamingContext'][0]
    }
    $root = if ($Credential) { New-Object DirectoryServices.DirectoryEntry($ldap, $Credential.UserName, $Credential.GetNetworkCredential().Password) } else { New-Object DirectoryServices.DirectoryEntry($ldap) }
    $ds = New-Object DirectoryServices.DirectorySearcher($root, '(&(objectCategory=computer)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))')
    $ds.PageSize = 500; [void]$ds.PropertiesToLoad.Add('dnshostname'); [void]$ds.PropertiesToLoad.Add('name')
    $res = $ds.FindAll()
    try { foreach ($r in $res) { $hosts += $(if ($r.Properties['dnshostname'].Count) { [string]$r.Properties['dnshostname'][0] } else { [string]$r.Properties['name'][0] }) } }
    finally { $res.Dispose() }
}
$hosts = @($hosts | Where-Object { $_ } | Sort-Object -Unique)
if (-not $hosts) { throw 'No target hosts. Use -ComputerName, -ComputerListFile or -FromAD.' }
Write-Host "[*] $($hosts.Count) target host(s), throttle $ThrottleLimit, timeout $TimeoutMinutes min"

# ---------------------------------------------------------------- remote payload
$params = @{} + $ScanArgs
if ($RemotePath.Count) { $params['Path'] = $RemotePath } elseif (-not $params.ContainsKey('Path')) { $params['AllDrives'] = $true }

$payload = {
    param([string]$ScannerText, [string]$RulesText, [hashtable]$Params)
    $out = Join-Path $env:TEMP ('PIIScan_' + [guid]::NewGuid().ToString('N'))
    $Params['OutputDir'] = $out; $Params['RulesJson'] = $RulesText; $Params['PassThru'] = $true; $Params['Quiet'] = $true
    try {
        $sb = [scriptblock]::Create($ScannerText)
        $r = & $sb @Params
        $files = @(Get-ChildItem $out -File | ForEach-Object { [pscustomobject]@{ Name = $_.Name; Bytes = [IO.File]::ReadAllBytes($_.FullName) } })
        [pscustomobject]@{ Host = $env:COMPUTERNAME; Ok = $true; Files = $files; Summary = $r.Summary; Error = '' }
    } catch {
        [pscustomobject]@{ Host = $env:COMPUTERNAME; Ok = $false; Files = @(); Summary = $null; Error = $_.Exception.Message }
    } finally { Remove-Item $out -Recurse -Force -ErrorAction SilentlyContinue }
}

$icm = @{ ComputerName = $hosts; ScriptBlock = $payload; ArgumentList = @($scannerText, $rulesText, $params); ThrottleLimit = $ThrottleLimit; AsJob = $true }
if ($Credential) { $icm['Credential'] = $Credential }
if ($UseSSL) { $icm['UseSSL'] = $true }
$job = Invoke-Command @icm

# ---------------------------------------------------------------- wait & collect
if (-not (Test-Path $CollectTo)) { New-Item -ItemType Directory -Path $CollectTo -Force | Out-Null }
$CollectTo = (Resolve-Path $CollectTo).Path
$deadline = (Get-Date).AddMinutes($TimeoutMinutes)
$done = @{}; $failures = New-Object System.Collections.Generic.List[object]
while ($true) {
    foreach ($cj in $job.ChildJobs) {
        if ($done.ContainsKey($cj.Location) -or $cj.State -notin 'Completed', 'Failed', 'Stopped') { continue }
        $done[$cj.Location] = $true
        $out = @(Receive-Job $cj -ErrorAction SilentlyContinue -ErrorVariable rerr)
        $r = $out | Where-Object { $_.PSObject.Properties['Files'] } | Select-Object -First 1
        if ($r -and $r.Ok) {
            $dir = Join-Path $CollectTo ($cj.Location -replace '[\\/:*?"<>|]', '_'); New-Item -ItemType Directory -Path $dir -Force | Out-Null
            foreach ($f in $r.Files) { [IO.File]::WriteAllBytes((Join-Path $dir $f.Name), [byte[]]$f.Bytes) }
            $s = $r.Summary
            Write-Host ("    [+] {0,-28} {1,7} files, {2,5} with PII, {3,4} Restricted, {4,4} PHI" -f $cj.Location, $s.files_examined, $s.files_with_pii, $s.files_by_classification.Restricted, $s.files_phi)
        } else {
            $msg = if ($r) { $r.Error } elseif ($rerr) { ($rerr | Select-Object -First 1).ToString() } elseif ($cj.JobStateInfo.Reason) { $cj.JobStateInfo.Reason.Message } else { "state $($cj.State)" }
            $failures.Add([pscustomobject]@{ Host = $cj.Location; Error = $msg })
            Write-Host "    [!] $($cj.Location): $msg" -ForegroundColor Yellow
        }
    }
    if ($done.Count -ge $job.ChildJobs.Count) { break }
    if ((Get-Date) -gt $deadline) {
        foreach ($cj in $job.ChildJobs) { if (-not $done.ContainsKey($cj.Location)) { $failures.Add([pscustomobject]@{ Host = $cj.Location; Error = "timeout after $TimeoutMinutes min" }); Stop-Job $cj } }
        break
    }
    $running = @($job.ChildJobs | Where-Object { $_.State -eq 'Running' }).Count
    Write-Progress -Activity 'Remote PII scan' -Status "$($done.Count)/$($hosts.Count) hosts finished, $running running"
    Start-Sleep -Seconds 5
}
Write-Progress -Activity 'Remote PII scan' -Completed
Remove-Job $job -Force -ErrorAction SilentlyContinue
if ($failures.Count) { $failures | Export-Csv (Join-Path $CollectTo '_failures.csv') -NoTypeInformation -Encoding UTF8 }
Write-Host "[*] Collected: $($done.Count - $failures.Count) host(s) OK, $($failures.Count) failed -> $CollectTo"

# ---------------------------------------------------------------- estate report
if (-not $NoMerge -and ($done.Count - $failures.Count) -gt 0) {
    if (-not $EstateReportDir) { $EstateReportDir = Join-Path $CollectTo '_estate' }
    & $scanner -MergeFrom $CollectTo -OutputDir $EstateReportDir -RulesFile $rulesPath
}
